import axios from 'axios';
import { BASE_URL_AXIOS, TOKEN_PASS_AXIOS } from '../constants/Const';
import { getCnpj } from '../utils/Utils';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

var cnpjEstabelecimento = getCnpj();

export function getCentrosMonetarios() {
    return axios.post(`LxApi/v1/CentroMonetario/Listar`, {
        query: { cnpjEstabelecimento }
    });
}

export function incluirCentroMonetario(codigoCentroMonetario, codigoBanco, agencia, digitoAgencia,
    conta, digitoConta, descricao, empresa, inativo, restrito) {
    return axios.post(`LxApi/v1/CentroMonetario/Incluir`, {
        cnpjEstabelecimento, codigoCentroMonetario, codigoBanco, agencia, digitoAgencia,
        conta, digitoConta, descricao, empresa, inativo, restrito
    });
}

export function alterarCentroMonetario(codigoCentroMonetario, codigoBanco, agencia, digitoAgencia,
    conta, digitoConta, descricao, inativo, restrito, rowVersion) {
    debugger;    
    return axios.put(`LxApi/v1/CentroMonetario/Alterar`, {
        cnpjEstabelecimento, codigoCentroMonetario, codigoBanco, agencia, digitoAgencia,
        conta, digitoConta, descricao, inativo, restrito, rowVersion
    });
}

export function excluirCentroMonetario(codigoCentroMonetario) {
    return axios.delete(`LxApi/v1/CentroMonetario/Excluir`, {
        params: { codigoCentroMonetario, cnpjEstabelecimento }
    });
} 