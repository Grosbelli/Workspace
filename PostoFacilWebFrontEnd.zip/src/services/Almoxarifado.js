import axios from 'axios';
import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';
import { getCodigoEstabelecimento } from '../utils/Utils';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

let codigoEstabelecimento = getCodigoEstabelecimento();

export function getListAlmoxarifado() {
    return axios.get(`LxApi/v1/Almoxarifado/Listar/`, {
        params: { codigoEstabelecimento }
    })
}

export function getAlmoxarifado(codigoAlmoxarifado) {
    return axios.get(`LxApi/v1/Almoxarifado/Selecionar`, {
        params: {
            codigoEstabelecimento,
            codigoAlmoxarifado
        }
    })
}

export function incluirAlmoxarifado(numeroAlmoxarifado, descricao, tipo, inativo) {
    return axios.post(`LxApi/v1/Almoxarifado/Incluir`, {
        codigoEstabelecimento, numeroAlmoxarifado, descricao, tipo, inativo
    });
}


export function alterarAlmoxarifado(codigoAlmoxarifado, numeroAlmoxarifado, descricao, tipo, inativo, rowVersion) {
    return axios.put(`LxApi/v1/Almoxarifado/Alterar`, {
        codigoEstabelecimento, codigoAlmoxarifado, numeroAlmoxarifado, descricao, tipo, inativo, rowVersion
    });
}

export function excluirAlmoxarifado(codigoAlmoxarifado) {
    return axios.delete(`LxApi/v1/Almoxarifado/Excluir`, {
        params: {
            codigoEstabelecimento,
            codigoAlmoxarifado
        }
    });
}

export function restaurarAlmoxarifado(codigoAlmoxarifado) {
    return axios.get(`LxApi/v1/Almoxarifado/Restaurar`, {
        params: {
            codigoEstabelecimento,
            codigoAlmoxarifado
        }
    });
}

