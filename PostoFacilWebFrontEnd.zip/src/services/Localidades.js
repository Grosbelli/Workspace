import axios from 'axios';

import {
    BASE_URL_AXIOS,
    TOKEN_PASS_AXIOS
} from '../constants/Const';

import { getCnpj } from "../utils/Utils";
import { endianness } from 'os';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getEstados() {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.get(`LxApi/v1/UnidadeFederativa/MontarComboUF`, {
    });
}

export function getCidades(codigoUF) {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.get(`LxApi/v1/Municipio/MontarComboCidades`, {
        params: { codigoUF }
    });
}

export function getCep(cep) {
    try {
        axios.defaults.baseURL = "https://lx-smb-api-qa.azurewebsites.net/api/v1/cep/";
        return axios.get(`${cep}`, {
        })
    }
    finally {
        axios.defaults.baseURL = BASE_URL_AXIOS;
    }
}

