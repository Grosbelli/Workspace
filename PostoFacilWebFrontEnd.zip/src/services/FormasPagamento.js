import axios from 'axios';

import {
    BASE_URL_AXIOS,
    TOKEN_PASS_AXIOS
} from '../constants/Const';

import { getCnpj } from "../utils/Utils";

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getFormasPagamento(somenteAtivos, cadastroCompleto) {
    let cnpjEstabelecimento = getCnpj();    
    return axios.post(`LxApi/v1/FormasPagamento/Listar/`, {
        query: {
            cnpjEstabelecimento,
            somenteAtivos,
            cadastroCompleto
        }
    });
}

export function getFormaPagamento(codigoFormaPagamento) {
    let cnpjEstabelecimento = getCnpj();
    return axios.get(`LxApi/v1/FormasPagamento/Selecionar/`, {
        params: {
            cnpjEstabelecimento,
            codigoFormaPagamento
        }
    })
}

export function incluiFormaPagamento(
    descricao,
    tipo,
    avisoSangria,
    interna,
    opcoesPagamento,
    parcelamento,
    inativo,
    diaRecebimento
) {
    let cnpjEstabelecimento = getCnpj();
    return axios.post(`LxApi/v1/FormasPagamento/Incluir`, {
        cnpjEstabelecimento,
        descricao,
        tipo,
        avisoSangria,
        interna,
        opcoesPagamento,
        parcelamento,
        inativo,
        diaRecebimento
    });
}

export function alteraFormaPagamento(
    codigo,
    descricao,
    tipo,
    avisoSangria,
    interna,
    opcoesPagamento,
    parcelamento,
    inativo,
    diaRecebimento,
    rowVersion) {
    let cnpjEstabelecimento = getCnpj();
    return axios.put(`LxApi/v1/FormasPagamento/Alterar`, {
        cnpjEstabelecimento,
        codigo,
        descricao,
        tipo,
        avisoSangria,
        interna,
        opcoesPagamento,
        parcelamento,
        inativo,
        diaRecebimento,
        rowVersion
    });
}

export function excluiFormaPagamento(codigoFormaPagamento) {
    let cnpjEstabelecimento = getCnpj();
    return axios.delete(`LxApi/v1/FormasPagamento/Excluir/`, {
        params: { cnpjEstabelecimento, codigoFormaPagamento }
    });
}