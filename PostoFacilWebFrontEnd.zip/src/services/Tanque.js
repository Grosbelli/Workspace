import axios from 'axios';
import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getTanques(cnpjEstabelecimento) {
    return axios.post(`LxApi/v1/Tanque/Listar`, {        
        query: { cnpjEstabelecimento }
    })
}

export function getTanque(codigoTanque, cnpjEstabelecimento) {
    return axios.get(`LxApi/v1/Tanque/Selecionar`, {
        params: {
            codigoTanque,
            cnpjEstabelecimento            
        }
    })
}

export function incluirTanque(
    cnpjEstabelecimento, numeroTanque, codigoTipoAlmoxarifado, codigoProduto, capacidade, percentualErroMedicao, dataAtivacao) {
    return axios.post(`LxApi/v1/Tanque/Incluir`, {
        cnpjEstabelecimento, numeroTanque, codigoTipoAlmoxarifado, codigoProduto, capacidade, percentualErroMedicao, dataAtivacao
    });
}

export function alterarTanque(
    cnpjEstabelecimento, codigoTanque, numeroTanque, codigoProduto, capacidade, percentualErroMedicao, dataAtivacao, motivoAlteracao, inativo, rowVersion) {
    return axios.put(`LxApi/v1/Tanque/Alterar`, {
        cnpjEstabelecimento, codigoTanque, numeroTanque, codigoProduto, capacidade, percentualErroMedicao, dataAtivacao, motivoAlteracao, inativo, rowVersion
    });
}

export function excluirTanque(codigoTanque, cnpjEstabelecimento) {
    return axios.delete(`LxApi/v1/Tanque/Excluir`, {
        params: {
            codigoTanque,
            cnpjEstabelecimento
        }
    });
}
