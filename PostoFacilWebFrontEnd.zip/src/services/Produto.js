import axios from 'axios';

import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getCombustivel(cnpjEstabelecimento) {
    return axios.get(`LxApi/v1/Tanque/MontarComboProdutosCombustivel`, { 
        params: {cnpjEstabelecimento}
    });
}

export function getTipoAlmoxarifadoComb(cnpjEstabelecimento){
    return axios.get(`LxApi/v1/Tanque/MontarComboTipoAlmoxarifadoCombustivel`, { 
        params: {cnpjEstabelecimento}
    }); 
}