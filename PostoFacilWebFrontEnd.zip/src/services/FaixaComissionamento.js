import axios from 'axios';

import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getFaixaComissionamento(codigoEstabelecimento) {
    return axios.get(`LxApi/v1/FaixaComissionamento/Listar/`, {
        params: {codigoEstabelecimento}
    });
}

export function incluirFaixaComissionamento(codigoEstabelecimento, codigoSetor, faixaInicial, faixaFinal, percentual) {
    return axios.post(`LxApi/v1/FaixaComissionamento/Incluir`, {
        codigoEstabelecimento, codigoSetor, faixaInicial, faixaFinal, percentual
    });
}

export function alterarFaixaComissionamento(codigo, codigoEstabelecimento, codigoSetor, faixaInicial, faixaFinal, percentual, rowVersion) {
    return axios.put(`LxApi/v1/FaixaComissionamento/Alterar`, {
        codigo, codigoEstabelecimento, codigoSetor, faixaInicial, faixaFinal, percentual, rowVersion
    });
}

export function excluirFaixaComissionamento(codigoEstabelecimento,codigo) {
    return axios.delete(`LxApi/v1/FaixaComissionamento/Excluir/`, {
        params: { codigoEstabelecimento, codigo }
    });
} 