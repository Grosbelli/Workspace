import axios from 'axios';
import { CNPJ_DEFAULT } from '../constants/Const';

import { BASE_URL_AXIOS, TOKEN_PASS_AXIOS } from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getEstabelecimentos() {
    var cnpj = CNPJ_DEFAULT;
    var cadastroCompleto = true;
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.post(`LxApi/v1/Empresa/Listar`, {
        query: { cnpj, cadastroCompleto }
    });
}

export function incluirEstabelecimento(razaoSocial, inativo, nomeFantasia, codigoANP, dataContituicao, cnpj,
    inscricaoEstadual, inscricaoMunicipal, email, enderecoInternet, endereco, representante, fiscais, setor) {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.post(`LxApi/v1/Empresa/Incluir`, {
        razaoSocial, inativo, nomeFantasia, codigoANP, dataContituicao, cnpj,
        inscricaoEstadual, inscricaoMunicipal, email, enderecoInternet, endereco, representante, fiscais, setor
    });
}

export function alterarEstabelecimento(Codigo, RazaoSocial, Inativo, NomeFantasia, CodigoANP, DataConstituicao, CNPJ, InscricaoEstadual, InscricaoMunicipal, Email, EnderecoInternet,
    Endereco, Representante, Fiscais, Setor, Cnae, rowVersion) {
    axios.defaults.baseURL = BASE_URL_AXIOS;  
    EnderecoInternet = EnderecoInternet === null ? "" : EnderecoInternet;
    var registroJunta = "";
    var dataRegistroJunta = "";
    return axios.put(`LxApi/v1/Empresa/Alterar`, {
        Codigo, RazaoSocial, Inativo, NomeFantasia, CodigoANP, DataConstituicao, CNPJ, InscricaoEstadual, InscricaoMunicipal, Email, EnderecoInternet,
        Endereco, Representante, Fiscais, Setor, Cnae, rowVersion, registroJunta, dataRegistroJunta
    });
}

export function excluirEstabelecimento(codigoEstabelecimento, codigo) {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.delete(`LxApi/v1/Estabelecimento/Excluir/`, {
        params: { codigoEstabelecimento, codigo }
    });
}

export function montarComboContador() {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    var classificacaoPessoa = 2;
    var cnpjEstabelecimento = CNPJ_DEFAULT;
    var codigoCategoria = 2;
    return axios.get(`LxApi/v1/Pessoa/MontarCombo`, {
        params: { cnpjEstabelecimento, classificacaoPessoa, codigoCategoria }
    });
}

export function montarComboUfs() {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    return axios.get(`LxApi/v1/UnidadeFederativa/MontarComboUF`, {
    });
}

export function montarComboMunicipios(codigoUF) {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;
    console.log('cuf-' + codigoUF);
    return axios.get(`LxApi/v1/Municipio/MontarComboCidades`, {
        params: { codigoUF }
    });
}

export function listarCNAEs() {
    axios.defaults.baseURL = BASE_URL_AXIOS;
    axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;
    return axios.post(`LxApi/v1/Cnae/Listar`, {
    });
}

