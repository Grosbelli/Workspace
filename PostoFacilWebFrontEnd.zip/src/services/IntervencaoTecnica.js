import axios from 'axios';
import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getIntervencaoTecnica(codigoEstabelecimento) {
    return axios.post(`LxApi/v1/IntervencaoTecnica/Listar`, {
        query: codigoEstabelecimento
    })
}


export function alterarIntervencaoTecnica(
    codigoEstabelecimento,
    codigoIntervencaoTecnica,
    dataIntervencao,
    codigoTanque,
    codigoBico,
    codigoPessoa,
    encerranteInicial,
    encerranteFinal,
    cpfTecnico,
    nomeTecnico,
    lacresRemovidos,
    lacresNovos,
    motivo,
    rowVersion
) {
    return axios.put(`LxApi/v1/IntervencaoTecnica/Alterar`, {
        codigoEstabelecimento,
        codigoIntervencaoTecnica,
        dataIntervencao,
        codigoTanque,
        codigoBico,
        codigoPessoa,
        encerranteInicial,
        encerranteFinal,
        cpfTecnico,
        nomeTecnico,
        lacresRemovidos,
        lacresNovos,
        motivo,
        rowVersion
    });
}

export function excluirIntervencaoTecnica(codigoEstabelecimento, codigoIntervencaoTecnica) {
    return axios.delete(`LxApi/v1/IntervencaoTecnica/Excluir`, {
        params: {
            codigoEstabelecimento,
            codigoIntervencaoTecnica
        }
    });
}
