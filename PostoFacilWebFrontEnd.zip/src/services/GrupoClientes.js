import axios from 'axios';
import {CNPJ_DEFAULT} from '../constants/Const';

import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';
import { getCodigoEstabelecimento } from '../utils/Utils';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

let codigoEstabelecimento = getCodigoEstabelecimento();

export function buscarGrupoClientes(cadastroCompleto) {
    return axios.post(`LxApi/v1/AgrupadorCliente/Listar`, {
        query: {
            codigoEstabelecimento,
            cadastroCompleto
        }
    }

    );
}

export function selecionarGrupoClientes(codigoEstabelecimento) {
    return axios.get(`LxApi/v1/AgrupadorCliente/Selecionar/${codigoEstabelecimento}`);
}

export function incluirGrupoClientes(descricao, mostraAgrupado, values) {    
    const clientes = values.map(cli => { return {codigoCliente: cli} })
    return axios.post(`LxApi/v1/AgrupadorCliente/Incluir`, {
        codigoEstabelecimento,
        descricao,
        mostraAgrupado,
        clientes
    });
}

export function alterarGrupoClientes(id, mostraAgrupado, descricao, rowVersion, values) {    
    const clientes = values.map(cli => { return {codigoCliente: cli} })
    return axios.put(`LxApi/v1/AgrupadorCliente/Alterar`, {
        codigoEstabelecimento, 
        id, 
        mostraAgrupado, 
        descricao, 
        rowVersion, 
        clientes            
    });
}

export function excluirGrupoClientes(codigoAgrupador) {
    return axios.delete(`LxApi/v1/AgrupadorCliente/Excluir`, {
        params: {
            codigoEstabelecimento,
            codigoAgrupador
        }
    });
}

export function montarComboClientes() {
    var classificacaoPessoa = 1;
    var cnpjEstabelecimento = CNPJ_DEFAULT;  
    return axios.get(`LxApi/v1/Pessoa/MontarCombo`, {
        params: { cnpjEstabelecimento, classificacaoPessoa}
    });
}


