import axios from 'axios';

import {
    BASE_URL_AXIOS,
    TOKEN_PASS_AXIOS
} from '../constants/Const';

import { getCnpj } from "../utils/Utils";

import { none, Classificacao, Categoria } from "../components/screens/pessoas/ScreenPessoas";


axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

function _classificacoes(
    isCliente,
    categoriaCliente,

    isFornecedor,
    categoriaFornecedor,
    crc,
    nomeContador,

    isFabricante,
    categoriaFabricante,

    isTransportadora) {
    let classificacoes = [];

    if (isCliente) {
        const classificacao = {
            codigo: Classificacao.Cliente
        };
        if (categoriaCliente !== none)
            classificacao.categoria = { codigo: categoriaCliente };
        classificacoes.push(classificacao);
    };

    if (isFornecedor) {
        const classificacao = {
            codigo: Classificacao.Fornecedor,
            categoria: { codigo: categoriaFornecedor }
        };
        if (Number(categoriaFornecedor) === Categoria.Contador) {
            classificacao.categoria.crc = crc;
            classificacao.categoria.nomeContador = nomeContador
        };
        classificacoes.push(classificacao);
    };

    if (isFabricante) {
        classificacoes.push({
            codigo: Classificacao.Fabricante,
            categoria: { codigo: categoriaFabricante }
        })
    };
    if (isTransportadora) {
        classificacoes.push({
            codigo: Classificacao.Transportadora
        })
    };
    return classificacoes;
}

function _endereco(
    codigoUF,
    codigoMunicipio,
    endereco,
    numero,
    complemento,
    referencia,
    bairro,
    cep) {
    return {
        codigoUF: codigoUF,
        codigoMunicipio: codigoMunicipio,
        endereco: endereco,
        numero: numero,
        complemento: complemento,
        referencia: referencia,
        bairro: bairro,
        cep: cep
    }
}

function _contatos(
    nome,
    descricao,
    ddd,
    numero,
    email) {
    debugger;
    if (!!nome || !!descricao || !!ddd || !!numero || !!email) {
        return [
            {
                nome: nome,
                descricao: descricao,
                ddd: ddd,
                numero: numero,
                email: email
            }
        ]
    }
    else
        return [];
};

export function incluiPessoa(
    cnpjCpf,
    inscricaoEstadual,
    inscricaoMunicipal,

    nome,
    apelido,
    isentoICMS,
    dataNascimento,
    identidade,
    orgaoEmissor,
    emiteNFe,
    ativo,
    tipo,

    isCliente,
    categoriaCliente,

    isFornecedor,
    categoriaFornecedor,
    crc,
    nomeContador,

    isFabricante,
    categoriaFabricante,

    isTransportadora,

    cep,
    codigoUF,
    codigoMunicipio,
    endereco,
    numero,
    complemento,
    referencia,
    bairro,

    contatoNome,
    contatoDescricao,
    contatoDDD,
    contatoNumero,
    contatoEMail,

    site
) {
    return axios.post(`LxApi/v1/Pessoa/Incluir`, {
        cnpjEstabelecimento: getCnpj(),

        cnpjCpf,
        inscricaoEstadual,
        inscricaoMunicipal,

        nome,
        apelido,
        isentoICMS,
        dataNascimento,
        identidade,
        orgaoEmissor,
        emiteNFe,
        inativo: !ativo,
        tipo: { codigo: tipo },

        classificacoes: _classificacoes(
            isCliente,
            categoriaCliente,
            isFornecedor,
            categoriaFornecedor,
            crc,
            nomeContador,
            isFabricante,
            categoriaFabricante,
            isTransportadora),

        endereco: _endereco(
            codigoUF,
            codigoMunicipio,
            endereco,
            numero,
            complemento,
            referencia,
            bairro,
            cep),

        contatos: _contatos(
            contatoNome,
            contatoDescricao,
            contatoDDD,
            contatoNumero,
            contatoEMail),

        site
    });
}

export function alteraPessoa(
    codigo,

    cnpjCpf,
    inscricaoEstadual,
    inscricaoMunicipal,

    nome,
    apelido,
    isentoICMS,
    dataNascimento,
    identidade,
    orgaoEmissor,
    emiteNFe,
    ativo,
    tipo,

    isCliente,
    categoriaCliente,

    isFornecedor,
    categoriaFornecedor,
    crc,
    nomeContador,

    isFabricante,
    categoriaFabricante,

    isTransportadora,

    cep,
    codigoUF,
    codigoMunicipio,
    endereco,
    numero,
    complemento,
    referencia,
    bairro,

    contatoNome,
    contatoDescricao,
    contatoDDD,
    contatoNumero,
    contatoEMail,

    site,
    rowVersion
) {
    return axios.put(`LxApi/v1/Pessoa/Alterar`, {
        cnpjEstabelecimento: getCnpj(),

        codigo,

        cnpjCpf,
        inscricaoEstadual,
        inscricaoMunicipal,

        nome,
        apelido,
        isentoICMS,
        dataNascimento,
        identidade,
        orgaoEmissor,
        emiteNFe,
        inativo: !ativo,
        tipo: { codigo: tipo },

        classificacoes: _classificacoes(
            isCliente,
            categoriaCliente,
            isFornecedor,
            categoriaFornecedor,
            crc,
            nomeContador,
            isFabricante,
            categoriaFabricante,
            isTransportadora),

        endereco: _endereco(
            codigoUF,
            codigoMunicipio,
            endereco,
            numero,
            complemento,
            referencia,
            bairro,
            cep),

        contatos: _contatos(
            contatoNome,
            contatoDescricao,
            contatoDDD,
            contatoNumero,
            contatoEMail),

        site,
        rowVersion
    });
}

export function excluiPessoa(codigo) {
    const cnpjEstabelecimento = getCnpj();
    return axios.delete(`LxApi/v1/Pessoa/Excluir/`, {
        params: {
            cnpjEstabelecimento,
            codigo
        }
    });
}

export function getPessoas(consulta) {
    consulta.cnpjEstabelecimento = getCnpj();
    consulta.cadastroCompleto = true;

    return axios.post(`LxApi/v1/Pessoa/Listar/`, {
        query: consulta
    });
}

export function verifyPessoa(cnpjCpf) {
    return axios.get(`LxApi/v1/Pessoa/Verificar/`, {
        params: {
            cnpjEstabelecimento: getCnpj(),
            cpfCnpj: cnpjCpf // ATENÇÃO! nessa api não foi mantido o padrão cnpjCpf (está invertido)
        }
    })
}

export function getTipos() {
    return axios.get(`LxApi/v1/Pessoa/MontarComboTipo/`, {
        params: {}
    });
}

export function getClassificacoes() {
    return axios.get(`LxApi/v1/Pessoa/MontarComboClassificacao/`, {
        params: {}
    });
}

export function getCategorias(classificacaoPessoa) {
    return axios.get(`LxApi/v1/Pessoa/MontarComboCategoria/`, {
        params: { classificacaoPessoa: classificacaoPessoa }
    });
}
