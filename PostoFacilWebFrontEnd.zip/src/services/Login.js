﻿import axios from 'axios';
import {CNPJ_DEFAULT} from '../constants/Const';

import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export default function fazlogin(nome, senha) {
        return axios.post(`LxApi/v1/auth`, {
        username: nome,
        password: senha,
    });
}   