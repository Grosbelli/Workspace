import axios from 'axios';

import {
    BASE_URL_AXIOS,
    TOKEN_PASS_AXIOS
} from '../constants/Const';

import { getCnpj } from "../utils/Utils";

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function montaComboRede(somenteAtivas) {
    return axios.get(`LxApi/v1/EstruturaCartao/MontaComboRede/`, {
        params: {            
            somenteAtivas            
        }
    });
}