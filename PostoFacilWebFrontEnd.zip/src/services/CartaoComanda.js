import axios from 'axios';

import {BASE_URL_AXIOS, TOKEN_PASS_AXIOS} from '../constants/Const';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

export function getCartaoComanda(codigoEstabelecimento) {
    return axios.get(`LxApi/v1/CartaoComanda/Listar/`, {
        params: {codigoEstabelecimento}
    });
}

export function incluirCartaoComanda(codigoEstabelecimento, numeroCartaoComanda, inativo) {
    return axios.post(`LxApi/v1/CartaoComanda/Incluir`, {
        codigoEstabelecimento, numeroCartaoComanda, inativo
    });
}

export function incluirCartaoComandaEmLote(cartoescomanda) {
    // cartoescomanda -> [{codigoEstabelecimento, numeroCartaoComanda, inativo,}, ...]
    return axios.post(`LxApi/v1/CartaoComanda/IncluirEmLote`, cartoescomanda);
}

export function alterarCartaoComanda(codigoEstabelecimento, codigoCartaoComanda, numeroCartaoComanda, inativo, excluido, rowVersion) {
    return axios.put(`LxApi/v1/CartaoComanda/Alterar`, {
        codigoEstabelecimento, codigoCartaoComanda, numeroCartaoComanda, inativo, excluido, rowVersion
    });
}

export function excluirCartaoComanda(codigoEstabelecimento, codigoCartaoComanda, rowVersion) {
    return axios.delete(`LxApi/v1/CartaoComanda/Excluir`, {data: {
        codigoEstabelecimento, codigoCartaoComanda, rowVersion
    }});
}

export function getMensagem(codigoEstabelecimento) {
    return axios.get(`LxApi/v1/CartaoComanda/Mensagem/Listar`,
        {
            params: {
                codigoEstabelecimento
            }
        })     
}

export function alterarMensagem(codigoEstabelecimento, mensagem1, mensagem2, mensagem3) {
    return axios.put(`LxApi/v1/CartaoComanda/Mensagem/Alterar`, {
        codigoEstabelecimento, mensagem1, mensagem2, mensagem3
    })
}