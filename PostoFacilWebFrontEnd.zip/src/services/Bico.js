import axios from 'axios';
import { BASE_URL_AXIOS, TOKEN_PASS_AXIOS } from '../constants/Const';
import { getCnpj } from '../utils/Utils';

axios.defaults.baseURL = BASE_URL_AXIOS;
axios.defaults.headers.common["TokenPass"] = TOKEN_PASS_AXIOS;

var cnpjEstabelecimento = getCnpj();

export function getBicos() {
    return axios.post(`LxApi/v1/Bico/Listar`, {
        query: { cnpjEstabelecimento }
    });
}

export function incluirBico(codigoTanque, codigoBomba, numeroSequencial, numeroBicoNaBomba,
    codigoNivelPreco, permiteAbastecimentoManual, numeroHexa, dataAtivacao) {
    return axios.post(`LxApi/v1/Bico/Incluir`, {
        cnpjEstabelecimento, codigoTanque, codigoBomba, numeroSequencial, numeroBicoNaBomba,
        codigoNivelPreco, permiteAbastecimentoManual, numeroHexa, dataAtivacao
    });
}

export function alterarBico(codigoBico, codigoTanque, codigoBomba, numeroSequencial, numeroBicoNaBomba,
    codigoNivelPreco, permiteAbastecimentoManual, numeroHexa, dataAtivacao, inativo, rowVersion) {
    return axios.put(`LxApi/v1/Bico/Alterar`, {
        cnpjEstabelecimento, codigoBico, codigoTanque, codigoBomba, numeroSequencial, numeroBicoNaBomba,
        codigoNivelPreco, permiteAbastecimentoManual, numeroHexa, dataAtivacao, inativo, rowVersion
    });
}

export function excluirBico(codigoBico) {
    return axios.delete(`LxApi/v1/Bico/Excluir`, {
        params: { codigoBico, cnpjEstabelecimento }
    });
}

export function montarComboTanque() {
    return axios.get(`LxApi/v1/Tanque/MontarCombo`, {
        params: { cnpjEstabelecimento }
    });
}

export function montarComboBomba() {
    return axios.get(`LxApi/v1/Bomba/MontarCombo`, {
        params: { cnpjEstabelecimento }
    });
}

export function montarComboListaPrecos(codigoTanque) {
    return axios.get(`LxApi/v1/Bico/MontarComboNiveisPreco`, {
        params: { codigoTanque, cnpjEstabelecimento }
    });
}
