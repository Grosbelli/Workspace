import axios from 'axios';

export function consultaCep(cepConsultado) {
    axios.defaults.baseURL = "https://lx-smb-api-qa.azurewebsites.net/api/v1/cep/";
    return axios.get(`${cepConsultado}`, {
    });
}
