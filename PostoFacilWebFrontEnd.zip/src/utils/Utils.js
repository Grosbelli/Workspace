import { CNPJ_DEFAULT, ESTACOD_DEFAULT } from "../constants/Const";

import validaInscricaoEstadual from "inscricaoestadual";

export function getCnpj() {
    return CNPJ_DEFAULT;
}

export function getCodigoEstabelecimento() {
    return ESTACOD_DEFAULT;
}

export function toFloatFormattedDisplay(numberString) {
    let number = parseFloat(numberString);
    let s = number.toLocaleString("pt-br");
    return number % 1 === 0 ? (s + ",00") : (s);
}

export function validaCPF(value) {
    let c = String(value);
    const b = [11, 10, 9, 8, 7, 6, 5, 4, 3, 2];

    if ((c = c.replace(/[^\d]/g, "")).length != 11)
        return false;

    if (/0{11}/.test(c))
        return false;

    for (var i = 0, n = 0; i < 9; n += c[i] * b[++i]);
    if (c[9] != (((n %= 11) < 2) ? 0 : 11 - n))
        return false;

    for (var i = 0, n = 0; i <= 9; n += c[i] * b[i++]);
    if (c[10] != (((n %= 11) < 2) ? 0 : 11 - n))
        return false;

    return true;
}

export function validaCNPJ(value) {
    // http://araujo.cc/blog/funcao-javascript-para-validar-cnpj.html
    let c = String(value);
    const b = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

    if ((c = c.replace(/[^\d]/g, "")).length != 14)
        return false;

    if (/0{14}/.test(c))
        return false;

    for (var i = 0, n = 0; i < 12; n += c[i] * b[++i]);
    if (c[12] != (((n %= 11) < 2) ? 0 : 11 - n))
        return false;

    for (var i = 0, n = 0; i <= 12; n += c[i] * b[i++]);
    if (c[13] != (((n %= 11) < 2) ? 0 : 11 - n))
        return false;

    return true;
};

export function validaCpfOrCnpj(value) {
    return validaCPF(value) || validaCNPJ(value);
}

export function maskedCpf(value) {
    // retorna value formatado com a máscara de CPF "999.999.999-99"
    let str = String(value);
    return (
        str.substr(0, 3) + "." +
        str.substr(3, 3) + "." +
        str.substr(6, 3) + "-" +
        str.substr(9, 2)
    );
}

export function maskedCnpj(value) {
    // retorna value formatado com a máscara do CNPJ "99.999.999/9999-99"
    let str = String(value);
    while (str.length < 14) { str = '0' + str };
    return (
        str.substr(0, 2) + "." +
        str.substr(2, 3) + "." +
        str.substr(5, 3) + "/" +
        str.substr(8, 4) + "-" +
        str.substr(12, 2)
    );
}

export function maskedCnpjCpf(value) {
    // retorna value formatado como CPF ou CNPJ se for válido em um desses    
    if (validaCPF(value)) {
        return maskedCpf(value);
    }
    if (validaCNPJ(value)) {
        return maskedCnpj(value);
    }
    return value;
}

export function maskCpfCnpj(value) {
    // se value for um CPF válido retorna a máscara do CPF mais um #
    // se for um CNPJ válido retorna a máscara do CNPJ
    // senão retorna 14 #
    if (validaCPF(value)) {
        return "###.###.###-###"; // o último é para poder continuar digitando
    }
    if (validaCNPJ(value)) {
        return "##.###.###/####-##";
    }
    return "##############";
}

export function validaIE(inscricaoEstadual, uf) {
    return validaInscricaoEstadual(inscricaoEstadual, uf);
}

export function getMeses() {
    const meses = [];
    meses.push({ label: "Janeiro", value: 0 });
    meses.push({ label: "Fevereiro", value: 1 });
    meses.push({ label: "Março", value: 2 });
    meses.push({ label: "Abril", value: 3 });
    meses.push({ label: "Maio", value: 4 });
    meses.push({ label: "Junho", value: 5 });
    meses.push({ label: "Julho", value: 6 });
    meses.push({ label: "Agosto", value: 7 });
    meses.push({ label: "Setembro", value: 8 });
    meses.push({ label: "Outubro", value: 9 });
    meses.push({ label: "Novembro", value: 10 });
    meses.push({ label: "Dezembro", value: 11 });
    
    return meses;
}

export function getDateIndex(month, year){
    return Number(String(year) + String(month));
}

export function isValidEmail(email) {
    // https://stackoverflow.com/questions/46155/how-to-validate-an-email-address-in-javascript    
    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

export function ibgeToUf(ibge) {
    switch (ibge) {
        case 12: return "AC";        
        case 27: return "AL";
        case 13: return "AM";
        case 16: return "AP";
        case 29: return "BA";
        case 23: return "CE";
        case 53: return "DF";
        case 32: return "ES";
        case 99: return "EX";
        case 52: return "GO";
        case 21: return "MA";
        case 31: return "MG";
        case 50: return "MS";
        case 51: return "MT";
        case 15: return "PA";
        case 25: return "PB";
        case 26: return "PE";
        case 22: return "PI";
        case 41: return "PR";
        case 33: return "RJ";
        case 24: return "RN";
        case 11: return "RO";
        case 14: return "RR";
        case 43: return "RS";
        case 42: return "SC";
        case 28: return "SE";
        case 35: return "SP";
        case 17: return "TO";
        default: return "";
    }
}

export function isValidIE(ie, uf) {
    return validaInscricaoEstadual(ie, isNaN(uf) ? uf : ibgeToUf(uf))
}