export let CNPJ_DEFAULT = "17898787000153"; 
export let ESTACOD_DEFAULT = "1";

export const TOKEN_PASS_AXIOS = "491E26F7-E1D7-4B53-9324-C28C80B41821";
export const BASE_URL_AXIOS = "http://dev.pfw.sellercorp.com.br/";
//export const BASE_URL_AXIOS = "http://qa.pfw.sellercorp.com.br/";

export function setDadosAcesso(novoCNPJ, novoEstaCod) {
    CNPJ_DEFAULT = novoCNPJ;
    ESTACOD_DEFAULT = novoEstaCod;
    console.log('cnpj novo:' + CNPJ_DEFAULT);
    console.log('estacod novo:' + ESTACOD_DEFAULT);
}
