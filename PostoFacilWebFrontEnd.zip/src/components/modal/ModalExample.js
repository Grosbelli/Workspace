import React, { Component } from 'react';
import { Botao } from './../botoes/Botao';
import { Modal, ModalBody, ModalHeader, ModalFooter } from './Modal';

import icmodal from './../img/modal-ic-head.png';
import modalclose from './../img/modal-close.png';

export class ModalExample extends Component {

    constructor() {
        super();
        this.state = { showmodal: false };
    }

    onRequestModal = (showmodal = true) => {
        this.setState({
            showmodal
        });
    }

    render() {

        const {
            content, successTitle, cancelTitle
        } = this.props;

        return (
            <div>
                
                <Modal className={`${(this.state.showmodal) ? 'active' : null}`} onClose={() => this.onRequestModal(false)}>
                        <ModalHeader 
                            title="This content is password protected."
                            subtitle="Please enter your password."
                        />
                        <ModalBody>
                            <div className="row">
                                <div className="col-1">
                                    <div className="form-input">
                                        <input type="input" className="input" required />
                                        <label className="input-label">Enter your password:</label>
                                    </div>
                                </div>
                            </div>
                        </ModalBody>
                        
                        <ModalFooter>
                            <Botao icon="icon-lx-trash" title={"Cancelar"} onClick={() => { this.onRequestModal(false)}} />
                            <Botao secondary icon="icon-lx-check" title={"Salvar"} onClick={() => { this.onRequestModal(false)}} />
                        </ModalFooter>
                </Modal>
                <div onClick={() => this.onRequestModal()}>TESTE</div>
            </div>
        );
    }
}
