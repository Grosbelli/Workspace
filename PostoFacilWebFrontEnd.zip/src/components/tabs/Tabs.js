import React, { Component } from 'react';

export class TabHead extends React.Component {

  handleChange(index){
    this.props.handleChange(index);
  }

  render(){

    const { indexShow } = this.props;

    return (
      <div className="tab">
        <div className="tab-container">
            {this.props.children.map((elmt, index) => {
            return <div key={index} className={`tab-item ${index === indexShow ? 'active':''}`} onClick={() => this.handleChange(index)}>{elmt}</div>
            })}
        </div>
      </div>
    );
      
  }
}

export class TabPanel extends React.Component {

  render(){

    const Elmt = this.props.children.find((Elmt, index) => index === this.props.indexShow);

    return (
        <div className="tab-content">
            {Elmt}
        </div>
    );
  }
}