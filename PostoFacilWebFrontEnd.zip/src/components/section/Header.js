import React, { Component } from 'react';

export class SectionHeader extends Component {
    render() {

        const {
            title, subtitle, back, children, right
        } = this.props;

        return (
            <header className="section-header">

                { (back) ? <div className="section-header-back"></div> : <div className="section-header-home"></div> }

                <div className="section-header-content">
                    <h1>{title}</h1>
                    <p>{subtitle}</p>
                </div>

                {children}

                <div className="section-header-right">
                    {right}
                </div>
               
            </header>
        );
    }
}