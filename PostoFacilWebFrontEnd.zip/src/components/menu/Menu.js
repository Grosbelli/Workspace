import React, { Component } from "react";

import { Link } from "react-router-dom";

import logo from "./../img/linx-logomarca.png";
import logomobile from "./../img/linx-logomarca-mobile.png";
import icfinanceiro from "./../img/menu-ic-financeiro.png";
import icestoque from "./../img/menu-ic-estoque.png";
import iccompras from "./../img/menu-ic-compras.png";
import icconsultas from "./../img/menu-ic-consultas.png";
import icrelatorios from "./../img/menu-ic-relatorios.png";
import icgraficos from "./../img/menu-ic-graficos.png";
import iccadastros from "./../img/menu-ic-cadastros.png";
import icclose from "./../img/sidebarnav-ic-close.png";
import headeropen from "./../img/header-ic-menu.png";
import headerclose from "./../img/header-ic-close.png";

export class Menu extends Component {
  state = {
    active: false,
    activeItem: null,
    activeSubMenu: null,
    menu: [
      {
        nome: "Cadastros",
        img: iccadastros,
        tab: "tab-cadastros",
        submenu: [
          { nome: "Empresa", path: "/empresas/" },
          /*{
            nome: "Cartão",
            tab: "cadastros-cartao",
            submenu: [
              { nome: "Cartão comanda", path: "/cartaocomanda/" },
              { nome: "Mensagem", path: "/mensagem/" }
            ]
          },
          */

          //{ nome: "Faixa de comissionamento", path: "/faixacomissionamento/" },
          { nome: "Grupo de clientes", path: "/grupoClientes/" },
          { nome: "Almoxarifado", path: "/almoxarifado/" },
          // { nome: "Intervenção técnica", path: "/intervencaoTecnica/" },
          { nome: "Pessoas", path: "/pessoas/" },
          //{ nome: "Tanques", path: "/tanque/" },
          //{ nome: "bombas", path: "/bomba/"},
          //{ nome: "Bicos", path: "/bico/" },
          { nome: "Tanques, bombas e bicos", path: "/tanquebombabico/" }
          
          
          // { nome: "Intervenção técnica", path: "/intervencaoTecnica/" },
        ]
      },

      {
        nome: "Financeiro",
        img: icfinanceiro,
        tab: "tab-financeiro",
        submenu: [
          { nome: "Centros Monetários ", path: "/centrosMonetarios/" },
          //{ nome: "Bancos", path: "/bancos/"},
          { nome: "Contas", path: "/contas/" },
          { nome: "Formas de Pagamento", path: "/formaspagamento/" },
          { nome: "Troco", path: "/troco/" }
        ]
      },

      {
        nome: "Estoque",
        img: icestoque,
        tab: "tab-estoque",
        submenu: [{ nome: "Módulos", path: "/empresa/" }]
      },

      {
        nome: "Compras",
        img: iccompras,
        tab: "tab-compras",
        submenu: [{ nome: "Módulos", path: "" }]
      },

      {
        nome: "Consultas",
        img: icconsultas,
        tab: "tab-consultas",
        submenu: [{ nome: "Módulos", path: "" }]
      },

      {
        nome: "Relatórios",
        img: icrelatorios,
        tab: "tab-relatorios",
        submenu: [{ nome: "Módulos", path: "" }]
      },

      {
        nome: "Gráficos",
        img: icgraficos,
        tab: "tab-graficos",
        submenu: [{ nome: "Módulos", path: "" }]
      }
    ]
  };

  openMenu = evt => {
    const tabID = evt.currentTarget.dataset.tab;
    this.setState({ active: true, activeItem: tabID });
  };

  closeMenu = () => {
    this.setState({ active: false, activeItem: null });
  };

  handleSubmenu = evt => {
    const { currentTarget } = evt;
    if (currentTarget.classList.contains("subnivel")) {
      if (this.state.activeSubMenu === null) {
        this.setState({ activeSubMenu: currentTarget.dataset.tab });
      } else {
        this.setState({ activeSubMenu: null });
      }
    }
  };
  render() {
    const { active, activeItem, activeSubMenu } = this.state;
    return (
      <nav className="sidebar-nav">
        <div className="sidebar-nav-head">
          <img src={logo} className="logo" />
          <div className="sidebar-nav-head-content">
            <img src={logomobile} className="logo" />
            <div className="bt">
              <img src={headeropen} className="open" />
              <img src={headerclose} className="close" />
            </div>
          </div>
        </div>

        <ul className={`sidebar-nav-list${active ? " active" : ""}`}>
          {this.state.menu.map(menu => {
            return (
              <li
                className={`sidebar-nav-item${
                  menu.tab === activeItem ? " active" : ""
                }`}
                key={menu.nome}
                data-tab={menu.tab}
                onClick={this.openMenu}
              >
                <img src={menu.img} className="ic" />
                <span>{menu.nome}</span>
              </li>
            );
          })}
        </ul>

        <div className={`sidebar-nav-subnivel${active ? " active" : ""}`}>
          {this.state.menu.map(menu => {
            return (
              <ul
                className={`sidebar-nav-subnivel-list${
                  menu.tab === activeItem ? " active" : ""
                }`}
                key={menu.tab}
                id={menu.tab}
              >
                <li
                  className="sidebar-nav-subnivel-item-head"
                  onClick={this.closeMenu}
                >
                  <img src={icclose} className="ic" />
                  <span>{menu.nome}</span>
                </li>
                {menu.submenu.map(sub => {
                  const children = sub.hasOwnProperty("submenu");
                  const subActive = activeSubMenu !== null;
                  const classSub = !subActive
                    ? ""
                    : activeSubMenu === sub.tab
                    ? " active"
                    : " hide";
                  return (
                    <li
                      key={sub.nome}
                      className={`sidebar-nav-subnivel-item${
                        children ? " subnivel" : ""
                      }${classSub}`}
                      data-tab={sub.tab}
                      data-path={sub.path}
                      onClick={this.handleSubmenu}
                    >
                      {sub.path ? (
                        <Link to={sub.path}>{sub.nome}</Link>
                      ) : (
                        <a>{sub.nome}</a>
                      )}
                      {children && (
                        <ul className={`sidebar-nab-subnivel-sub${classSub}`}>
                          {sub.submenu.map(sub => {
                            return (
                              <li
                                key={sub.nome}
                                data-path={sub.path}
                                onClick={this.handleSubmenu}
                              >
                                <Link style={{ color: "#FFF" }} to={sub.path}>
                                  {sub.nome}
                                </Link>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ul>
            );
          })}
        </div>
      </nav>
    );
  }
}

export class MenuMobile extends Component {
  render() {
    return (
      <div className="sidebar-nav-mobile">
        <div className="bt" id="showmenumobile">
          <img src={headeropen} />
        </div>
        <h2>Posto Fácil Web</h2>
        <img className="logo" src={logomobile} />
      </div>
    );
  }
}