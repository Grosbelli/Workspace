import React, { Component } from 'react';
import { Dropdown } from './../dropdown/Dropdown';
import imguser from '../img/bt-ic-usuario.png';

class FavButton extends Component {
  state = {active: false};

  toggleFav = () => {
	  this.setState({active: !this.state.active});
  }

  render() {
    return (
		<>
          <a className="header-bt" id="showfavoritos" onClick={this.toggleFav}>
            <div className="icon icon-lx-star"></div>
          </a>

		  <nav className={`sidebar-favoritos${this.state.active? " active":""}`}>
			<span className="sidebar-favoritos-title">Favoritos</span>
			<ul className="sidebar-favoritos-list">
			  <li className="sidebar-favoritos-item">
				<div className="sidebar-favoritos-item-content">
				  <img src={imguser} className="ic" />
				  <span>Financeiro</span>
				</div>
			  </li>
			  <li className="sidebar-favoritos-item">
				<div className="sidebar-favoritos-item-content">
				  <img src={imguser} className="ic" />
				  <span>Contas</span>
				</div>
			  </li>
			  <li className="sidebar-favoritos-item">
				<div className="sidebar-favoritos-item-content">
				  <img src={imguser} className="ic" />
				  <span>Gráficos</span>
				</div>
			  </li>
			  <li className="sidebar-favoritos-item">
				<div className="sidebar-favoritos-item-content">
				  <img src={imguser} className="ic" />
				  <span>Relatórios</span>
				</div>
			  </li>
			  <li className="sidebar-favoritos-item">
				<div className="sidebar-favoritos-item-content">
				  <img src={imguser} className="ic" />
				  <span>Despesas</span>
				</div>
			  </li>
			</ul>
		  </nav>
	  </>
    );
  }
}

export class MenuHeader extends Component {

  state = {active: false};

  toggleFav = () => {
	  this.setState({active: !this.state.active});
  }

  render() {
    return (
        <header className="header">
        <a className="header-bt" id="showmenu" onClick={this.toggleFav}>
          <div className="icon icon-lx-bars"></div>
        </a>
        <div className={`header-content${this.state.active? " active":""}`}>
		  <FavButton />
          <a className="header-bt">
            <div className="icon icon-lx-cash-register"></div>
            <span>Caixas</span>
          </a>
          <a className="header-bt">
            <div className="icon icon-lx-payments"></div>
            <span>Contas</span>
          </a>
          <a className="header-bt">
            <div className="icon icon-lx-basket"></div>
            <span>Produtos</span>
          </a>
          <a className="header-bt">
            <div className="icon icon-lx-question"></div>
            <span>DicaLinx</span>
          </a>
        </div>
        <div className="flex-right">
          <a className="header-bt right dropdown">
            <div className="icon icon-lx-user"></div>
            <span>Sérgio Vieira</span>
            <Dropdown>
              <span>Configurações</span>
              <span>Ajuda</span>
              <span>Sair</span>
            </Dropdown>
          </a>
          <a className="header-bt">
            <div className="icon icon-lx-question"></div>
          </a>
        </div>
      </header>
    );
  }
}
