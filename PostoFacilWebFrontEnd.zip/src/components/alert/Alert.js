import React, { Component } from "react";
import { Botao } from "./../botoes/Botao";
import { Modal, ModalBody, ModalHeader, ModalFooter } from "./../modal/Modal";
import icsuccess from "./../img/modal-alerta-ic-sucesso.png";
import icerro from "./../img/modal-alerta-ic-block.png";
import icalerta from "./../img/modal-alerta-ic-alerta.png";
import icquestion from "./../img/modal-alerta-ic-questao.png";

export const AlertType = {
    None: "",
    Success: "success",
    Error: "error",
    Alert: "alert",
    Question: "question",
    Cancel: "cancel",
    Recreate: "recreate"
}

export class Alert extends Component {
    renderSwitch(param) {
        const { title, subtitle, handleAction } = this.props;

        switch (param) {
            case "success":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icsuccess} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                secondary
                                icon="icon-lx-check"
                                title={"OK"}
                                onClick={handleAction}
                            />
                        </ModalFooter>
                    </div>
                );

            case "error":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icerro} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                secondary
                                icon="icon-lx-check"
                                title={"OK"}
                                onClick={handleAction}
                            />
                        </ModalFooter>
                    </div>
                );

            case "alert":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icalerta} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                secondary
                                icon="icon-lx-check"
                                title={"OK"}
                                onClick={handleAction}
                            />
                        </ModalFooter>
                    </div>
                );

            case "question":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icquestion} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                icon="icon-lx-check"
                                title={"Sim"}
                                onClick={() => {
                                    handleAction(true);
                                }}
                            />
                            <Botao
                                secondary
                                icon="icon-lx-close"
                                title={"Não"}
                                onClick={() => {
                                    handleAction(false);
                                }}
                            />

                        </ModalFooter>
                    </div>
                );

            case "cancel":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icquestion} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                icon="icon-lx-check"
                                title={"Sim"}
                                onClick={() => {
                                    handleAction(true);
                                }}
                            />
                            <Botao
                                secondary
                                icon="icon-lx-trash"
                                title={"Não"}
                                onClick={() => {
                                    handleAction(false);
                                }}
                            />
                        </ModalFooter>
                    </div>
                );

            case "recreate":
                return (
                    <div>
                        <ModalBody>
                            <AlertBody icon={icquestion} title={title} subtitle={subtitle} />
                        </ModalBody>
                        <ModalFooter>
                            <Botao
                                icon="icon-lx-check"
                                title={"Sim"}
                                onClick={() => {
                                    handleAction(true);
                                }}
                            />
                            <Botao
                                secondary
                                icon="icon-lx-trash"
                                title={"Não"}
                                onClick={() => {
                                    handleAction(false);
                                }}
                            />
                        </ModalFooter>
                    </div>
                );

            default:
                return <div>default</div>;
        }
    }

    render() {
        const { type, active, onRequestClose } = this.props;

        return (
            <Modal className={`${active ? "active" : null}`} onClose={onRequestClose}>
                {this.renderSwitch(type)}
            </Modal>
        );
    }
}

export class AlertBody extends Component {
    render() {
        const { icon, title, subtitle } = this.props;

        return (
            <div className="row modal-alert">
                <div className="icon">
                    <img src={icon} className="ic" />
                </div>
                <div className="body">
                    <h3 className="title">{title}</h3>
                    <span className="subtitle">{subtitle}</span>
                </div>
            </div>
        );
    }
}
