import React, { Component } from 'react';

export class Botao extends Component {

  render() {

      const {
          secondary, className, ic, icon, onClick 
      } = this.props;

    return (
        <button className={`button ${className} ${(secondary) ? 'secondary' : null} ${(ic) ? 'ic' : null}`} onClick={onClick}>
            {this.props.title}
            <div className={`icon ${icon}`} />
        </button>
    );
  }
}
