import React, { Component } from 'react';
import add from './../../img/button-ic-add.png';
import check from './../../img/button-ic-check.png';
import edit from './../../img/button-ic-edit.png';
import lixo from './../../img/button-ic-lixo.png';


export { add }
export { check }
export { edit }
export { lixo }