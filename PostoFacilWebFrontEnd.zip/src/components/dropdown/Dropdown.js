import React, { Component } from 'react';

/* Usar classe dropdown no elemento 'Pai', ex: <div className="test dropdown"> ... </div> */

export class Dropdown extends React.Component {
    render() {
        return (
            <div className="dropdown-menu">
                {this.props.children.map((elmt, index) => {
                    return <div key={index} className="dropdown-item" onClick={this.props.onClick}>{elmt}</div>
                })}
            </div>
        );
    }
}