import React, { Component } from "react";
import NumberFormat from 'react-number-format';
import MultiSelect from "@khanacademy/react-multi-select";
import TimeField from "./TimeField";

import { Botao } from "../botoes/Botao";
import { AsYouType } from 'libphonenumber-js';
import "react-dates/initialize";
import SingleDatePicker from "./react-dates/SingleDatePicker";
import "react-dates/lib/css/_datepicker.css";
import moment from "moment";
import "moment/locale/pt-br";

moment.locale("pt-br");

export function handleInputChange(event) {
    let value, name;
    if (event.hasOwnProperty("target")) {
        // inputs comuns
        const target = event.target;
        value = target.type === "checkbox" ? target.checked : target.value;
        name = target.name;
    } else if (event.hasOwnProperty("floatValue")) {
        // input react-number-format
        value = event.format === null ? event.floatValue : event.value;
        name = event.name;
    } else if (event.hasOwnProperty("date")) {
        // react-date...
        value = event.date ? event.date.format("YYYY-MM-DD") : null;
        name = event.name;
    } else {
        // multi-select, TimeField...
        value = event.hasOwnProperty("selected") ? event.selected : event.value;
        name = event.name;
    }

    this.setState({
        [name]: value
    });
}

export function formatPhoneNumber(number) {
    return new AsYouType("BR").input(number);
}

export class InputText extends Component {
    render() {
        const {
            label,
            placeholder,
            icone,
            onIconeClick,
            help,
            type = "text",
            name,
            value,
            onChange,
            disabled = false,
            required = false,
            decimalScale = 2,
            allowNegative = false,
            format = null,
            mask = " ",
            autofocus,
            maxlength,
            tabindex,
            onBlur,
            onKeyDown,
            onPaste,
            inputRef,
            id
        } = this.props;

        return (
            <div className={`form-input ${icone ? "has-bt" : null}`}>
                {type !== "number" ?
                    <input
                        type={type}
                        className="input"
                        placeholder={placeholder}
                        disabled={disabled}
                        required={required}
                        name={name}
                        value={value}
                        onChange={onChange}
                        onBlur={onBlur}
                        maxlength={maxlength}
                        onKeyDown={onKeyDown}
                        onPaste={onPaste}
                        ref={inputRef}
                        id={id || name}
                    /> :
                    <NumberFormat
                        decimalSeparator=","
                        decimalScale={decimalScale}
                        className="input"
                        placeholder={placeholder}
                        allowNegative={allowNegative}
                        disabled={disabled}
                        required={required}
                        name={name}
                        value={value}
                        format={format}
                        mask={mask}
                        maxlength={maxlength}
                        onKeyDown={onKeyDown}
                        onBlur={onBlur}
                        onValueChange={(values) => onChange({ ...values, name, format })}
                        inputRef={inputRef}
                        id={id || name}
                    />
                }

                {label && <span className="input-label">{label}</span>}

                {icone && (
                    <div className="input-bt" {...(onIconeClick? {onClick: onIconeClick}: {})}>
                        <div className={`icon ${icone}`} />
                    </div>
                )}

                {help && <span className="help">{help}</span>}
            </div>
        );
    }
}

const customFilter = (options, filter) => {
    const optionIncludesText = (option) => {
        const label = option.label || "";
        return label.toLowerCase().includes(filter.toLowerCase());
    };

    return options.filter(optionIncludesText);
};

export class Select extends Component {
    render() {
        const {
            label,
            icone,
            onIconeClick,
            help,
            name,
            value,
            options = [],
            onChange,
            multi = false,
            autofocus,
            tabindex,
            disabled,
            onBlur
        } = this.props;

        return (
            <div className={`form-input ${icone ? "has-bt" : null}`}>
                {!multi ?
                    <select
                        className="input"
                        name={name}
                        value={value}
                        onChange={onChange}
                        disabled={disabled}
                        onBlur={onBlur}
                    >
                        {options.map((option) => {
                            const [v, label] = option.hasOwnProperty("value") ? [option.value, option.label] : [option, option];
                            return (
                                <option value={v}>{label}</option>
                            )
                        })}
                    </select>
                    :
                    <MultiSelect
                        {...this.props}
                        selected={value}
                        onSelectedChanged={(selected) => onChange({ selected, name })}
                        filterOptions={customFilter}
                        overrideStrings={{
                            selectSomeItems: "Selecionar...",
                            allItemsAreSelected: "Todos os items",
                            selectAll: "Selecionar todos",
                            search: "Pesquisar",
                        }}
                        disabled={disabled}
                    />}
                {label && <span className="input-label">{label}</span>}

                {icone && (
                    <div className="input-bt" {...(onIconeClick? {onClick: onIconeClick}: {})}>
                        <div className={`icon ${icone}`} />
                    </div>
                )}

                {help && <span className="help">{help}</span>}
            </div>
        );
    }
}

export class InputDate extends Component {
    state = { date: null, focused: false };

    render() {
        const {
            label,
            icone,
            onIconeClick,
            help,
            value,
            name,
            onChange,
            onFocus,
            withPortal
        } = this.props;
        return (
            <div className={`form-input ${icone ? "has-bt" : null}`}>
                <SingleDatePicker
                    isOutsideRange={() => false}
                    date={value ? moment(value) : null} // momentPropTypes.momentObj or null
                    onDateChange={date => { onChange({ date, name }) }} // PropTypes.func.isRequired
                    focused={this.state.focused} // PropTypes.bool                                   
                    onFocusChange={({ focused }) => {
                        this.setState({ focused })
                        if (onFocus != null) {
                            onFocus(focused);
                        }
                    }
                    } // PropTypes.func.isRequired
                    numberOfMonths={1}
                    id={name} // PropTypes.string.isRequired,
                    withPortal={withPortal}
                />

                {label && <span className="input-label">{label}</span>}

                {icone && (
                    <div className="input-bt" {...(onIconeClick? {onClick: onIconeClick}: {})}>
                        <div className={`icon ${icone}`} />
                    </div>
                )}

                {help && <span className="help">{help}</span>}
            </div>
        );
    }
}

export class InputTime extends Component {
    render() {
        const {
            label,
            placeholder,
            icone,
            onIconeClick,
            help,
            name,
            value,
            onChange,
            showSeconds = false,
            inputRef,
            id
        } = this.props;


        return (
            <div className={`form-input ${icone ? "has-bt" : null}`}>
                <TimeField
                    className="input"
                    value={value}
                    name={name}
                    placeholder={placeholder}
                    onChange={onChange}
                    style={{ width: "100%" }}
                    showSeconds={showSeconds}
                    ref={inputRef}
                    id={id || name}
                />
                {label && <span className="input-label">{label}</span>}

                {icone && (
                    <div className="input-bt" {...(onIconeClick? {onClick: onIconeClick}: {})}>
                        <div className={`icon ${icone}`} />
                    </div>
                )}

                {help && <span className="help">{help}</span>}
            </div>
        );
    }
}

export class Checkbox extends Component {
    render() {
        const { label } = this.props;

        return (
            <div className="form-input">
                <div className="input hascheckbox">{this.props.children}</div>

                {label && <label className="input-label">{label}</label>}
            </div>
        );
    }
}

export class Checkitem extends Component {
    render() {
        const { label, name, checked, onChange, disabled = false } = this.props;

        return (
            <label className="checkbox-label">
                <input
                    type="checkbox"
                    className="checkboxinput"
                    name={name}
                    checked={checked}
                    onChange={onChange}
                    disabled={disabled}
                />
                <div className="checkbox"></div>
                <span className="label">{label}</span>
            </label>
        );
    }
}

export class FormOptions extends Component {
    /* Rodape de um form contendo botões para salvar, cancelar, excluir... */

    render() {
        const { handleSalvar, handleAdicionar, handleExcluir, handleCancelar } = this.props;
        return (
            <div className="section-footer">
                {handleSalvar && (
                    <Botao
                        secondary
                        icon="icon-lx-check"
                        title={"Salvar"}
                        onClick={handleSalvar}
                    />
                )}
                {handleAdicionar && (
                    <Botao
                        className="right"
                        icon="icon-lx-plus"
                        title={"Adicionar"}
                        onClick={handleAdicionar}
                    />
                )}
                {handleExcluir && (
                    <Botao
                        icon="icon-lx-trash"
                        title={"Excluir"}
                        onClick={handleExcluir}
                    />
                )}
                {handleCancelar && (
                    <Botao
                        icon="icon-lx-close"
                        title={"Cancelar"}
                        onClick={handleCancelar}
                    />
                )}
            </div>
        );
    }
}


export class StatusIndicator extends Component {

    render() {

        const {
            status, className = "",
        } = this.props;
        const icon = status ? "icon-lx-close" : "icon-lx-check";

        return (
            <div className={`status-button ${className} ${(status) ? "true" : ""}`}>
                <div className={`icon ${icon}`} />
            </div>
        );
    }
}

export class MessageInLine extends Component {
    render() {
        const {
            message = "",
            visible = true
        } = this.props;

        return (
            <>
                {visible ?
                    <div className="row" >
                        {message}
                    </div>
                    :
                    <div className="content-hidden" >
                        {message}
                    </div>
                }
            </>
        );
    }
}