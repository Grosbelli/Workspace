import React, { Component } from 'react';
import './css/main.css';
import './css/icones.css';
import './css/normalize.css';
import jQuery from 'jquery';
import { Menu, MenuMobile } from './menu/Menu';
import { MenuHeader } from './menu/MenuHeader';


class App extends Component {

  componentWillMount() {
    window.$=window.jQuery = jQuery;
    require('../js/main.js');

  }

  render() {
    return ([
      <div className="body-content">
        <MenuMobile />
        <Menu />
        <div className="body-container">
          
		      {this.props.screen}
        </div>
    </div>,

    <div className="modal-bg"></div>
    ]);
  }
}

export default App;
