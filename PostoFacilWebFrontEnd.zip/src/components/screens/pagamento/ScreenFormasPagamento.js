import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import {
    InputText,
    Checkbox,
    Checkitem,
    Select,
    FormOptions,
    handleInputChange,
    MessageInLine
} from "../../formulario/Formulario";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";
import { Botao } from "../../botoes/Botao";
import { List } from "../../formulario/List";

import {
    getFormasPagamento,
    incluiFormaPagamento,
    alteraFormaPagamento,
    excluiFormaPagamento
} from "../../../services/FormasPagamento";

const Pagamento = {
    AVista: "1",
    APrazo: "2"
};

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            descricao = "",

            tipo = {},
            tipoCodigo = 0,
            tipoDescricao = "",
            codigoSefaz = "",
            permiteParcelamento = true,

            avisoSangria = true,
            interna = false,

            opcoesPagamento = {},
            opcoesPagamentoCodigo = Pagamento.AVista,
            //opcoesPagamentoDescricao = "À vista",

            parcelamento = {},
            numeroParcelas,
            carenciaPrimeiraParcela,
            primeiraParcelaMaior = false,
            periodicidade,
            juros,
            diasCorridos = true,

            inativo = false,
            rowVersion = null,
            diaRecebimento = 1
        } = this.props.forma;

        this.state = {
            codigo,
            descricao,
            ativo: !inativo,
            interna,

            tipo,
            tipoCodigo,
            tipoDescricao,
            codigoSefaz,
            permiteParcelamento,
            tipos: [],

            avisoSangria,

            opcoesPagamento,
            opcoesPagamentoCodigo,
            //opcoesPagamentoDescricao,
            pagamentos: [],

            parcelamento,
            numeroParcelas,
            carenciaPrimeiraParcela,
            primeiraParcelaMaior,
            periodicidade,
            juros,
            diasCorridos,

            rowVersion,
            diaRecebimento,

            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: "",

            formasExistentes: [],
            formaSel: []
        };

    }

    getCodigoSefazByTipo(codigoTipo) {
        switch (codigoTipo) {
            case "1": return "01";
            case "2": return "02";
            case "4": return "03";
            case "6": return "05";
            case "7": return "04";
            default: return "99";
        }
    }

    handleTipoPagamentoChange = (event) => {
        let tipo = this.state.tipo;
        tipo.codigo = event.target.value;
        tipo.codigoSefaz = this.getCodigoSefazByTipo(tipo.codigo);
        let codigoSefaz = tipo.codigoSefaz;

        let { opcoesPagamento, opcoesPagamentoCodigo } = this.state;
        if (!this.tipoPermiteParcelamento() &&
            (String(opcoesPagamento.codigo) === Pagamento.APrazo ||
                String(opcoesPagamentoCodigo) === Pagamento.APrazo)) {
            opcoesPagamento.codigo = Pagamento.AVista;
            opcoesPagamentoCodigo = opcoesPagamento.codigo;
        }
        this.setState({
            tipo,
            codigoSefaz,
            opcoesPagamento,
            opcoesPagamentoCodigo
        });
    }

    handlePeriodoChange = (event) => {
        let parcelamento = this.state.parcelamento;
        parcelamento.diasCorridos = event.target.value === "true"; // string escrito true        
        let periodicidade = !parcelamento.diasCorridos ? 1 :
            this.state.periodicidade;
        parcelamento.periodicidade = periodicidade;
        this.setState({ parcelamento, periodicidade });
    }

    handleOpcoesPagamentoChange = (event) => {
        let opcoesPagamento = this.state.opcoesPagamento;
        opcoesPagamento.codigo = event.target.value;
        let opcoesPagamentoCodigo = opcoesPagamento.codigo;
        this.setState({ opcoesPagamento, opcoesPagamentoCodigo });
    }

    handleNumeroParcelasChange = (event) => {
        let parcelamento = this.state.parcelamento;
        parcelamento.numeroParcelas = event.floatValue;
        let numeroParcelas = parcelamento.numeroParcelas;
        this.setState({ parcelamento, numeroParcelas });
    }

    handlePrimeiraParcelaMaiorChange = (event) => {
        let parcelamento = this.state.parcelamento;

        parcelamento.primeiraParcelaMaior = event.target.checked;
        let primeiraParcelaMaior = parcelamento.primeiraParcelaMaior;
        this.setState({ parcelamento, primeiraParcelaMaior });
    }

    handleCarenciaPrimeiraParcela = (event) => {
        let parcelamento = this.state.parcelamento;
        parcelamento.carenciaPrimeiraParcela = event.floatValue;
        let carenciaPrimeiraParcela = parcelamento.carenciaPrimeiraParcela;
        this.setState({ parcelamento, carenciaPrimeiraParcela });
    }

    handlePeriodicidadeChange = (event) => {
        let parcelamento = this.state.parcelamento;
        parcelamento.periodicidade = event.floatValue;
        let periodicidade = parcelamento.periodicidade;
        this.setState({ parcelamento, periodicidade });
    }

    handleJurosChange = (event) => {
        let parcelamento = this.state.parcelamento;
        parcelamento.juros = event.floatValue;
        let juros = parcelamento.juros;
        this.setState({ parcelamento, juros });
    }

    tipoPermiteParcelamento() {
        const { tipo, tipoCodigo } = this.state;
        let value = (tipo.codigo ? tipo.codigo : tipoCodigo);
        switch (Number(value)) {
            case 2: return true; // cheque
            case 4: return true; // crédito
            case 6: return true; // a faturar
            case 7: return true; // débito           
            default: return false;
        }
    }

    isParcelavel() {
        const { opcoesPagamento } = this.state;
        return (String(opcoesPagamento.codigo) === Pagamento.APrazo &&
            this.tipoPermiteParcelamento());
    }

    isFormValid() {
        if (this.state.interna) {
            return true; // interna só altera status e sangria, campos booleanos
        }

        if (!this.state.descricao) {
            this.showError("É obrigatório informar uma descrição.");
            return false;
        }

        if (this.state.diaRecebimento && (this.state.diaRecebimento < 1 ||
            this.state.diaRecebimento > 30)) {
            this.showError("O dia de recebimento deve ser entre 1 e 30.");
            return false;
        }

        if (!this.state.opcoesPagamento) {
            const opcoesPagamentoCodigo = this.state.opcoesPagamentoCodigo;
            if (String(opcoesPagamentoCodigo) === Pagamento.AVista)
                return true; // não precisa validar parcelamento pois é à vista
        }
        else {
            const opcoesPagamento = this.state.opcoesPagamento;
            if (String(opcoesPagamento.codigo) === Pagamento.AVista)
                return true; // não invente de dar return false aqui!
        }

        const parcelamento = this.state.parcelamento;
        if (parcelamento) { // validações se é parcelado
            if (!parcelamento.numeroParcelas ||
                parcelamento.numeroParcelas < 1 ||
                parcelamento.numeroParcelas > 99) {
                this.showError("O número de parcelas deve ser entre 1 e 99.");
                return false;
            }

            if (!parcelamento.carenciaPrimeiraParcela ||
                parcelamento.carenciaPrimeiraParcela < 0 ||
                parcelamento.carenciaPrimeiraParcela > 99) {
                this.showError("O número de dias de vencimento da primeira " +
                    "parcela deve ser entre 0 e 99.");
                return false;
            }

            if (!parcelamento.periodicidade ||
                parcelamento.periodicidade < 1 ||
                parcelamento.periodicidade > 30) {
                this.showError("O número de dias corridos deve ser entre" +
                    " 1 e 30.");
                return false;
            }

            if (parcelamento.juros && (
                parcelamento.juros < 0 ||
                parcelamento.juros > 99.99)) {
                this.showError("O percentual de juros deve ser entre" +
                    "0 e 99,99.");
                return false;
            }
        }
        return true;
    }

    clearParcelamento() {
        const { parcelamento } = this.state;
        parcelamento.numeroParcelas = 1;
        parcelamento.carenciaPrimeiraParcela = 0;
        parcelamento.primeiraParcelaMaior = false;
        parcelamento.periodicidade = 0;
        parcelamento.diasCorridos = true;
        parcelamento.juros = 0;
        this.setState({ parcelamento });
    }

    handleSalvar = async () => {
        let {
            codigo,
            descricao,
            ativo,
            interna,
            tipo,
            avisoSangria,
            opcoesPagamento,
            //opcoesPagamentoCodigo,
            parcelamento,
            //periodicidade,
            diaRecebimento,
            rowVersion,
        } = this.state;

        if (!this.isFormValid()) {
            return;
        }

        //parcelamento.periodicidade = periodicidade;
        //
        //opcoesPagamento.codigo = opcoesPagamentoCodigo;
        let inativo = !ativo;
        // debugger;
        if (opcoesPagamento.codigo === Pagamento.AVista)
            this.clearParcelamento();

        const [action, params] =
            rowVersion === null
                ? [
                    incluiFormaPagamento,
                    [
                        descricao,
                        tipo,
                        avisoSangria,
                        interna,
                        opcoesPagamento,
                        parcelamento,
                        inativo,
                        diaRecebimento
                    ]
                ]
                : [
                    alteraFormaPagamento,
                    [
                        codigo,
                        descricao,
                        tipo,
                        avisoSangria,
                        interna,
                        opcoesPagamento,
                        parcelamento,
                        inativo,
                        diaRecebimento,
                        rowVersion
                    ]
                ];

        try {
            await action(...params);
            this.showInfo(`Forma de pagamento ${rowVersion === null ?
                "incluída" : "alterada"} com sucesso!`);
        } catch (err) {
            this.showInfo(err.response.data.message);
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Formas de pagamento",
            alertSubtitle: message
        });
    }

    handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Formas de pagamento",
            alertSubtitle: "Deseja excluir?"
        });
    };

    handleBlur = (event) => {
        return;
    };

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Formas de pagamento",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    };

    async componentDidMount() {
        const periodos = [];
        periodos.push({ label: "Dias corridos", value: true });
        periodos.push({ label: "Mês comercial", value: false });

        const pagamentos = [];
        pagamentos.push({ label: "À vista", value: 1 });
        pagamentos.push({ label: "A prazo", value: 2 });

        const tipos = [];
        if (this.state.rowVersion && this.state.interna) {
            tipos.push({
                label: this.state.tipo.descricao,
                value: this.state.tipo.codigo
            });
        }
        else {
            tipos.push({ label: "Cheque", value: 2 });
            tipos.push({ label: "Crachá", value: 8 });
            tipos.push({ label: "CTF", value: 9 });
            tipos.push({ label: "Ticket", value: 3 });
            tipos.push({ label: "Vale", value: 5 });
        };
        this.setState({ periodos, pagamentos, tipos });

        if (!this.state.rowVersion) { // abriu para inserir um novo
            const tipo = {};
            tipo.codigoSefaz = this.getCodigoSefazByTipo("2");
            tipo.codigo = 2;

            const parcelamento = {};
            //parcelamento.periodicidade = 1;            
            parcelamento.diasCorridos = true;

            const opcoesPagamento = {};
            opcoesPagamento.codigo = "1";

            this.setState({ tipo, parcelamento, opcoesPagamento });
        }
    }

    handleAlertAction = async (resp) => {
        const {
            alertType,
            codigo
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/formaspagamento/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluiFormaPagamento(codigo);
                        this.showInfo("Forma de pagamento excluída com sucesso!");
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/formaspagamento/");
                }
                break;
            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Formas de pagamento",
            alertSubtitle: message
        });
    }

    render() {
        const {
            //codigo,
            descricao,
            ativo,
            interna,
            tipo,
            //tipoCodigo,
            //tipoDescricao,
           // codigoSefaz,
            //permiteParcelamento,
            tipos,
            avisoSangria,
            opcoesPagamento,
            //opcoesPagamentoCodigo,
            //opcoesPagamentoDescricao,
            parcelamento,
            pagamentos,
            periodos,
            diaRecebimento,
           // periodicidade,
            rowVersion,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;

        return (
            <>
                <SectionContainer>
                    <SectionContent title="Formas de pagamento" accordion>
                        <MessageInLine
                            message={"Registro interno, apenas as informações" +
                                " de sangria e status poderão ser modificadas."}
                            visible={interna}
                        />
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Descrição:"
                                    value={descricao}
                                    name="descricao"
                                    disabled={interna}
                                    //
                                    //onBlur={this.handleBlur}
                                    onChange={this.handleInputChange}
                                    maxlength={100}
                                    tabindex={1}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Select
                                    label="Tipo:"
                                    name="tipo.codigo"
                                    value={tipo.codigo}
                                    onChange={this.handleTipoPagamentoChange}
                                    options={tipos}

                                    disabled={interna}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Código SEFAZ:"
                                    value={tipo.codigoSefaz}
                                    name="tipo.codigoSefaz"
                                    onChange={this.handleInputChange}

                                    disabled
                                    maxlength={2}
                                    tabindex={4}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                            <div className="col-5">
                                <Checkbox label="Considerar esta forma de pagamento no aviso de sangria:">
                                    <Checkitem
                                        label=""
                                        name="avisoSangria"
                                        checked={avisoSangria}
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Select
                                    label="Pagamento:"
                                    name="opcoesPagamento.codigo"
                                    value={opcoesPagamento.codigo}
                                    onChange={this.handleOpcoesPagamentoChange}
                                    options={pagamentos}
                                    disabled={interna || !this.tipoPermiteParcelamento()}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Dia previsto de recebimento:"
                                    value={diaRecebimento}
                                    name="diaRecebimento"
                                    type="number"
                                    maxlength={2}
                                    decimalScale={0}
                                    allowNegative={false}
                                    onChange={this.handleInputChange}
                                    disabled={interna}
                                />
                            </div>
                        </div>
                    </SectionContent>

                    <SectionContent
                        title="Parcelamento"
                        accordion
                        visible={this.isParcelavel()}
                    >
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="Número de parcelas:"
                                    value={parcelamento.numeroParcelas}
                                    name="parcelamento.numeroParcelas"
                                    type="number"
                                    maxlength={2}
                                    decimalScale={0}
                                    allowNegative={false}
                                    onChange={this.handleNumeroParcelasChange}
                                    disabled={interna}
                                />
                            </div>
                            <div className="col-12">
                                <Checkbox label="Primeira parcela terá o maior valor:">
                                    <Checkitem
                                        label=""
                                        name="parcelamento.primeiraParcelaMaior"
                                        checked={parcelamento.primeiraParcelaMaior}
                                        onChange={this.handlePrimeiraParcelaMaiorChange}
                                        disabled={interna}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Número de dias para vencimento da 1ª parcela:"
                                    value={parcelamento.carenciaPrimeiraParcela}
                                    name="parcelamento.carenciaPrimeiraParcela"
                                    type="number"
                                    maxlength={2}
                                    decimalScale={0}
                                    allowNegative={false}
                                    onChange={this.handleCarenciaPrimeiraParcela}
                                    disabled={interna}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Select
                                    label="Período:"
                                    name="parcelamento.diasCorridos"
                                    value={parcelamento.diasCorridos}
                                    onChange={this.handlePeriodoChange}
                                    options={periodos}
                                    disabled={interna}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Periodicidade das parcelas:"
                                    value={parcelamento.periodicidade}
                                    //value={periodicidade}
                                    name="parcelamento.periodicidade"
                                    //name="periodicidade"
                                    type="number"
                                    maxlength={2}
                                    decimalScale={0}
                                    allowNegative={false}
                                    onChange={this.handlePeriodicidadeChange}
                                    disabled={interna || !parcelamento.diasCorridos}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Juros:"
                                    value={parcelamento.juros}
                                    name="parcelamento.juros"
                                    type="number"
                                    maxlength={5}
                                    decimalScale={2}
                                    allowNegative={false}
                                    onChange={this.handleJurosChange}
                                    disabled={interna}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={(interna || rowVersion === null) ?
                        null : this.handleExcluir}
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }

}

Form = withRouter(Form);

class ScreenFormasPagamento extends Component {
    state = {
        formas: [],
        formaSel: {},
        telaDisponivel: false,
        codigo: 0
    };

    async doMount() {
        const { data: frm } = await getFormasPagamento(false, true);
        this.setState({
            formas: frm.result,
            telaDisponivel: true
        });
    }

    componentDidMount() {
        this.doMount();
    }

    componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            this.doMount();
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        try {
            if (this.state.telaDisponivel && rowInfo) {
                this.setState({ formaSel: rowInfo.original });
                this.props.history.push("/formaspagamento/new");
            }
        } catch (error) {
            console.log(error.message);
        }
    }

    render() {
        const { edit } = this.props,
            { formaSel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Formas de Pagamento"
                        subtitle=""
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ formaSel: {} });
                                            this.props.history.push("/formaspagamento/new")
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form
                            forma={formaSel}
                            formasExistentes={this.state.formas}
                        />
                    ) : (
                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "descricao",
                                        Header: "Descrição",
                                        width: 600,
                                        filterable: false
                                    },
                                    {
                                        accessor: "inativo",
                                        Header: "Ativo",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={row.inativo}
                                                    ic
                                                    icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.formas}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenFormasPagamento = withRouter(ScreenFormasPagamento);
export { ScreenFormasPagamento };