import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Select,
    Checkbox,
    Checkitem,
    FormOptions,
    handleInputChange,
    InputDate,
    InputTime
} from "../../formulario/Formulario";
import { List, sortInt } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getBicos,
    incluirBico,
    alterarBico,
    excluirBico,
    montarComboTanque,
    montarComboBomba,
    montarComboListaPrecos
} from "../../../services/Bico";

import {
    getBancos
} from "../../../services/Bancos";

import { toFloatFormattedDisplay } from "../../../utils/Utils";
import moment from "moment";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigoBico,
            codigoTanque,
            codigoBomba,
            numeroSequencial,
            numeroBicoNaBomba,
            codigoNivelPreco,
            permiteAbastecimentoManual = true,
            possuiMovimentacaoEstoque = false,
            numeroHexa,
            dataAtivacao = moment(),
            inativo = false,
            rowVersion = null,
        } = this.props.Bico,
            dataAlteracao = moment().format("YYYY-MM-DD"),
            horaAlteracao = moment().format("HH:mm:ss"),
            motivoAlteracao = "";



        this.state = {
            codigoBico,
            codigoTanque,
            codigoBomba,
            numeroSequencial,
            numeroBicoNaBomba,
            codigoNivelPreco,
            permiteAbastecimentoManual,
            possuiMovimentacaoEstoque,
            numeroHexa,
            dataAtivacao,
            ativo: !inativo,

            dataAlteracao,
            horaAlteracao,
            motivoAlteracao,

            rowVersion,
            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            bicosExistentes: this.props.bicosExistentes,
            tanques: this.props.tanques

        };
    }

    validaDataEscolhida = () => {
        var dataValida = false;
        dataValida = moment(this.state.dataAtivacao, "YYYY-MM-DD").isValid();
        return dataValida;
    }

    async componentDidMount() {
        var tanques = this.state.tanques;

        this.setState({
            tanquesLista: tanques === null ? [] :
                (tanques.map(tanque => { return { label: tanque.descricao, value: tanque.codigo } })),
            codigoTanque: this.state.codigoTanque === undefined ? tanques[0].codigo : this.state.codigoTanque
        })

        var ct = this.state.codigoTanque === undefined ? tanques[0].codigo : this.state.codigoTanque;
        this.buscaListaPrecos(ct);


        const { data: bombas } = await montarComboBomba();
        this.setState({
            bombasLista: bombas === null ? [] :
                (bombas.map(bomba => { return { label: bomba.descricao, value: bomba.codigo } })),
            codigoBomba: this.state.codigoBomba === undefined ? bombas[0].codigo : this.state.codigoBomba
        })
    }

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoBico
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/tanquebombabico/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluirBico(codigoBico);
                        //sucesso
                        console.log("sucesso");
                        this.showInfo("Bico excluído com sucesso!");
                    } catch (err) {
                        // falha
                        console.log("fallha");
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/tanquebombabico/");
                }
                break;


            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Bico",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {

            codigoBico,
            codigoTanque,
            codigoBomba,
            numeroSequencial,
            numeroBicoNaBomba,
            codigoNivelPreco,
            permiteAbastecimentoManual,
            possuiMovimentacaoEstoque,
            numeroHexa,
            dataAtivacao,
            rowVersion,
            ativo,
            dataAlteracao,
            horaAlteracao,
            motivoAlteracao,

        } = this.state,
            inativo = !ativo;

        const [action, params] =
            rowVersion !== null
                ? [
                    alterarBico,
                    [
                        codigoBico,
                        codigoTanque,
                        codigoBomba,
                        numeroSequencial,
                        numeroBicoNaBomba,
                        codigoNivelPreco,
                        permiteAbastecimentoManual,
                        numeroHexa,
                        dataAtivacao,
                        inativo,
                        rowVersion
                    ]
                ]
                : [
                    incluirBico,
                    [

                        codigoTanque,
                        codigoBomba,
                        numeroSequencial,
                        numeroBicoNaBomba,
                        codigoNivelPreco,
                        permiteAbastecimentoManual,
                        numeroHexa,
                        dataAtivacao
                    ]
                ];

        let temErros = this.verificaBico();

        if (!temErros) {
            temErros = this.verificaBicoExistente(numeroSequencial);
        }

        if (!temErros) {

            try {
                const resp = await action(...params);
                console.log(resp);
                this.setState({
                    alertActive: true,
                    alertType: "success",
                    alertTitle: "Bicos",
                    alertSubtitle: `Bico  ${rowVersion === null ? "cadastrado" : "alterado"} com sucesso!`
                });
            } catch (err) {
                this.setState({
                    alertActive: true,
                    alertType: "error",
                    alertTitle: "Erro",
                    alertSubtitle: err.response.data.message
                });
            }
        }
    };

    handleExcluir = () => {
        console.log("excluir");
        var temErros = false;

        if (this.state.possuiMovimentacaoEstoque) {
            this.showError("O bico não pode ser excluído, pois tem movimentação de estoque.");
            temErros = true;
        }

        if (!temErros)

            this.setState({
                alertActive: true,
                alertType: "question",
                alertTitle: "Bicos",
                alertSubtitle: "Confirma a exclusão do Bico?"
            });
    }

    handleCancelar = () => {
        console.log("cancelar");
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Bicos",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    buscaListaPrecos = async (codigoTanque) => {
        console.log("ct " + codigoTanque);
        console.log("cnp " + this.state.codigoNivelPreco);

        const { data: precos } = await montarComboListaPrecos(codigoTanque);

        this.setState({
            listaPrecos: precos === null ? [] :
                (precos.map(preco => { return { label: preco.descricao, value: preco.codigo } })),
            codigoNivelPreco: this.state.codigoNivelPreco === undefined ? precos[0].codigo : this.state.codigoNivelPreco
        })
        console.log("cnp1" + this.state.codigoNivelPreco);
    }

    handleTanqueChange = (e) => {
        var codigoTanque = e.target.value;
        this.buscaListaPrecos(codigoTanque);
        this.setState({ codigoTanque });
    }

    verificaBico = () => {
        //verifica preenchimento dos campos   

        var temErros = false;

        if (this.state.numeroSequencial < 1 || this.state.numeroSequencial > 99) {
            this.showError("Número sequencial do bico deve ser entre 1 e 99.");
            temErros = true;
        }

        if (temErros)
            return temErros;


        if (!this.state.numeroSequencial) {
            this.showError("É necessário informar o número sequencial do bico.");
            temErros = true;
        }

        if (temErros)
            return temErros;


        if (!this.state.numeroBicoNaBomba) {
            this.showError("É necessário informar o número do bico na bomba.");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (this.state.numeroBicoNaBomba < 1 || this.state.numeroBicoNaBomba > 4) {
            this.showError("Número do bico na bomba deve ser entre 1 e 4.");
            temErros = true;
        }

        if (temErros)
            return temErros;


        if (!this.validaDataEscolhida()) {
            this.showError("Campo Data de Ativação deve ser uma data válida");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (this.state.rowVersion) {
            if (!moment(this.state.dataAlteracao, "YYYY-MM-DD").isValid()) {
                this.showError("Data de alteração inválida");
                return true;
            }
            if (moment(this.state.dataAlteracao, "YYYY-MM-DD") < moment(this.state.dataAtivacao, "YYYY-MM-DD")) {
                this.showError("A data de alteração deve ser igual ou superior a data de ativação informada");
                return true;
            }

            if (this.state.horaAlteracao === "") {
                this.showError("É obrigatório informar a hora de alteração");
                return true;
            }
            if (!moment(this.state.horaAlteracao, "HH:mm:ss").isValid()) {
                this.showError("Hora de alteração inválida");
                return true;
            }
            if (!this.state.motivoAlteracao) {
                this.showError("É obrigatório informar o motivo de alteração");
                return true;
            }
        }


    }

    validaTeclaDigitada = (e) => {
        console.log(e.key);

        const re = /[0-9a-zA-Z]+/g;
        if (!re.test(e.key)) {
            e.preventDefault();
        }
        if ((e.key === 'ç')) {
            e.preventDefault();
        }      
    }

    handleHexaChange = (e) => {
        let value = "";
        
        const re = /[0-9a-zA-Z]+/g;
        if (!re.test(e.target.value)) {
            e.target.value = "";
        }
        if ((e.target.value === 'ç')) {
            e.target.value = "";
        }

        value = e.target.value;

        this.setState({
            numeroHexa: value
          });
    }

    validaTextoColado = (event) => {
        console.log(event.clipboardData.getData('Text'));

        var textoNovo = "";

        var textoOriginal = "";

        var tamMax = 0;
        var tamTexto = 0;

        tamMax = event.target.maxLength;

        var caracterEspecial = false;

        var campo = event.target.name;

        textoOriginal = event.clipboardData.getData('Text');

        for (let i = 0; i < textoOriginal.length; i++) {
            const re = /[0-9a-zA-Z]+/g;
            const c = textoOriginal[i];
            tamTexto = textoNovo.length;
            caracterEspecial = false;
            if (!re.test(c)) {
                caracterEspecial = true;
            }

            if ((c === 'ç')) {
                caracterEspecial = true;
            }

            if (tamTexto < tamMax)
                if (!caracterEspecial)
                    textoNovo += c;
        }

        if (caracterEspecial)
            event.preventDefault();

        this.setState({
            [campo]: textoNovo
        });

    }

    verificaBicoExistente = (numeroSequencial) => {
        let existeBico = false;
        debugger;
        let lista = this.state.bicosExistentes;
        if (lista) {
            for (let i = 0; i < lista.length; i++) {
                const bico = lista[i];
                if (bico.codigoBico !== this.state.codigoBico)
                    if (bico.numeroSequencial === numeroSequencial) {
                        existeBico = true;
                        break;
                    }
            }
            if (existeBico)
                this.showError("O número sequencial informado para o bico já existe.");
        }
        return existeBico;
    }

    render() {
        const {
            //campos tela
            codigoBico,
            codigoTanque,
            codigoBomba,
            numeroSequencial,
            numeroBicoNaBomba,
            codigoNivelPreco,
            permiteAbastecimentoManual,
            numeroHexa,
            dataAtivacao,
            ativo,
            rowVersion,

            horaAlteracao,
            dataAlteracao,
            motivoAlteracao,

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle,

            tanquesLista,
            bombasLista,
            listaPrecos,
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="Número sequencial do bico"
                                    value={numeroSequencial}
                                    name="numeroSequencial"
                                    maxlength="2"
                                    decimalScale={0}
                                    type="number"
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    disabled={rowVersion !== null}
                                    tabindex={1}
                                />
                            </div>
                            <div className="col-5">
                                <Select
                                    label="Tanque"
                                    name="codigoTanque"
                                    value={codigoTanque}
                                    onChange={this.handleTanqueChange}
                                    options={tanquesLista}
                                    tabindex={2}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <Select
                                    label="Bomba"
                                    name="codigoBomba"
                                    value={codigoBomba}
                                    onChange={this.handleInputChange}
                                    options={bombasLista}
                                    tabindex={3}
                                />
                            </div>
                            <div className="col-1">
                                <InputText
                                    type="number"
                                    label="Número do bico  na bomba (1-4)"
                                    value={numeroBicoNaBomba}
                                    decimalScale={0}
                                    name="numeroBicoNaBomba"
                                    maxlength="1"
                                    allowNegative={false}
                                    onChange={this.handleInputChange}
                                    tabindex={4}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Número hexa (Endereço lógico na automação)"
                                    value={numeroHexa}
                                    name="numeroHexa"
                                    maxlength="2"
                                    onChange={this.handleHexaChange}
                                    tabindex={5}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                />
                            </div>
                            <div className="col-1">
                                <Select
                                    label="Nível de preço:"
                                    name="codigoNivelPreco"
                                    value={codigoNivelPreco}
                                    onChange={this.handleInputChange}
                                    options={listaPrecos}
                                    tabindex={6}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputDate
                                    label="Data de ativação"
                                    value={dataAtivacao}
                                    name="dataAtivacao"
                                    onChange={this.handleInputChange}
                                    tabindex={7}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                        tabindex={8}
                                        disabled={rowVersion === null}
                                    />
                                </Checkbox>
                            </div>
                            <div className="col-5">
                                <Checkbox label="Permite abastecimento manual:">
                                    <Checkitem
                                        label=""
                                        name="permiteAbastecimentoManual"
                                        checked={permiteAbastecimentoManual}
                                        onChange={this.handleInputChange}
                                        tabindex={9}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                    </SectionContent>
                    <SectionContent title="" visible={rowVersion !== null ? true : false}>
                        <div className="row">
                            <div className="col-5">
                                <InputDate
                                    label="Data da alteração"
                                    name="dataAlteracao"
                                    value={(dataAlteracao ? moment(dataAlteracao) : moment())}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-5">
                                <InputTime className="input time"
                                    required
                                    label="Hora de alteração"
                                    value={horaAlteracao}
                                    name="horaAlteracao"
                                    showSeconds
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Motivo da alteração"
                                    value={motivoAlteracao}
                                    name="motivoAlteracao"
                                    maxlength="255"
                                    required
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                    </SectionContent>
                    {/*<div className="content-divider" />
                    <SectionContent title="Volume máximo por turno">
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Litros"
                                    type="number"
                                    value={litros}
                                    name="litros"
                                    maxlength="10"
                                    onChange={this.handleInputChange}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                    tabindex={10}
                                />
                            </div>
                            +
                            <div className="col-1">
                                <InputText
                                    label="% tolerância"
                                    type="number"
                                    value={tolerancia}
                                    name="tolerancia"
                                    maxlength="10"
                                    onChange={this.handleInputChange}
                                    tabindex={11}
                                />
                            </div>
                            =
                            <div className="col-1">
                                <InputText
                                    label=""
                                    type="number"
                                    value={resultado}
                                    name="resultado"
                                    maxlength="10"
                                    onChange={this.handleInputChange}
                                    tabindex={12}
                                    disabled
                                />
                            </div>
                        </div>
                    </SectionContent>
        */}
                </SectionContainer>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={
                        ((rowVersion !== null)) ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}

                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenCadastroBico extends Component {
    state = {
        Bicos: [],
        tanques: [],
        Bicosel: {}
    };

    async componentDidMount() {
        const { data: responseBicos } = await getBicos();
        var bicosDesord = responseBicos.result;

        const { data: tanques } = await montarComboTanque();

        const bicos = bicosDesord.sort(function (a, b) {
            if (a.numeroSequencial < b.numeroSequencial) return -1;
            if (a.numeroSequencial > b.numeroSequencial) return 1;
            return 0;
        });

        for (let i = 0; i < bicos.length; i++) {
            var tanque = tanques.filter(t => t.codigo === parseInt(bicos[i].codigoTanque));
            if (tanque) {
                bicos[i].descricaoTanque = tanque[0].descricao;
            }
            bicos[i].numeroSequencial = ("00" + bicos[i].numeroSequencial).slice(-2);
            bicos[i].descricaoBomba = ("00" + bicos[i].codigoBomba).slice(-2);
            bicos[i].numeroBicoNaBomba = ("00" + bicos[i].numeroBicoNaBomba).slice(-2);
            bicos[i].dataAtivacaoFormatada = moment(bicos[i].dataAtivacao).format("DD/MM/YYYY");

        }



        this.setState({ bicos, tanques });

    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            const { data: responseBicos } = await getBicos();
            var bicos = responseBicos.result;

            const { data: tanques } = await montarComboTanque();

            for (let i = 0; i < bicos.length; i++) {
                var tanque = tanques.filter(t => t.codigo === parseInt(bicos[i].codigoTanque));
                if (tanque) {
                    bicos[i].descricaoTanque = tanque[0].descricao;
                }
                bicos[i].numeroSequencial = ("00" + bicos[i].numeroSequencial).slice(-2);
                bicos[i].codigoBomba = ("00" + bicos[i].codigoBomba).slice(-2);
                bicos[i].numeroBicoNaBomba = ("00" + bicos[i].numeroBicoNaBomba).slice(-2);
                bicos[i].dataAtivacaoFormatada = moment(bicos[i].dataAtivacao).format("DD/MM/YYYY");

            }

            this.setState({ bicos, tanques });

        }
    }

    buscaDescricaoBanco = (codigoBanco) => {
        var arBancos = this.state.bancosArray;
        for (let i = 0; i < arBancos.length; i++) {
            const banco = arBancos[i];
            if (parseInt(banco.codigo) === parseInt(codigoBanco)) {
                var descricao = banco.nome;
                break;
            }
        }

        return descricao;
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) { // se clicar numa linha vazia, não faz nada
            this.setState({ Bicosel: rowInfo.original });
            this.props.history.push("/bico/new", { Bicosel: rowInfo.original, tanques: this.state.tanques, bicosExistentes: this.state.bicos });
        }
    }

    render() {
        const { edit } = this.props;
        let Bicosel = {};
        let tanques = [];
        let bicosExistentes = [];
        if (edit) {
            // this.props.location.state por padrao eh undefined
            if (this.props.location.state) {
                Bicosel = this.props.location.state.Bicosel;
                tanques = this.props.location.state.tanques;
                bicosExistentes = this.props.location.state.bicosExistentes;
            }
        }

        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Bicos"
                        subtitle=""
                        /*  <div className="section-header-search">
                                <InputText placeholder="Buscar" icone="icon-lx-search" />
                            </div>
                                */
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ Bicosel: {} });
                                            this.props.history.push("/bico/new", { Bicosel: {}, tanques: this.state.tanques, bicosExistentes: this.state.bicos });
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form
                            Bico={Bicosel}
                            tanques={tanques}
                            bicosExistentes={bicosExistentes}
                        />
                    ) : (

                            <List
                                defaultPageSize={5}
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "numeroSequencial",
                                        Header: "Nº Seq. Bico",
                                        width: 110,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricaoTanque",
                                        Header: "Tanque",
                                        width: 150,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricaoBomba",
                                        Header: "Bomba",
                                        width: 80,
                                        filterable: false,
                                    },
                                    {
                                        accessor: "numeroBicoNaBomba",
                                        Header: "Nº bico na bomba (1-4)",
                                        width: 175,
                                        filterable: false,
                                    },
                                    {
                                        accessor: "numeroHexa",
                                        Header: "Nº Hexa",
                                        width: 100,
                                        filterable: false,
                                    },

                                    {
                                        accessor: "codigoNivelPreco",
                                        Header: "Nível de Preço",
                                        width: 120,
                                        filterable: false,
                                    },

                                    {
                                        accessor: "dataAtivacaoFormatada",
                                        Header: "Data ativação",
                                        width: 150,
                                        filterable: false,
                                    },
                                    {
                                        accessor: "inativo",
                                        Header: "Ativo",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={row.inativo}
                                                    ic
                                                    icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.bicos}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenCadastroBico = withRouter(ScreenCadastroBico);
export { ScreenCadastroBico };
