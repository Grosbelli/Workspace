import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Select,
    Checkbox,
    Checkitem,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { List, sortInt } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getCentrosMonetarios,
    incluirCentroMonetario,
    alterarCentroMonetario,
    excluirCentroMonetario
} from "../../../services/CentrosMonetarios";

import {
    getBancos
} from "../../../services/Bancos";

import { toFloatFormattedDisplay } from "../../../utils/Utils";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigoCentroMonetario,
            codigoBanco,
            agencia,
            digitoAgencia,
            conta,
            digitoConta,
            descricao,
            codigoEmpresa,
            cnpjEmpresa,
            inativo = false,
            restrito,
            rowVersion = null,
            saldo = 0,
            possuiMovimentacao = false
        } = this.props.CentroMonetario;

        this.state = {
            codigoCentroMonetario,
            codigoBanco,
            agencia,
            digitoAgencia,
            conta,
            digitoConta,
            descricao,
            codigoEmpresa,
            cnpjEmpresa,
            ativo: !inativo,
            restrito,
            rowVersion,
            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            centrosExistentes: this.props.centrosExistentes,
            centrosListaTransfere: [],

            bancos: [],
            bancosarray: [],

            saldo,
            possuiMovimentacao,

            restritoOriginal: restrito
        };
    }

    async componentDidMount() {
        const bancosArray = this.props.bancosArray;
        let primeiroBanco = 1;
        if (bancosArray) {
            this.setState({
                bancos:

                    bancosArray.filter(ba => ba.tipo.descricao === "Banco").map(b => {
                        return {
                            label: ("000" + b.codigo).slice(-3) + ' - ' + b.nome,
                            value: b.codigo
                        }
                    })
            });

            if (!this.props.CentroMonetario.rowVersion) {

                for (let i = 0; i < bancosArray.length; i++) {
                    const banco = bancosArray[i];
                    if (banco.tipo.descricao === "Banco") {
                        primeiroBanco = banco.codigo;
                        break;
                    }
                }

                this.setState({ codigoBanco: primeiroBanco });
            }

        }

    }

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoCentroMonetario
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/centrosmonetarios/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluirCentroMonetario(codigoCentroMonetario);
                        //sucesso
                        console.log("sucesso");
                        this.showInfo("Centro Monetário excluído com sucesso!");
                    } catch (err) {
                        // falha
                        console.log("fallha");
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/centrosmonetarios/");
                }
                break;


            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Centro Monetário",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {
            //state de centro monetario
            codigoCentroMonetario,
            codigoBanco,
            agencia,
            digitoAgencia,
            conta,
            digitoConta,
            descricao,
            codigoEmpresa,
            ativo,
            restrito,
            rowVersion,

        } = this.state,
            inativo = !ativo;

        const [action, params] =
            rowVersion !== null
                ? [
                    alterarCentroMonetario,
                    [
                        codigoCentroMonetario,
                        codigoBanco,
                        agencia,
                        digitoAgencia,
                        conta,
                        digitoConta,
                        descricao,
                        inativo,
                        restrito,
                        rowVersion
                    ]
                ]
                : [
                    incluirCentroMonetario,
                    [
                        codigoCentroMonetario,
                        codigoBanco,
                        agencia,
                        digitoAgencia,
                        conta,
                        digitoConta,
                        descricao,
                        codigoEmpresa,
                        inativo,
                        restrito,
                    ]
                ];

        let temErros = this.verificaCentroMonetario();

        if (!temErros) {
            temErros = this.verificaCentroExistente(codigoBanco, agencia, conta, codigoCentroMonetario);
        }

        if (!temErros) {

            try {
                const resp = await action(...params);
                console.log(resp);
                this.setState({
                    alertActive: true,
                    alertType: "success",
                    alertTitle: "Centros Monetários",
                    alertSubtitle: `Centro Monetário  ${rowVersion === null ? "cadastrado" : "alterado"} com sucesso!`
                });
            } catch (err) {
                this.setState({
                    alertActive: true,
                    alertType: "error",
                    alertTitle: "Erro",
                    alertSubtitle: err.response.data.message
                });
            }
        }
    };

    handleExcluir = () => {
        console.log("excluir");
        var temErros = false;

        if (this.state.possuiMovimentacao) {
            this.showError("Não é permitido excluir Centro Monetário com histórico");
            temErros = true;
        }

        if (!temErros)

            if (parseInt(this.state.saldo) !== 0) {
                this.showError("Não é permitido excluir Centro Monetário com saldo diferente de zero");
                temErros = true;
            }

        if (!temErros) {

            this.setState({
                alertActive: true,
                alertType: "question",
                alertTitle: "Centros Monetários",
                alertSubtitle: "Confirma a exclusão do centro monetário?"
            });
        }
    }

    handleCancelar = () => {
        console.log("cancelar");
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Centros Monetários",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    verificaCentroMonetario = () => {
        //verifica preenchimento dos campos   

        var temErros = false;

        if ((!this.state.descricao) || (this.state.descricao.trim() === '')) {
            this.showError("É necessário informar a descrição.");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (!this.state.codigoBanco) {
            this.showError("É necessário informar o código do banco.");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (!this.state.agencia) {
            this.showError("É necessário informar o número da Agência.");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (!this.state.conta) {
            this.showError("É necessário informar o número da Conta.");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if ((!this.state.ativo) && (!this.state.rowVersion)) {
            this.showError("Não é permitido inclusão de centro monetário inativo");
            temErros = true;
        }

        if (temErros)
            return temErros;

        /*  if ((!this.state.ativo) && (this.state.possuiMovimentacao)) {
              this.showError("Não é permitido inativar Centro Monetário com histórico");
              temErros = true;
          }
  
          if (temErros)
              return temErros;*/

        if ((!this.state.ativo) && (parseInt(this.state.saldo) !== 0)) {
            this.showError("Não é permitido inativar Centro Monetário com saldo diferente de zero");
            temErros = true;
        }

        if (temErros)
            return temErros;


    }

    validaTeclaDigitada = (e) => {
        const re = /[0-9a-zA-Z]+/g;
        if (!re.test(e.key)) {
            e.preventDefault();
        }

        if ((e.key === 'ç')) {
            e.preventDefault();
        }
    }

    validaTextoColado = (event) => {
        console.log(event.clipboardData.getData('Text'));

        var textoNovo = "";

        var textoOriginal = "";

        var tamMax = 0;
        var tamTexto = 0; 

        tamMax = event.target.maxLength;

        var caracterEspecial = false;

        var campo = event.target.name;

        textoOriginal = event.clipboardData.getData('Text');

        for (let i = 0; i < textoOriginal.length; i++) {
            const re = /[0-9a-zA-Z]+/g;
            const c = textoOriginal[i];
            tamTexto = textoNovo.length;
            caracterEspecial = false;
            if (!re.test(c)) {
                caracterEspecial = true;
            }

            if ((c === 'ç')) {
                caracterEspecial = true;
            }

            if (tamTexto < tamMax)
                if (!caracterEspecial)
                    textoNovo += c;
        }

        if (caracterEspecial)
            event.preventDefault();

        this.setState({
            [campo]: textoNovo
        });

    }

    verificaCentroExistente = (idBanco, idAgencia, idConta, codigoCentroMonetario) => {
        let existeCentro = false;

        let lista = this.state.centrosExistentes;
        for (let i = 0; i < lista.length; i++) {
            const centro = lista[i];
            if (centro.codigoCentroMonetario !== codigoCentroMonetario)
                if ((parseInt(centro.codigoBanco) === parseInt(idBanco)) && (centro.agencia === idAgencia) && (centro.conta === idConta)) {
                    existeCentro = true;
                    break;
                }
        }
        if (existeCentro) {
            this.showError("Conta já cadastrada!");
        }

        return existeCentro;
    }

    render() {
        const {
            //campos tela
            codigoCentroMonetario,
            codigoBanco,
            agencia,
            digitoAgencia,
            conta,
            digitoConta,
            descricao,
            ativo,
            restrito,
            rowVersion,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle,
            restritoOriginal,
            saldo,

            bancos
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-2">
                                <InputText
                                    label="Código:"
                                    value={codigoCentroMonetario}
                                    name="codigoCentroMonetario"
                                    type="number"
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    disabled
                                    tabindex={1}
                                />
                            </div>
                            <div className="col-1 ">
                                <InputText
                                    label="Descrição:"
                                    value={descricao}
                                    name="descricao"
                                    maxlength="50"
                                    onChange={this.handleInputChange}
                                    tabindex={2}

                                />
                            </div>
                        </div>
                    </SectionContent>
                    <div className="content-divider" />
                    <SectionContent title="Dados Bancários" >
                        <div className="row">
                            <div className="col-1">
                                <Select
                                    label="Banco:"
                                    name="codigoBanco"
                                    value={codigoBanco}
                                    onChange={this.handleInputChange}
                                    options={bancos}
                                    tabindex={3}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Agência:"
                                    value={agencia}
                                    name="agencia"
                                    maxlength="4"
                                    onChange={this.handleInputChange}
                                    tabindex={4}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                />
                            </div>
                            <div className="col-2">
                                <InputText
                                    label="Dígito:"
                                    value={digitoAgencia}
                                    name="digitoAgencia"
                                    maxlength="1"
                                    onChange={this.handleInputChange}
                                    tabindex={5}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Conta:"
                                    value={conta}
                                    name="conta"
                                    maxlength="10"
                                    onChange={this.handleInputChange}
                                    tabindex={6}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                />
                            </div>
                            <div className="col-2">
                                <InputText
                                    label="Dígito:"
                                    value={digitoConta}
                                    name="digitoConta"
                                    maxlength="1"
                                    onChange={this.handleInputChange}
                                    tabindex={7}
                                    onKeyDown={this.validaTeclaDigitada}
                                    onPaste={this.validaTextoColado}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Saldo:"
                                    value={toFloatFormattedDisplay(saldo)}
                                    name="saldo"
                                    onChange={this.handleInputChange}
                                    tabindex={8}
                                    disabled
                                    onKeyDown={this.validaTeclaDigitada}
                                    decimalScale={2}
                                />
                            </div>
                        </div>
                    </SectionContent>
                    <div className="content-divider" />
                    <SectionContent title="Opções">
                        <div className="row">
                            <div className="col-1">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <Checkbox label="Restrito:">
                                    <Checkitem
                                        label=""
                                        name="restrito"
                                        checked={restrito}
                                        onChange={this.handleInputChange}
                                        disabled={rowVersion === null}
                                    />
                                </Checkbox>
                            </div>
                        </div>

                    </SectionContent>

                </SectionContainer>

                <FormOptions
                    handleSalvar={
                        (!restritoOriginal) ? this.handleSalvar : null}
                    handleExcluir={
                        ((rowVersion !== null) && (!restritoOriginal)) ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}

                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenCentrosMonetarios extends Component {
    state = {
        centroMonetarios: [],
        centroMonetariosel: {}
    };

    async componentDidMount() {
        const { data: responsecentroMonetarios } = await getCentrosMonetarios();
        var centroMonetarios = responsecentroMonetarios.result;

        const { data: bc } = await getBancos();
        const bancosArray = bc.result;
        this.setState({ bancosArray });

        for (let i = 0; i < centroMonetarios.length; i++) {
            centroMonetarios[i].descricaoBanco = this.buscaDescricaoBanco(centroMonetarios[i].codigoBanco);
        }

        const ceMoOrd = centroMonetarios.sort(function (a, b) {
            if (a.descricaoBanco < b.descricaoBanco) return -1;
            if (a.descricaoBanco > b.descricaoBanco) return 1;
            return 0;
        });

        this.setState({ centroMonetarios: ceMoOrd });

    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            const { data: responsecentroMonetarios } = await getCentrosMonetarios();

            const centroMonetarios = responsecentroMonetarios.result;

            const { data: bc } = await getBancos();
            const bancosArray = bc.result;
            this.setState({ bancosArray });

            for (let i = 0; i < centroMonetarios.length; i++) {
                const cdBanco = centroMonetarios[i].codigoBanco;
                centroMonetarios[i].descricaoBanco = this.buscaDescricaoBanco(cdBanco);
            }

            const ceMoOrd = centroMonetarios.sort(function (a, b) {
                if (a.descricaoBanco < b.descricaoBanco) return -1;
                if (a.descricaoBanco > b.descricaoBanco) return 1;
                return 0;
            });

            this.setState({ centroMonetarios: ceMoOrd });
        }
    }

    buscaDescricaoBanco = (codigoBanco) => {
        var arBancos = this.state.bancosArray;
        for (let i = 0; i < arBancos.length; i++) {
            const banco = arBancos[i];
            if (parseInt(banco.codigo) === parseInt(codigoBanco)) {
                var descricao = banco.nome;
                break;
            }
        }

        return descricao;
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) { // se clicar numa linha vazia, não faz nada
            this.setState({ centroMonetariosel: rowInfo.original });
            this.props.history.push("/centrosmonetarios/new");
        }
    }

    render() {
        const { edit } = this.props,
            { centroMonetariosel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Centros Monetários"
                        subtitle=""
                        /*  <div className="section-header-search">
                                <InputText placeholder="Buscar" icone="icon-lx-search" />
                            </div>
                                */
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ centroMonetariosel: {} });
                                            this.props.history.push("/centrosmonetarios/new")
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form
                            CentroMonetario={centroMonetariosel}
                            centrosExistentes={this.state.centroMonetarios}
                            bancosArray={this.state.bancosArray}
                        />
                    ) : (

                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "codigoCentroMonetario",
                                        Header: "Código",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricaoBanco",
                                        Header: "Banco",
                                        width: 350,
                                        filterable: false
                                    },
                                    {
                                        accessor: "agencia",
                                        Header: "Agência",
                                        width: 100,
                                        filterable: false,
                                        sortMethod: sortInt
                                    },
                                    {
                                        accessor: "conta",
                                        Header: "Conta",
                                        width: 100,
                                        filterable: false,
                                        sortMethod: sortInt
                                    },
                                    {
                                        accessor: "descricao",
                                        Header: "Descrição",
                                        width: 200,
                                        filterable: false,
                                    },
                                    {
                                        accessor: "inativo",
                                        Header: "Ativo",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={row.inativo}
                                                    ic
                                                    icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.centroMonetarios}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenCentrosMonetarios = withRouter(ScreenCentrosMonetarios);
export { ScreenCentrosMonetarios };
