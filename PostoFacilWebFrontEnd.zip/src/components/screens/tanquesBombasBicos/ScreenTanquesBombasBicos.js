import React, { Component } from "react";
import { SectionContainer, SectionContent } from "../../section/Content";

import { withRouter } from "react-router-dom";

import { ScreenCadastroBico } from "../bicos/ScreenCadastroBico";
import { ScreenCadastroTanque } from "../tanque/ScreenCadastroTanque";
import { ScreenCadastroBomba } from "../bomba/ScreenCadastroBomba";

class ScreenTanquesBombasBicos extends Component {
    render() {
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <ScreenCadastroTanque />
                        <div className="content-divider1" />
                        <ScreenCadastroBomba />
                        <div className="content-divider1" />
                        <ScreenCadastroBico />
                    </SectionContent>
                </SectionContainer>
            </>
        )
    }
}


ScreenTanquesBombasBicos = withRouter(ScreenTanquesBombasBicos);
export { ScreenTanquesBombasBicos };
