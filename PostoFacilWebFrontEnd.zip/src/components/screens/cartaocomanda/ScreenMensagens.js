import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { List } from "./../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "./../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    alterarMensagem,
    getMensagem
} from "../../../services/CartaoComanda";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const
            codigoEstabelecimento = "1",
            mensagem1 = "",
            mensagem2 = "",
            mensagem3 = "";

        this.state = {
            codigoEstabelecimento,
            mensagem1,
            mensagem2,
            mensagem3,

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "" // subtitulo/mensagem do alert
        };
    }

    handleAlertAction = async (resp) => {
        const {
            alertType,
            codigoEstabelecimento,
            mensagem1,
            mensagem2,
            mensagem3
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/mensagem/");
                break;

            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
          //  codigoEstabelecimento: "",

            alertActive: true,
            alertType: "success",
            alertTitle: "Mensagens",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {
            codigoEstabelecimento,
            mensagem1,
            mensagem2,
            mensagem3
        } = this.state;        

        const [action, params] =
            [
                alterarMensagem,
                [
                    codigoEstabelecimento,
                    mensagem1,
                    mensagem2,
                    mensagem3
                ]
            ]
        if (mensagem1.length > 500 || mensagem2.length > 500 || mensagem3.length > 500) {
            this.showError('Mensagem nao pode ter mais que 500 caracteres!');
        }
        else {
            try {
                const resp = await action(...params);
                this.showInfo(`Mensagem alterada com sucesso!`);
            } catch (err) {
                this.showError(err.response.data.message);
            }
        }
    };

    async componentDidMount() {
        const { data: mensagens } = await getMensagem(1);
        const {
            mensagem1,
            mensagem2,
            mensagem3
        } = mensagens[0];
        this.setState({ mensagem1, mensagem2, mensagem3 });
    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            const { data: mensagens } = await getMensagem(1);
            const {
                mensagem1,
                mensagem2,
                mensagem3
            } = mensagens[0];
            this.setState({ mensagem1, mensagem2, mensagem3 });
        }
    }

    render() {
        const {

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;

        const {
            codigoEstabelecimento,
            mensagem1,
            mensagem2,
            mensagem3
        } = this.state;

        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Linha 1:"
                                    name="mensagem1"
                                    value={mensagem1}
                                    onChange={this.handleInputChange}
                                    tabindex={1}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Linha 2:"
                                    name="mensagem2"
                                    value={mensagem2}
                                    onChange={this.handleInputChange}
                                    tabindex={2}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Linha 3:"
                                    name="mensagem3"
                                    value={mensagem3}
                                    onChange={this.handleInputChange}
                                    tabindex={3}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions handleSalvar={this.handleSalvar} />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenMensagens extends Component {

    render() {

        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Mensagens"
                        subtitle=""
                        right={
                            <>
                            </>
                        }
                    />
                    <Form />
                </section>
            </main>
        );
    }
}

ScreenMensagens = withRouter(ScreenMensagens);
export { ScreenMensagens };