import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Checkbox,
    Checkitem,
    FormOptions,
    StatusIndicator,
    handleInputChange
} from "../../formulario/Formulario";
import {
    List,
    sortInt
} from "./../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "./../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getCartaoComanda,
    incluirCartaoComanda,
    alterarCartaoComanda,
    excluirCartaoComanda,
    alterarMensagem
} from "../../../services/CartaoComanda";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigoCartaoComanda = null,
            numeroCartaoComanda = "",
            inativo = false,
            excluido = false,
            rowVersion = null,
            codigoEstabelecimento = "1"
        } = this.props.cartaoComanda;

        this.state = {
            codigoCartaoComanda, // ID do cartao  
            numeroCartaoComanda, // numero (codigo) do cartao
            ativo: !inativo, // indica se o cartao esta ativo/inativo
            excluido, // exclusao logica do cartao
            rowVersion, // TODO: entender melhor funcionamento
            codigoEstabelecimento, // TODO: verificar como setar esse valor!

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            cartoesExistentes: []
        };
    }

    componentDidMount() {
        this.setState({ cartoesExistentes: this.props.comandasExistentes })
    }

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoEstabelecimento,
            codigoCartaoComanda,
            rowVersion } = this.state;
        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/cartaocomanda/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluirCartaoComanda(codigoEstabelecimento, codigoCartaoComanda, rowVersion);
                        //sucesso
                        this.showInfo("Cartão comanda excluído com sucesso!");
                    } catch (err) {
                        // falha
                        this.showError(err.response.data.message);
                    }
                }
                break;
             
            case "cancel":
                if (resp) {
                    this.props.history.push("/cartaocomanda/");
                }
                break;

            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            /*codigoCartaoComanda: null,
            numeroCartaoComanda: "",
            ativo: true,
            excluido: false,
            rowVersion: null,
            codigoEstabelecimento: "",*/
            alertActive: true,
            alertType: "success",
            alertTitle: "Cartão comanda",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {
            codigoCartaoComanda,
            numeroCartaoComanda,
            ativo,
            excluido,
            rowVersion,
            codigoEstabelecimento
        } = this.state,
            inativo = !ativo;
        const [action, params] =
            codigoCartaoComanda !== null
                ? [
                    alterarCartaoComanda,
                    [
                        codigoEstabelecimento,
                        codigoCartaoComanda,
                        numeroCartaoComanda,
                        inativo,
                        excluido,
                        rowVersion
                    ]
                ]
                : [
                    incluirCartaoComanda,
                    [codigoEstabelecimento, numeroCartaoComanda, inativo]
                ];


        if (action === incluirCartaoComanda) {
            var cartaoExiste = this.verificaValorDigitado(this.state.numeroCartaoComanda);
            if (numeroCartaoComanda === "") {
                this.showError("É obrigatório informar o número do cartão comanda");
            }
            else {
                if (cartaoExiste) {
                    this.showError("Não foi possível inserir o cartão comanda pois o mesmo já existe.");
                } else {
                    try {
                        const resp = await action(...params);
                        console.log(resp);
                        this.showInfo(`Cartão comanda ${codigoCartaoComanda === null ? "cadastrado" : "alterado"} com sucesso!`);
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
            }
        } else {
            try {
                const resp = await action(...params);
                console.log(resp);
                this.showInfo(`Cartão comanda ${codigoCartaoComanda === null ? "cadastrado" : "alterado"} com sucesso!`);
            } catch (err) {
                this.showError(err.response.data.message);
            }
        }
    };

    handleExcluir = () => {
        console.log("excluir");
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Cartão comanda",
            alertSubtitle: "Deseja excluir?"
        });

    }

    handleCancelar = () => {
        console.log("cancelar");
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Cartão comanda",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    /* handleBlur = (event) => {
         var campo = event.target;
         if (this.state[campo.name] === "") {
             this.showError("É obrigatório informar o número do cartão comanda");
         }
     }*/

    verificaValorDigitado = (valor) => {
        var existeCartao = false;
        var lista = this.state.cartoesExistentes;
        for (let i = 0; i < lista.length; i++) {
            const cartao = lista[i];
            if (parseInt(cartao.numeroCartaoComanda) === valor) {
                existeCartao = true;
            }

        }
        return existeCartao;
    }

    render() {
        const {
            codigoCartaoComanda,
            numeroCartaoComanda,
            ativo,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-4">
                                <InputText
                                    label="Número do cartão:"
                                    name="numeroCartaoComanda"
                                    value={numeroCartaoComanda}
                                    type="number"
                                    //onBlur={this.handleBlur}
                                    required
                                    disabled={codigoCartaoComanda !== null}
                                    onChange={this.handleInputChange}
                                    decimalScale={0}
                                    allowNegative={false}
                                    autofocus={true}
                                    tabindex={1}
                                />
                            </div>
                            <div className="col-12">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={codigoCartaoComanda !== null ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />

            </>
        );
    }
}

Form = withRouter(Form);

class ScreenCartoComanda extends Component {
    state = { cartaoComandas: [], cartaoComandaSel: {}, telaDisponivel: false };

    async componentDidMount() {
        const { data: cartaoComandas } = await getCartaoComanda(1);
        this.setState({ cartaoComandas });
        this.setState({ telaDisponivel: true });
    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            const { data: cartaoComandas } = await getCartaoComanda(1);
            this.setState({ cartaoComandas });
            this.setState({ telaDisponivel: true });
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (this.state.telaDisponivel)
            if (rowInfo) {
                this.setState({ cartaoComandaSel: rowInfo.original });
                this.props.history.push("/cartaocomanda/new");
            }
    }

    render() {
        const { edit } = this.props,
            { cartaoComandaSel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Cartão Comanda"
                        subtitle=""
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ cartaoComandaSel: {} });
                                            this.props.history.push("/cartaocomanda/new")
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form cartaoComanda={cartaoComandaSel} comandasExistentes={this.state.cartaoComandas} />
                    ) : (
                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "numeroCartaoComanda",
                                        Header: "Número do cartão",
                                        width: 200,
                                        filterable: false,
                                        sortMethod: sortInt
                                    },
                                    {
                                        accessor: "inativo",
                                        Header: "Ativo",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={row.inativo}
                                                    ic
                                                    icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.cartaoComandas}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenCartoComanda = withRouter(ScreenCartoComanda);
export { ScreenCartoComanda };