import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import {
    InputText,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";
import { Botao } from "../../botoes/Botao";
import { List } from "../../formulario/List";

import {
    getTrocos,
    incluiTroco,
    alteraTroco,
    excluiTroco,
    montaComboTipoFormaPagamento,
    montaComboFormaPagamento,
    montaComboTipoLimite
} from "../../../services/Troco";

import {
    getFormaPagamento, getFormasPagamento
} from "../../../services/FormasPagamento";

import { toFloatFormattedDisplay } from "../../../utils/Utils";

const Formas = {
    Cheque: -2,
    Dinheiro: -1,
    Ticket: -3,
    Vale: -5
};

const FormasAceitas = {
    Dinheiro: -1,
    Vale: -5
};

const Tipos = {
    Percentual: 0,
    Valor: 1
};

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        // const { codigo } = this.props.troco.codigo ?
        //     Math.abs(this.props.troco.codigo) : Formas.Cheque;                

        let {
            codigo = Formas.Cheque,
            codigoFormaPagamento = FormasAceitas.Dinheiro,
            codigoAntigo = 0,
            tipoLimite = Tipos.Percentual,
            limite,
            inativo = false,
            rowVersion = null
        } = this.props.troco;

        const {
            trocosExistentes = [],
            shouldRender = false,
            isEditing = false 
        } = this.props;

        codigoAntigo = isEditing ? codigo : codigoAntigo;    

        this.state = {
            codigo,
            codigoAntigo,
            formas: [],
            ativo: !inativo,
            codigoFormaPagamento,
            formasAceitas: [],
            tipoLimite,
            tipos: [],
            limite,
            rowVersion,

            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: "",

            trocosExistentes,
            trocoSel: [],
            shouldRender,
            isEditing
        };

    }

    async componentDidMount() {
        const formasAceitas = [];
        const { data: dinheiro } = await getFormaPagamento(FormasAceitas.Dinheiro);
        if (!dinheiro.inativo) {
            formasAceitas.push({
                label: dinheiro.descricao,
                value: dinheiro.codigo
            });
        }

        const { data: vale } = await getFormaPagamento(FormasAceitas.Vale);
        if (!vale.inativo) {
            formasAceitas.push({
                label: vale.descricao,
                value: vale.codigo
            });
        }

        if (formasAceitas.length === 0) {
            this.showError("As formas de pagamento aceitas para troco " +
                "(dinheiro e vale) não estão ativas no cadastro de " +
                "formas de pagamento");
        }

        const { data: dataTipoForma } = await montaComboTipoFormaPagamento();
        const formas = [];

        dataTipoForma.forEach((fp) => {
            formas.push({
                label: fp.descricao, value: fp.codigo > 0 ?
                    fp.codigo * (-1) : fp.codigo
            });
        })
        // formas.push({ label: "Cheque", value: Formas.Cheque });
        // formas.push({ label: "Dinheiro", value: Formas.Dinheiro });
        // formas.push({ label: "Ticket", value: Formas.Ticket });
        // formas.push({ label: "Vale", value: Formas.Vale });

        const { data: dataTipoLimite } = await montaComboTipoLimite();
        const tipos = [];
        dataTipoLimite.forEach((l) => {
            tipos.push({ label: l.descricao, value: l.codigo });
        })
        // tipos.push({ label: "Percentual", value: Tipos.Percentual });
        // tipos.push({ label: "Valor", value: Tipos.Valor });

        this.setState({ formas, formasAceitas, tipos });
    }

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Troco",
            alertSubtitle: message
        });
    }

    handleCodigoChange = (event) => {
        let value = event.target.value;        
        let codigo = "0";
        switch (Number(value)) {
            case Formas.Cheque:
                codigo = String(Formas.Cheque);
                break;
            case Formas.Dinheiro:
                codigo = String(Formas.Dinheiro);
                break;
            case Formas.Ticket:
                codigo = String(Formas.Ticket);
                break;
            case Formas.Vale:
                codigo = String(Formas.Vale);
                break;
            default:
                break;
        }
        this.setState({ codigo });
    }

    handleAceitaEmChange = (event) => {
        let value = event.target.value;
        let codigoFormaPagamento = Number(value) === FormasAceitas.Dinheiro ?
            String(FormasAceitas.Dinheiro) : String(FormasAceitas.Vale);
        this.setState({ codigoFormaPagamento });
    }

    handleTipoLimiteChange = (event) => {
        let value = event.target.value;
        let limite = this.state.limite;
        if (value !== this.state.tipoLimite)
            limite = 0;
        let tipoLimite = Number(value) === Tipos.Percentual ?
            String(Tipos.Percentual) : String(Tipos.Valor);
        this.setState({ tipoLimite, limite });
    }

    trocoExists = (forma, aceitaEm) => {
        if(this.state.isEditing) // em edição existe, mas não tem problema
            return false;        

        let lista = this.state.trocosExistentes;        
        
        for (let i = 0; i < lista.length; i++) {
            const troco = lista[i];
            if (Number(forma) === Number(troco.codigo) &&
                Number(aceitaEm) === Number(troco.codigoFormaPagamento)) {
                this.showError("Já existe troco com as formas de " +
                    "pagamento informadas");
                return true;
            }
        }
        return false;
    }

    isFormValid() {
        const {            
            tipoLimite,
            limite,
        } = this.state;
                
        if(!limite){
            this.showError("Informe o limite do troco");
            return false;
        }

        if (Number(tipoLimite) === Tipos.Valor &&
            (limite < 0 || limite > 999999)){
                this.showError("O valor limite de troco deve estar entre"+
                    " 0 e 999.999");
                return false;
            }

        if (Number(tipoLimite) === Tipos.Percentual &&
            (limite < 0.01 || limite > 100)){
                this.showError("O percentual limite de troco deve estar"+
                    " entre 0,01 e 100");
                return false;
            }

        /* Percentual	Aceitar valores entre 0,01 e 100,00.
        Valor	Aceitar valores entre 0,00 e 999999,00. */

        return true;
    }

    handleSalvar = async () => {
        let {
            isEditing,
            codigo,
            codigoAntigo,
            codigoFormaPagamento,
            tipoLimite,
            limite,
            ativo
        } = this.state;

        let inativo = !ativo;
        
        if (!this.isFormValid() || this.trocoExists(codigo, 
            codigoFormaPagamento)) {
            return;
        }

        const [action, params] =
            isEditing
                ? [
                    alteraTroco,
                    [
                        codigo,
                        codigoAntigo,
                        codigoFormaPagamento,
                        tipoLimite,
                        limite,
                        inativo
                    ]
                ]
                : [
                    incluiTroco,
                    [
                        codigo,
                        codigoAntigo,
                        codigoFormaPagamento,
                        tipoLimite,
                        limite,
                        inativo
                    ]
                ];

        try {
            await action(...params);
            this.showInfo(`Troco ${isEditing ?
                "alterado" : "incluído"} com sucesso!`);
        } catch (err) {
            this.showError(err.response.data.message);
        }
    };

     handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Troco",
            alertSubtitle: "Deseja excluir?"
        });
    }; 

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Troco",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    };

    dismiss() {
        this.props.onClose();
    }

    handleAlertAction = async (resp) => {
        const {
            alertType,
            codigo,
            codigoFormaPagamento,
            tipoLimite,
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/troco/");
                this.dismiss();
                break;

            case "question":
                if (resp) {
                    try {
                        await excluiTroco(codigoFormaPagamento, tipoLimite, codigo);
                        this.showInfo("Troco excluído com sucesso!");
                        this.dismiss();
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/troco/");
                    this.dismiss();
                }
                break;
            default:
                break;
        }
    };

    getLimiteMaxLength = () => {
        return (Number(this.state.tipoLimite) === Tipos.Percentual ? 6 : 9);
    }

    render() {
        const {
            codigo,
            codigoFormaPagamento,
            tipoLimite,
            formas,
            formasAceitas,
            tipos,
            limite,
            //rowVersion,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle,
            shouldRender,
            isEditing
        } = this.state;

        if (!shouldRender)
            return (<></>);

        return (
            <>
                <SectionContent
                    title="Nova configuração de troco">
                    <div className="row">
                        <div className="col-5">
                            <Select
                                label="Forma de pagamento:"
                                name="codigo"
                                value={codigo}
                                onChange={this.handleCodigoChange}
                                options={formas}
                                disabled={isEditing}
                            />
                        </div>
                        <div className="col-5">
                            <Select
                                label="Aceitar troco em:"
                                name="codigoFormaPagamento"
                                value={codigoFormaPagamento}
                                onChange={this.handleAceitaEmChange}
                                options={formasAceitas}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                label="Tipo de limite para troco:"
                                name="tipoLimite"
                                value={tipoLimite}
                                onChange={this.handleTipoLimiteChange}
                                options={tipos}
                            />
                        </div>
                        <div className="col-5">
                            <InputText
                                label={`Limite 
                                        ${Number(tipoLimite) ===
                                        Tipos.Percentual ?
                                        "(%)" : "(R$)"}:`}
                                //label="Limite"
                                value={limite}
                                name="limite"
                                type="number"
                                maxlength={this.getLimiteMaxLength()}
                                decimalScale={2}
                                allowNegative={false}
                                onChange={this.handleInputChange}
                            />
                        </div>
                    </div>
                </SectionContent>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={isEditing ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />

            </>
        );
    }
}

Form = withRouter(Form);

class ScreenTroco extends Component {
    state = {
        trocos: [],
        trocoSel: {},
        telaDisponivel: false,
        codigo: 0,
        showForm: false,
        isEditing: false
    };

    closeForm = () => {
        const shouldRender = false;
        const showForm = false;
        const trocoSel = {};
        this.setState({ shouldRender, showForm, trocoSel });
    }

    async doMount() {
        const { data: dataTrocos } = await getTrocos(false);
        const trocos = dataTrocos.result;

        const { data: dataFormas } = await getFormasPagamento(false, true);

        const formas = dataFormas.result;
        trocos.forEach((t) => {
            for (let i = 0; i < formas.length - 1; i++)
                if (t.codigo === formas[i].codigo) {
                    t.formaPagamento = formas[i].descricao;
                    break;
                }
            for (let i = 0; i < formas.length - 1; i++)
                if (t.codigoFormaPagamento === formas[i].codigo) {
                    t.aceitaTrocoEm = formas[i].descricao;
                    break;
                }
            t.descricaoLimite = Number(t.tipoLimite) === Tipos.Percentual ?
                "Percentual" : "Valor";
        });

        this.setState({
            trocos,
            telaDisponivel: true
        });
    }

    componentDidMount() {
        this.doMount();
    }

    componentDidUpdate(prevProps) {
        //if (this.props.edit !== prevProps.edit && !this.props.edit) {
        this.doMount();
        // }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {    
        try {
            if (this.state.telaDisponivel && rowInfo) {
                this.setState({
                    trocoSel: rowInfo.original,
                    showForm: true,
                    isEditing: true
                });
                //this.props.history.push("/troco");
            }
        } catch (error) {
            //console.log(error.message);
        }
    }

    render() {
        const {
            trocos,
            trocoSel,
            showForm,
            isEditing
        } = this.state;

        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Troco"
                        subtitle=""
                        right={
                            <div className="button-container">

                                <Botao ic icon="icon-lx-plus" onClick={() => {
                                    this.setState({
                                        formaSel: {},
                                        showForm: true,
                                        isEditing: false
                                    });
                                    //this.props.history.push("/troco/new")
                                }} />

                            </div>
                        }
                    />
                    <SectionContainer>
                        <SectionContent
                            title="Configurações de Troco"
                            accordion>
                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "formaPagamento",
                                        Header: "Forma de Pagamento",
                                        width: 250,
                                        filterable: false
                                    },
                                    {
                                        accessor: "aceitaTrocoEm",
                                        Header: "Aceitar troco em",
                                        width: 250,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricaoLimite",
                                        Header: "Tipo de limite para troco",
                                        width: 250,
                                        filterable: false
                                    },
                                    {
                                        accessor: "limite",
                                        Header: "Limite",
                                        width: 150,
                                        filterable: false,
                                        Cell: props => <div>
                                            {toFloatFormattedDisplay(props.value)}
                                        </div>
                                    },
                                ]}
                                rows={trocos}
                                defaultPageSize={5}
                            />
                        </SectionContent>
                        {showForm ? (
                            <Form
                                troco={trocoSel ? trocoSel : null}
                                trocosExistentes={trocos ? trocos : null}
                                shouldRender={showForm}
                                isEditing={isEditing}
                                onClose={this.closeForm}
                            />) : (<></>)
                        }


                    </SectionContainer>
                </section>
            </main>
        );
    }

}

ScreenTroco = withRouter(ScreenTroco);
export { ScreenTroco };