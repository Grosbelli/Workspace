import React, { Component } from "react";
import "./Login.css";
import "../css/normalize.css";
import { withRouter } from "react-router-dom";

import imguser from "../img/login-ic-usuario.png";
import imgsenha from "../img/login-ic-senha.png";
import logopreto from "../img/login-logo-preto.png";
import logomarca from "../img/login-logomarca.png";
import imgcheck from "../img/button-ic-check.png";

import fazLogin from '../../services/Login.js';

import { setDadosAcesso } from '../../constants/Const.js';


class Login extends Component {
  state = { user: "", password: "", mensagemErro: "", CNPJ: "17898787000153", estaCod: "1" };

  handleInputChange = event => {
    const {
      target: { name, value }
    } = event;
    this.setState({ [name]: value });
  };

  login = async () => {

    if ((!this.state.user) || (!this.state.password)) {
      this.setState({ mensagemErro: "Informe Usuário e Senha" });
    } else {
      try {
        const resp = await fazLogin(this.state.user, this.state.password)
        //sucesso
        if (resp) {
          console.log("sucesso");
          setDadosAcesso(this.state.CNPJ, this.state.estaCod);
          this.props.history.push("/empresas");
        }
      } catch (err) {
        // falha
        console.log("fallha");
        this.setState({ mensagemErro: "Erro na autenticação" });
      }
    }
  };

  render() {
    return (
      <>
        <div className="login-container">
          <img src={logopreto} className="login-logo-mobile" />
          <div className="login-left">
            <img src={logomarca} className="logo" />
            <img src={logopreto} className="title" />
          </div>

          <div className="login-right">
            <div className="login-content">
              <div className="login-anima-head">
                <h1 className="title">Login</h1>
                <p>Seja bem vindo, por favor identifique-se!</p>
              </div>
              <div className="login-anima-content">
                <Input
                  value={this.state.CNPJ}
                  name="cnpj"
                  onChange={this.handleInputChange}
                  type="text"
                  label="CNPJ"
                  img={imguser}
                />
                <Input
                  value={this.state.estaCod}
                  name="estacod"
                  onChange={this.handleInputChange}
                  type="text"
                  label="Código Estabelecimento"
                  img={imguser}
                />
                <Input
                  value={this.state.user}
                  name="user"
                  onChange={this.handleInputChange}
                  type="text"
                  label="Usuário"
                  img={imguser}
                />
                <Input
                  value={this.state.password}
                  name="password"
                  onChange={this.handleInputChange}
                  type="password"
                  label="Senha"
                  img={imgsenha}
                />
                <a className="bt-esqueceu">Esqueceu a senha?</a>
                <button className="button" id="bt-entrar" onClick={this.login}>
                  Entrar
                  <img src={imgcheck} className="ic" />
                </button>
              </div>

              <div className="col-1">
                <label>
                  {this.state.mensagemErro}{'\n'}{'\n'}
                </label>
              </div>


            </div>

            {/*<footer className="login-footer">
              Linx Sistemas e Consultoria LTDA
    </footer>*/}
          </div>
        </div>

      </>
    );
  }
}

class Input extends Component {
  render() {
    const { type, name, label, img, value, onChange } = this.props;
    return (
      <div className="form-input has-bt">
        <input
          value={value}
          name={name}
          onChange={onChange}
          type={type}
          className="input"
          required
        />
        <label className="input-label">{label}:</label>
        <div className="input-bt">
          <img src={img} className="ic" />
        </div>
      </div>
    );
  }
}

export default withRouter(Login);