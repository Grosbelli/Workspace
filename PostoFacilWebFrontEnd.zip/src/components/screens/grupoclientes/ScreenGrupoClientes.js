import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
	InputText,
	Checkbox,
	Checkitem,
	FormOptions,
	handleInputChange,
	Select
} from "../../formulario/Formulario";
import { List } from "./../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "./../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
	buscarGrupoClientes,
	incluirGrupoClientes,
	alterarGrupoClientes,
	excluirGrupoClientes,
	selecionarGrupoClientes,
	montarComboClientes
} from "../../../services/GrupoClientes";

class Form extends React.Component {
	constructor(props) {
		super(props);
		this.handleInputChange = handleInputChange.bind(this);

		const {
			id = null,
			mostraAgrupado = false,
			descricao = "",
			clientes = [],
			rowVersion = null,
		} = this.props.grupoCliente;

		this.state = {
			id,
			mostraAgrupado,
			descricao,
			rowVersion,
			clientes,
			clientesLista: [],
			alertActive: false, // se o alert deve ser apresentado
			alertType: "", // tipo de alert (sucesso, erro...)
			alertTitle: "", // titulo do alert
			alertSubtitle: "", // subtitulo/mensagem do alert

			gruposClienteExistentes: this.props.gruposClienteExistentes
		};
	}

	verificaDescricaoExistente = (valorDescricao) => {
		let existeDescricao = false;
		let lista = this.state.gruposClienteExistentes;
		for (let i = 0; i < lista.length; i++) {
			const gc = lista[i];
			if (gc.id !== this.state.id)
				if (gc.descricao.toUpperCase() === valorDescricao.toUpperCase())
					existeDescricao = true;
		}
		if (existeDescricao)
			this.showError("Já existe um grupo de clientes com a descrição informada");

		return existeDescricao;
	}

	handleAlertAction = async (resp) => {
		const { alertType,
			id,
			rowVersion } = this.state;
		this.setState({
			alertActive: false,
			alertType: "",
			alertTitle: "",
			alertSubtitle: ""
		});

		switch (alertType) {
			case "success":
				this.props.history.push("/grupoClientes/");
				break;

			case "question":
				if (resp) {
					try {
						await excluirGrupoClientes(id);
						//sucesso
						console.log("sucesso");
						this.showInfo("Grupo de clientes excluído com sucesso!");
					} catch (err) {
						// falha
						console.log("fallha");
						this.showError(err.response.data.message);
					}
				}
				break;

			case "cancel":
				if (resp) {
					this.props.history.push("/grupoClientes/");
				}
				break;

			default:
				break;
		}
	};

	showError = (message) => {
		this.setState({
			alertActive: true,
			alertType: "error",
			alertTitle: "Erro",
			alertSubtitle: message
		});
	}

	showInfo = (message) => {
		this.setState({
			id: null,
			alertActive: true,
			alertType: "success",
			alertTitle: "Grupo de clientes",
			alertSubtitle: message
		});
	}

	verificaGrupoClientes = () => {

		var temErros = false;
		//verifica preenchimento dos campos
		if (this.state.descricao.trim() === "") {
			this.showError("Descrição não informada");
			temErros = true;
		}

		if (temErros)
			return temErros;

		if (this.state.clientes.length === 0) {
			this.showError("Inclua ao menos um cliente");
			temErros = true;
		}

		if (temErros)
			return temErros;

		//if (!this.state.id)
		temErros = this.verificaDescricaoExistente(this.state.descricao);

		return temErros;
	}

	handleSalvar = async () => {
		const {
			id,
			mostraAgrupado,
			descricao,
			rowVersion,
			clientes
		} = this.state;

		const [action, params] =
			id !== null
				? [
					alterarGrupoClientes,
					[
						id,
						mostraAgrupado,
						descricao,
						rowVersion,
						clientes
					]
				]
				: [
					incluirGrupoClientes,
					[
						descricao,
						mostraAgrupado,
						clientes
					]
				];

		var temErros = this.verificaGrupoClientes();

		if (!temErros) {

			try {
				const resp = await action(...params);
				console.log(resp);
				this.showInfo(`Grupo de clientes ${id === null ? "cadastrado" : "alterado"} com sucesso!`);
			} catch (err) {
				this.showError(err.response.data.message);
			}
		}
	};

	handleExcluir = () => {
		console.log("excluir");
		this.setState({
			alertActive: true,
			alertType: "question",
			alertTitle: "Grupo de clientes",
			alertSubtitle: "Deseja excluir?"
		});

	}

	handleCancelar = () => {
		console.log("cancelar");
		this.setState({
			alertActive: true,
			alertType: "cancel",
			alertTitle: "Grupo de clientes",
			alertSubtitle: "Deseja realmente cancelar a operação?"
		});
	}

	async componentDidMount() {
		const { data: clientesLista } = await montarComboClientes(1);

		const clientesListaOrd = clientesLista.sort(function (a, b) {
			if (a.descricao < b.descricao) return -1;
			if (a.descricao > b.descricao) return 1;
			return 0;
		});

		const clientesOrd = this.state.clientes.sort(function (a, b) {
			if (a.nomeCliente < b.nomeCliente) return -1;
			if (a.nomeCliente > b.nomeCliente) return 1;
			return 0;
		});

		this.setState({
			clientesLista: clientesListaOrd === null ? [] : (clientesListaOrd.map(cliente => { return { label: cliente.descricao, value: cliente.codigo } })),
			clientes: (clientesOrd.map(cli => { return cli.codigoCliente })),
		})
	}

	render() {
		const {
			id,
			descricao,
			mostraAgrupado,
			clientes,
			clientesLista,
			alertActive,
			alertType,
			alertTitle,
			alertSubtitle
		} = this.state;
		return (
			<>
				<SectionContainer>
					<SectionContent title="">
						<div className="row">
							<div className="col-4">
								<InputText
									label="Descrição"
									name="descricao"
									value={descricao}
									required
									disabled={id !== null}
									onChange={this.handleInputChange}
									autofocus="true"
									maxlength={100}
								/>
							</div>
							<div className="col-12">
								<Checkbox label="Mostra Agrupado:">
									<Checkitem
										label=""
										name="mostraAgrupado"
										checked={mostraAgrupado}
										onChange={this.handleInputChange}
									/>
								</Checkbox>
							</div>
						</div>
						<div className="row">
							<div className="col-1">
								<Select multi
									label="Cliente:"
									name="clientes"
									value={clientes}
									onChange={this.handleInputChange}
									options={clientesLista}
								/>
							</div>
						</div>
					</SectionContent>
				</SectionContainer>

				<FormOptions handleSalvar={this.handleSalvar} handleExcluir={
					id !== null ? this.handleExcluir : null}
					handleCancelar={this.handleCancelar}
				/>

				<Alert
					active={alertActive}
					type={alertType}
					title={alertTitle}
					subtitle={alertSubtitle}
					handleAction={this.handleAlertAction}
				/>
			</>
		);
	}
}

Form = withRouter(Form);

class ScreenGrupoClientes extends Component {
	state = { resultgrupoClientes: {}, grupoClientes: [], grupoClienteSel: {} };

	async componentDidMount() {
		const { data: resultgrupoClientes } = await buscarGrupoClientes(1, true);
		this.setState({ resultgrupoClientes });

		const grupoClientesOrd = resultgrupoClientes.result.sort(function (a, b) {
			if (a.descricao.toLowerCase() < b.descricao.toLowerCase()) return -1;
			if (a.descricao.toLowerCase() > b.descricao.toLowerCase()) return 1;
			return 0;
		});

		this.setState({ grupoClientes: grupoClientesOrd })
	}

	async componentDidUpdate(prevProps) {
		if (this.props.edit !== prevProps.edit && !this.props.edit) {
			const { data: resultgrupoClientes } = await buscarGrupoClientes(1, true);
			this.setState({ resultgrupoClientes });

			const grupoClientesOrd = resultgrupoClientes.result.sort(function (a, b) {
				if (a.descricao.toLowerCase() < b.descricao.toLowerCase()) return -1;
				if (a.descricao.toLowerCase() > b.descricao.toLowerCase()) return 1;
				return 0;
			});

			this.setState({ grupoClientes: grupoClientesOrd })

		}
	}

	handleTableClick = (state, rowInfo, column, instance, e) => {
		if (rowInfo) {
			this.setState({ grupoClienteSel: rowInfo.original });
			this.props.history.push("/grupoClientes/new");
		}
	}

	render() {
		const { edit } = this.props,
			{ grupoClienteSel } = this.state;
		return (
			<main className="main">
				<section className="section-container">
					<SectionHeader
						title="Grupo de Clientes"
						subtitle=""
						right={
							<div className="button-container">
								{edit ? (
									<>

									</>
								) : (
										<Botao ic icon="icon-lx-plus" onClick={() => {
											this.setState({ grupoClienteSel: {} });
											this.props.history.push("/grupoClientes/new")
										}} />
									)}
							</div>
						}
					/>
					{edit ? (
						<Form grupoCliente={grupoClienteSel}
							gruposClienteExistentes={this.state.grupoClientes}
						/>
					) : (
							<List
								onClick={this.handleTableClick}
								cols={[
									{
										accessor: "descricao",
										Header: "Descrição",
										width: 300,
										filterable: false,
									},
									{
										accessor: "mostraAgrupado",
										Header: "Mostra Agrupado",
										width: 300,
										filterable: false,
										Cell: ({ row }) => {
											return (
												<Botao
													secondary={!row.mostraAgrupado}
													ic
													icon={row.mostraAgrupado ? "icon-lx-check" : "icon-lx-close"}
												/>
											);
										}
									}
								]}
								rows={this.state.grupoClientes}
							/>
						)}
				</section>
			</main>
		);
	}
}

ScreenGrupoClientes = withRouter(ScreenGrupoClientes);
export { ScreenGrupoClientes };