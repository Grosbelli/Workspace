import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Select,
    FormOptions,
    handleInputChange,
    Checkbox,
    Checkitem,
    InputDate,
    InputTime
} from "../../formulario/Formulario";
import { List } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";
import { toFloatFormattedDisplay } from "../../../utils/Utils";
import moment from "moment";
import { CNPJ_DEFAULT } from '../../../constants/Const';

import {
    getTanques,
    getTanque,
    incluirTanque,
    alterarTanque,
    excluirTanque
} from "../../../services/Tanque";

import { getCombustivel, getTipoAlmoxarifadoComb } from "../../../services/Produto";

class FormCadastroTanque extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            cnpjEstabelecimento = CNPJ_DEFAULT,
            codigoTanque = null,
            numeroTanque = "",
            codigoProduto = 1,
            capacidade = "",
            percentualErroMedicao = "",
            dataAtivacao = moment(),
            motivoAlteracao = "",
            codigoTipoAlmoxarifado = 2,
            possuiBicosAtivos = false,
            possuiMovimentacaoEstoque = false,
            inativo = false,
            rowVersion = null,

            dataAlteracao = moment(),
            horaAlteracao = "",

            tipoAlmoxarifado = "",
            produto = "",

            dataAtivAnterior,
            tipoTanqueAnterior,
            produtoAnterior,

            volumeAtual = "0,00"
        } = this.props.tanque;

        this.state = {
            cnpjEstabelecimento,
            codigoTanque,
            numeroTanque,
            codigoProduto,
            capacidade,
            percentualErroMedicao,
            dataAtivacao,
            motivoAlteracao,
            codigoTipoAlmoxarifado,
            possuiBicosAtivos,
            possuiMovimentacaoEstoque,
            ativo: !inativo,
            rowVersion,

            horaAlteracao,
            dataAlteracao,

            tipoAlmoxarifado,
            produto,

            volumeAtual,
            //para verificação da data de ativação
            dataAtivAnterior,
            tipoTanqueAnterior,
            produtoAnterior,

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            tanquesExistentes: []
        };
    }

    //Para o combo produto
    async componentDidMount() {
        const { data: produtos } = await getCombustivel(this.state.cnpjEstabelecimento);
        this.setState({
            produtos: produtos.map(produto => {
                return {
                    label: produto.descricao,
                    value: produto.codigo
                }
            })
        });

        const { data: almoxarifados } = await getTipoAlmoxarifadoComb(this.state.cnpjEstabelecimento);
        this.setState({
            almoxarifados: almoxarifados.map(almoxarifado => {
                return {
                    label: almoxarifado.descricao,
                    value: almoxarifado.codigo
                }
            })
        });
    }

    handleAlertAction = async (resp) => {
        const { alertType,
            cnpjEstabelecimento,
            codigoTanque } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/tanquebombabico/");
                break;

            case "question":
                if (resp) {
                    try {
                        //caso for tanque  
                        //somente é permitido inativar com volume atual zerado
                        if (parseFloat(this.state.volumeAtual) > 0 && this.state.codigoTipoAlmoxarifado === 2) {
                            this.showError("Não é permitido inativar tanque com volume maior que zero");
                        }
                        else {
                            if (this.state.possuiBicosAtivos && this.state.codigoTipoAlmoxarifado === 2) {
                                this.showError("Não é possível excluir tanques com bicos vinculados e ativos. Os bicos devem ser direcionados para o outro tanque ou inativados");
                            }
                            else {
                                if (this.state.possuiMovimentacaoEstoque) {
                                    this.showError("Não é possível excluir tanques que possui movimentação de estoque");
                                }
                                else {
                                    await excluirTanque(codigoTanque, cnpjEstabelecimento);
                                    this.showInfo("Tanque excluído com sucesso!");
                                }
                            }
                        }
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/tanquebombabico/");
                }
                break;


            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Tanque",
            alertSubtitle: message
        });
    }

    handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Tanque",
            alertSubtitle: "Deseja excluir?"
        });
    }

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Tanque",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    handleSalvar = async () => {
        const {
            cnpjEstabelecimento,
            codigoTanque,
            numeroTanque,
            codigoProduto,
            capacidade,
            percentualErroMedicao,
            dataAtivacao,
            motivoAlteracao,
            codigoTipoAlmoxarifado,
            ativo,
            rowVersion,

            horaAlteracao,
            dataAlteracao,

            tipoAlmoxarifado,
            produto,
            possuiMovimentacaoEstoque

        } = this.state,
            inativo = !ativo;

        //Se for compressor não salva os dados volume e capacidade, pois não estarão nem visiveis.
        if (parseInt(this.state.codigoTipoAlmoxarifado) !== 2) {
            //volumeAtual = "";
            this.state.capacidade = "";
        }

        const [action, params] =
            codigoTanque !== null
                ? [
                    alterarTanque,
                    [
                        cnpjEstabelecimento,
                        codigoTanque,
                        numeroTanque,
                        codigoProduto,
                        capacidade,
                        percentualErroMedicao,
                        moment(dataAtivacao).format("YYYY-MM-DD") + "T" + moment(dataAtivacao).format("HH:mm:ss"),
                        moment(dataAlteracao).format("YYYY-MM-DD") + "T" + horaAlteracao + " " + motivoAlteracao,
                        inativo,
                        rowVersion
                    ]
                ]
                : [
                    incluirTanque,
                    [
                        cnpjEstabelecimento,
                        numeroTanque,
                        codigoTipoAlmoxarifado,
                        codigoProduto,
                        capacidade,
                        percentualErroMedicao,
                        dataAtivacao
                    ]
                ];

        let temErros = this.verificaTanque();

        if ((!temErros) && (action === incluirTanque)) {
            temErros = this.verificaTanqueExistente(this.state.numeroTanque);
        }

        if (!temErros) {
            try {
                const resp = await action(...params);
                this.setState({
                    alertActive: true,
                    alertType: "success",
                    alertTitle: "Tanque",
                    alertSubtitle: `Tanque  ${codigoTanque === null ? "cadastrado" : "alterado"} com sucesso!`
                });
            } catch (err) {
                this.setState({
                    alertActive: true,
                    alertType: "error",
                    alertTitle: "Erro",
                    alertSubtitle: err.response.data.message
                });
            }
        }
    };


    verificaTanque = () => {
        //verifica preenchimento dos campos
        if ((this.state.codigoTipoAlmoxarifado) === "") {
            this.showError("É obrigatório informar o tipo de tanque");
            return true;
        }
        if (this.state.numeroTanque === "") {
            this.showError("É obrigatório informar o número do tanque");
            return true;
        }
        if (this.state.codigoProduto === "") {
            this.showError("É obrigatório informar o combustível");
            return true;
        }
        if (this.state.percentualErro) {
            this.showError("É obrigatório informar o percentual de erro na medição");
            return true;
        }
        if (this.state.percentualErro <= 0 || this.state.percentualErro > 99.99) {
            this.showError("O percentual de erro na medição deve ser entre 0,01 e 99,99");
            return true;
        }
        if (this.state.dataAtivacao === "") {
            this.showError("É obrigatório informar a data de ativação");
            return true;
        }
        if (!moment(this.state.dataAtivacao, "YYYY-MM-DD").isValid()) {
            this.showError("Data de ativação inválida");
            return true;
        }
        if (moment(this.state.dataAtivacao).isAfter(moment().add(1, "months"))) {
            this.showError("Data de ativação não deve ser superior a um mês.");
            return true;
        }
        if (this.state.capacidade === "" && parseInt(this.state.codigoTipoAlmoxarifado) === 2) {
            this.showError("É obrigatório informar capacidade");
            return true;
        }
        //Se tiver em alteração e for um tanque.
        //Se o produto tiver mudado e a data de ativação permanecer igual, a mesma deve ser alterada.
        if (this.state.codigoTanque !== null && parseInt(this.state.codigoTipoAlmoxarifado) === 2) {
            if (this.state.produtoAnterior !== this.state.codigoProduto && moment(this.state.dataAtivAnterior).isSame(this.state.dataAtivacao)) {
                this.showError("Você está alterando o produto do tanque. Deve ser informada a data da alteração no campo Data de ativação");
                return true;
            }
        }

        //Validações para o momento de alteração
        if (this.state.codigoTanque !== null) {
            if (this.state.dataAlteracao === "") {
                this.showError("É obrigatório informar a data de alteração");
                return true;
            }
            if (!moment(this.state.dataAlteracao, "YYYY-MM-DD").isValid()) {
                this.showError("Data de alteração inválida");
                return true;
            }
            if (moment(this.state.dataAlteracao, "YYYY-MM-DD") < moment(this.state.dataAtivacao, "YYYY-MM-DD")) {
                this.showError("A data de alteração deve ser igual ou superior a data de ativação informada");
                return true;
            }
            if (this.state.horaAlteracao === "") {
                this.showError("É obrigatório informar a hora de alteração");
                return true;
            }
            if (!moment(this.state.horaAlteracao, "HH:mm:ss").isValid()) {
                this.showError("Hora de alteração inválida");
                return true;
            }
            if (!this.state.motivoAlteracao) {
                this.showError("É obrigatório informar o motivo de alteração");
                return true;
            }
            if (this.state.possuiMovimentacaoEstoque) {
                this.showError("Não é possível alterar o produto, pois existe movimentação de estoque.");
                return true;
            }
        }
    }

    verificaTanqueExistente = (numTanque) => {
        let existeTanque = false;
        let lista = this.state.tanquesExistentes;
        for (let i = 0; i < lista.length; i++) {
            const tanque = lista[i];
            if (parseInt(tanque.numeroTanque) === numTanque) {
                existeTanque = true;
            }
        }
        if (existeTanque) {
            this.showError("Já existe tanque cadastrado com os valores informados");
        }
        return existeTanque;
    }

    changeSelect = (event) => {
        let value;
        value = this.state.codigoProduto;

        //validação apenas válida para alteração
        if (this.state.codigoTanque !== null) {
            //Adicionar o bicos associados a validação (esperar API)
            if (parseInt(this.state.volumeAtual) !== 0) {
                this.showError("Alteração de produto permitida apenas para volume atual zerado");
            }
            else {
                if (this.state.possuiBicosAtivos) {
                    this.showError("Alteração de produto permitida apenas para tanque sem bicos associadas com turno em aberto");
                }
                else {
                    value = event.target.value;
                }
            }
        }
        else {
            value = event.target.value;
        }
        this.setState({ codigoProduto: value });
    }

    render() {
        const {
            codigoTanque,
            numeroTanque,
            codigoProduto,
            capacidade,
            percentualErroMedicao,
            dataAtivacao,
            codigoTipoAlmoxarifado,
            ativo,

            volumeAtual,
            produtos,
            almoxarifados,

            horaAlteracao,
            dataAlteracao,
            motivoAlteracao,

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;

        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-5">
                                <Select
                                    label="Tipo"
                                    name="codigoTipoAlmoxarifado"
                                    value={codigoTipoAlmoxarifado}
                                    onChange={this.handleInputChange}
                                    options={almoxarifados}
                                    tabindex={1}
                                    disabled={codigoTanque !== null}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Número tanque"
                                    value={numeroTanque}
                                    name="numeroTanque"
                                    type="number"
                                    maxlength="4"
                                    onChange={this.handleInputChange}
                                    disabled={codigoTanque !== null}
                                    allowNegative={false}
                                    tabindex={2}
                                    decimalScale={0}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <Select
                                    label="Produto"
                                    name="codigoProduto"
                                    value={codigoProduto}
                                    onChange={this.changeSelect}
                                    options={produtos}
                                    required
                                    tabindex={3}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="% de erro na medição"
                                    value={percentualErroMedicao}
                                    name="percentualErroMedicao"
                                    type="number"
                                    maxlength="5"
                                    decimalScale={2}
                                    required
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={4}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputDate
                                    label="Data de ativação"
                                    name="dataAtivacao"
                                    value={(dataAtivacao ? moment(dataAtivacao) : moment())}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-12">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                        disabled={codigoTanque === null}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                    </SectionContent>
                    <SectionContent title="" visible={parseInt(this.state.codigoTipoAlmoxarifado) === 2 ? true : false}>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="Volume atual"
                                    value={volumeAtual}
                                    name="volumeAtual"
                                    type="number"
                                    maxlength="12"
                                    decimalScale={2}
                                    required
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={7}
                                    //nunca deixa editar
                                    disabled={true}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Capacidade"
                                    value={capacidade}
                                    name="capacidade"
                                    type="number"
                                    maxlength="12"
                                    decimalScale={2}
                                    required
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={8}
                                />
                            </div>
                        </div>
                    </SectionContent>
                    <SectionContent title="" visible={this.state.codigoTanque !== null ? true : false}>
                        <div className="row">
                            <div className="col-5">
                                <InputDate
                                    label="Data da alteração"
                                    name="dataAlteracao"
                                    value={(dataAlteracao ? moment(dataAlteracao) : moment())}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-5">
                                <InputTime className="input time"
                                    required
                                    label="Hora de alteração"
                                    value={horaAlteracao}
                                    name="horaAlteracao"
                                    showSeconds
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Motivo da alteração"
                                    value={motivoAlteracao}
                                    name="motivoAlteracao"
                                    maxlength="250"
                                    required
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>
                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={
                        codigoTanque !== null ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

FormCadastroTanque = withRouter(FormCadastroTanque);

class ScreenCadastroTanque extends Component {
    state = {
        tanques: [],
        tanqueSel: {}
    };

    async doMount() {
        const { data: t } = await getTanques(CNPJ_DEFAULT);
        const tanqueArray = t.result;
        const tanqs = tanqueArray.map(tq => {
            return {
                codigoTanque: tq.codigoTanque,
                numeroTanque: tq.numeroTanque,
                codigoProduto: tq.codigoProduto,
                capacidade: tq.capacidade,
                percentualErroMedicao: tq.percentualErroMedicao,
                dataAtivacao: tq.dataAtivacao,
                motivoAlteracao: tq.motivoAlteracao,
                codigoTipoAlmoxarifado: tq.codigoTipoAlmoxarifado,
                possuiBicosAtivos: tq.possuiBicosAtivos,
                possuiMovimentacaoEstoque: tq.possuiMovimentacaoEstoque,
                inativo: tq.inativo,
                rowVersion: tq.rowVersion,
                dataAlteracao: moment().format("YYYY-MM-DD"),
                horaAlteracao: moment().format("HH:mm:ss"),

                tipoAlmoxarifado: tq.tipoAlmoxarifado,
                produto: tq.produto,

                volumeAtual: tq.volumeAtual,
                //para verificação da data de ativação
                dataAtivAnterior: tq.dataAtivacao,
                tipoTanqueAnterior: tq.codigoTipoAlmoxarifado,
                produtoAnterior: tq.codigoProduto
            }
        }
        )

        const { data: tp } = await getTipoAlmoxarifadoComb(CNPJ_DEFAULT);
        const tiposArray = tp;
        this.setState({ tiposArray });

        const { data: c } = await getCombustivel(CNPJ_DEFAULT);
        const combsArray = c;
        this.setState({ combsArray });

        for (let i = 0; i < tanqs.length; i++) {
            tanqs[i].descricaoComb = this.buscaDescricaoComb(tanqs[i].codigoProduto);
            tanqs[i].descricaoTipo = this.buscaDescricaoTipo(tanqs[i].codigoTipoAlmoxarifado);
        }

        const tqMoOrd = tanqs.sort(function (a, b) {
            if (parseInt(a.numeroTanque) < parseInt(b.numeroTanque)) return -1;
            if (parseInt(a.numeroTanque) > parseInt(b.numeroTanque)) return 1;
            return 0;
        });

        this.setState({ tanques: tqMoOrd });
    }

    async componentDidMount() {
        this.doMount();
    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            this.doMount();
        }
    }

    buscaDescricaoTipo = (codigotipo) => {
        let tipos = this.state.tiposArray;
        for (let i = 0; i < tipos.length; i++) {
            const t = tipos[i];
            if (parseInt(t.codigo) === parseInt(codigotipo)) {
                var descTipo = t.descricao;
                break;
            }
        }
        return descTipo;
    }

    buscaDescricaoComb = (codigoProd) => {
        let combs = this.state.combsArray;
        for (let i = 0; i < combs.length; i++) {
            const comb = combs[i];
            if (parseInt(comb.codigo) === parseInt(codigoProd)) {
                var descComb = comb.descricao;
                break;
            }
        }
        return descComb;
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) {
            // se clicar numa linha vazia, não faz nada
            this.setState({ tanqueSel: rowInfo.original });
            this.props.history.push("/tanque/new", { tanqueSel: rowInfo.original, tanquesExistentes: this.state.tanque });
        }
    }

    render() {
        const { edit } = this.props;
        let tanqueSel = {};
        if (edit) {
            // this.props.location.state por padrao eh undefined
            if (this.props.location.state)
                tanqueSel = this.props.location.state.tanqueSel;
        }
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Tanques"
                        subtitle=""
                        /*  <div className="section-header-search">
                                <InputText placeholder="Buscar" icone="icon-lx-search" />
                            </div>
                        */
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ tanqueSel: {} });
                                            this.props.history.push("/tanque/new", { tanqueSel: {} });
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <FormCadastroTanque
                            tanque={tanqueSel}
                            tanquesExistentes={this.state.tanque}
                        />
                    ) : (
                            <List
                                defaultPageSize={5}
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "descricaoTipo",
                                        Header: "Tipo",
                                        width: 150,
                                        filterable: false
                                    },
                                    {
                                        accessor: "numeroTanque",
                                        Header: "Número",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricaoComb",
                                        Header: "Produto",
                                        width: 250,
                                        filterable: false
                                    },
                                    {
                                        accessor: "capacidade",
                                        Header: "Capacidade",
                                        width: 200,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {toFloatFormattedDisplay(props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "volumeAtual",
                                        Header: "Volume atual",
                                        width: 200,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {toFloatFormattedDisplay(props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "inativo",
                                        Header: "Ativo",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={row.inativo}
                                                    ic
                                                    icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.tanques}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenCadastroTanque = withRouter(ScreenCadastroTanque);
export { ScreenCadastroTanque };