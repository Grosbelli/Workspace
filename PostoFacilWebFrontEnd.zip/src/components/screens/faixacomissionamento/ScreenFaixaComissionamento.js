import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { List } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getFaixaComissionamento,
    incluirFaixaComissionamento,
    alterarFaixaComissionamento,
    excluirFaixaComissionamento
} from "../../../services/FaixaComissionamento";

import {
    getSetores
} from "../../../services/Setores";


class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            codigoEstabelecimento = "1",
            codigoSetor = "2",
            codigoAlmoxarifado = null,
            tipo = "",
            descricao = "",
            faixaInicial = "",
            faixaFinal = "",
            percentual = "",
            excluido = false,
            rowVersion = null
        } = this.props.faixaComissionamento;

        this.state = {
            codigo,
            codigoEstabelecimento,
            codigoSetor,
            codigoAlmoxarifado,
            tipo,
            descricao,
            faixaInicial,
            faixaFinal,
            percentual,
            excluido,
            rowVersion,

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            faixasExistentes: []

        };
    }


    async componentDidMount() {
        const { data: setores } = await getSetores(1);
        this.setState({
            setores: setores.map(setor => {
                return {
                    label: setor.descricao,
                    value: setor.codigo
                }
            })
        });
    }

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoEstabelecimento,
            codigo } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/faixacomissionamento/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluirFaixaComissionamento(codigoEstabelecimento, codigo);
                        //sucesso
                        console.log("sucesso");
                        this.showInfo("Faixa de comissionamento excluída com sucesso!");
                    } catch (err) {
                        // falha
                        console.log("fallha");
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/faixacomissionamento/");
                }
                break;


            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
           /* codigo: null,
            codigoEstabelecimento: "",
            codigoSetor: null,
            rowVersion: null,
            faixaInicial: null,
            faixaFinal: null,
            percentual: null,*/
            alertActive: true,
            alertType: "success",
            alertTitle: "Faixa de comissionamento",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {
            codigo,
            codigoEstabelecimento,
            codigoSetor,
            faixaInicial,
            faixaFinal,
            percentual,
            rowVersion,
        } = this.state;

        const [action, params] =
            codigo !== null
                ? [
                    alterarFaixaComissionamento,
                    [
                        codigo,
                        codigoEstabelecimento,
                        codigoSetor,
                        faixaInicial,
                        faixaFinal,
                        percentual,
                        rowVersion
                    ]
                ]
                : [
                    incluirFaixaComissionamento,
                    [
                        codigoEstabelecimento,
                        codigoSetor,
                        faixaInicial,
                        faixaFinal,
                        percentual
                    ]
                ];

        let temErros = this.verificaFaixaComisionamento();

        if ((!temErros) && (action === incluirFaixaComissionamento)) {
            temErros = this.verificaFaixaExistente(this.state.faixaInicial, this.state.faixaFinal);
        }

        if (!temErros) {

            try {
                const resp = await action(...params);
                console.log(resp);
                this.setState({
                    /*codigo: null,
                    codigoEstabelecimento: "1",
                    codigoSetor: "2",
                    codigoAlmoxarifado: null,
                    tipo: "",
                    descricao: "",
                    faixaInicial: null,
                    faixaFinal: null,
                    percentual: null,
                    excluido: false,
                    rowVersion: null,*/
                    alertActive: true,
                    alertType: "success",
                    alertTitle: "Faixa de comissionamento",
                    alertSubtitle: `Faixa de comissionamento  ${codigo === null ? "cadastrada" : "alterada"} com sucesso!`
                });
            } catch (err) {
                this.setState({
                    alertActive: true,
                    alertType: "error",
                    alertTitle: "Erro",
                    alertSubtitle: err.response.data.message
                });
            }
        }
    };

    handleExcluir = () => {
        console.log("excluir");
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Faixa de comissionamento",
            alertSubtitle: "Deseja excluir?"
        });
    }

    handleCancelar = () => {
        console.log("cancelar");
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Faixa de comissionamento",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    handleBlur = (event) => {
        let labelCampo = "";
        let campo = event.target;
        if (this.state[campo.name] === "") {
            switch (campo.name) {
                case "faixaInicial":
                    labelCampo = "Faixa inicial";
                    break;

                case "faixaFinal":
                    labelCampo = "Faixa final";
                    break;

                case "percentual":
                    labelCampo = "Comissão";
                    break;

                default:
                    break;
            }
            this.showError("É obrigatório informar " + labelCampo);
        }
    }

    verificaFaixaComisionamento = () => {
        //verifica preenchimento dos campos
        if (this.state.faixaInicial === "") {
            this.showError("É obrigatório informar Faixa inicial");
            return true;
        }

        if (parseFloat(this.state.faixaInicial) === 0) {
            this.showError("A faixa inicial deve ser maior que zero");
            return true;
        }

        if (this.state.faixaFinal === "") {
            this.showError("É obrigatório informar Faixa final");
            return true;
        }

        //verifica faixaInicial maior que final
        if (parseFloat(this.state.faixaFinal) < parseFloat(this.state.faixaInicial)) {
            this.showError("A faixa final não pode ser menor que a faixa inicial");
            return true;
        }

        // verifica valor da comissao
        if (this.state.percentual <= 0 || this.state.percentual > 99.99) {
            this.showError("O valor da comissão deve ser entre 0,01 e 99,99");
            return true;
        }
        return false;
    }

    verificaFaixaExistente = (valorFaixaInicial, valorFaixaFinal) => {
        let existeFaixa = false;
        let lista = this.state.faixasExistentes;
        for (let i = 0; i < lista.length; i++) {
            const faixa = lista[i];
            if ((valorFaixaInicial >= faixa.faixaInicial &&
                valorFaixaInicial <= faixa.faixaFinal) ||
                (valorFaixaFinal >= faixa.faixaInicial &&
                    valorFaixaFinal <= faixa.faixaFinal)) {
                existeFaixa = true;
            }
        }
        if (existeFaixa) {
            this.showError("Já existe faixa de comissionamento para o intervalo de valores informados");
        }
        return existeFaixa;
    }

    render() {
        const {
            codigo,
            codigoSetor,
            faixaInicial,
            faixaFinal,
            percentual,
            setores,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-4">
                                <Select
                                    label="Setor:"
                                    name="codigoSetor"
                                    value={codigoSetor}
                                    onChange={this.handleInputChange}
                                    options={setores}
                                    required
                                    disabled={codigoSetor === null}
                                    autofocus="true"
                                    tabindex={1}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    label="Faixa inicial:"
                                    value={faixaInicial}
                                    name="faixaInicial"
                                    type="number"
                                    maxlength="14"
                                    decimalScale={2}
                                    required
                                    onBlur={this.handleBlur}
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={2}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    label="Faixa final:"
                                    value={faixaFinal}
                                    name="faixaFinal"
                                    type="number"
                                    maxlength="14"
                                    decimalScale={2}
                                    required
                                    onBlur={this.handleBlur}
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={3}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    type="number"
                                    label="Comissão (%):"
                                    decimalScale={2}
                                    value={percentual}
                                    name="percentual"
                                    maxlength="5"
                                    required
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={4}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={
                        codigo !== null ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}

                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenFaixaComissionamento extends Component {
    state = {
        FaixaComissionamentos: [],
        faixaComissionamentoSel: {}
    };

    async componentDidMount() {
        const { data: faixaComissionamentos } = await getFaixaComissionamento(1);
        this.setState({ faixaComissionamentos });
    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            const { data: faixaComissionamentos } = await getFaixaComissionamento(1);
            this.setState({ faixaComissionamentos });
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        //debugger;
        if (rowInfo) { // se clicar numa linha vazia, não faz nada
            this.setState({ faixaComissionamentoSel: rowInfo.original });
            this.props.history.push("/faixacomissionamento/new");
        }
    }

    toFloatFormattedDisplay(numberString) {
        let number = parseFloat(numberString);
        let s = number.toLocaleString("pt-br");
        return number % 1 === 0 ? (s + ",00") : (s);
    }

    render() {
        const { edit } = this.props,
            { faixaComissionamentoSel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Faixa de comissionamento"
                        subtitle=""
                        /*  <div className="section-header-search">
                                <InputText placeholder="Buscar" icone="icon-lx-search" />
                            </div>
                                */
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ faixaComissionamentoSel: {} });
                                            this.props.history.push("/faixacomissionamento/new")
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form
                            faixaComissionamento={faixaComissionamentoSel}
                            faixasExistentes={this.state.faixaComissionamentos}
                        />
                    ) : (

                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "tipo",
                                        Header: "Tipo",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "descricao",
                                        Header: "Descrição",
                                        width: 200,
                                        filterable: false
                                    },
                                    {
                                        accessor: "faixaInicial",
                                        Header: "Faixa inicial",
                                        width: 150,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {this.toFloatFormattedDisplay(
                                                    props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "faixaFinal",
                                        Header: "Faixa final",
                                        width: 150,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {this.toFloatFormattedDisplay(props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "percentual",
                                        Header: "Percentual (%)",
                                        width: 150,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {this.toFloatFormattedDisplay(props.value)}
                                            </div>
                                    }
                                ]}
                                rows={this.state.faixaComissionamentos}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenFaixaComissionamento = withRouter(ScreenFaixaComissionamento);
export { ScreenFaixaComissionamento };
