/* eslint-disable no-array-constructor */
import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import {
    InputText,
    Checkbox,
    Checkitem,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { List } from "../../formulario/List";
import { SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";
import {
    incluiSubConta,
    excluiSubConta,
    alteraSubConta,
    montaComboReceitaDespesa,
    montaComboPagarReceber,
    montaComboGrupo,
    montaComboTipoConta,
    montaComboNaturezaSped
} from "../../../services/Contas";
import { getDateIndex, getMeses } from "../../../utils/Utils";
import moment from "moment";
import { Total } from "./ScreenContasCadastroPai";
import { getSetores } from "../../../services/Setores";
import { montaComboRede } from "../../../services/EstruturaCartoes";


export const TipoConta = {
    None: -1,
    AFaturar: 1,
    Absorcao: 2,
    CartaoCredito: 3,
    CartaoDebito: 4,
    CartaoVale: 5,
    Cheque: 6,
    ContaContabilSPED: 7,
    Cracha: 8,
    CTF: 9,
    Dinheiro: 10,
    FaltaSobra: 11,
    ParceladoLojista: 12,
    ParceladoRede: 13,
    Ticket: 14,
    Vale: 15,
    ValeFuncionario: 16
};

export const TiposContas = [
    { value: TipoConta.None, label: "Selecione um tipo de conta" },
    { value: TipoConta.AFaturar, label: "A faturar" },
    { value: TipoConta.Absorcao, label: "Absorção" },
    { value: TipoConta.CartaoCredito, label: "Cartão Crédito" },
    { value: TipoConta.CartaoDebito, label: "Cartão Débito" },
    { value: TipoConta.CartaoVale, label: "Cartão Vale" },
    { value: TipoConta.Cheque, label: "Cheque" },
    { value: TipoConta.ContaContabilSPED, label: "Conta contábil para o SPED" },
    { value: TipoConta.Cracha, label: "Crachá" },
    { value: TipoConta.CTF, label: "CTF" },
    { value: TipoConta.Dinheiro, label: "Dinheiro" },
    { value: TipoConta.FaltaSobra, label: "Falta/Sobra" },
    { value: TipoConta.ParceladoLojista, label: "Parcelado Lojista" },
    { value: TipoConta.ParceladoRede, label: "Parcelado Rede" },
    { value: TipoConta.Ticket, label: "Ticket" },
    { value: TipoConta.Vale, label: "Vale" },
    { value: TipoConta.ValeFuncionario, label: "Vale de funcionário" }];


export const TipoPagarReceber = {
    None: "",
    AReceber: "C",
    APagar: "D"
};

export const TiposPagarReceber = [
    { value: TipoPagarReceber.None, label: "Selecione a natureza da conta" },
    { value: TipoPagarReceber.AReceber, label: "A Receber" },
    { value: TipoPagarReceber.APagar, label: "A Pagar" }
];

export const TipoReceitaDespesa = {
    None: -1,
    Operacional: 1,
    NaoOperacional: 2
};

export const TiposReceitasDespesas = [
    {
        value: TipoReceitaDespesa.None,
        label: "Selecione o tipo de receita/despesa"
    },
    { value: TipoReceitaDespesa.Operacional, label: "Operacional" },
    { value: TipoReceitaDespesa.NaoOperacional, label: "Não operacional" }
];

export const CodigoNaturezaSped = {
    None: -1,
    ContaAtivo: 1,
    ContaPassivo: 2,
    PatrimonioLiquido: 3,
    ContaResultado: 4,
    ContaCompensacao: 5,
    Outras: 9
};

export const CodigosNaturezaSped = [
    {
        value: CodigoNaturezaSped.None,
        label: "Selecione um código de natureza do SPED"
    },
    { value: CodigoNaturezaSped.ContaAtivo, label: "Conta de ativo" },
    { value: CodigoNaturezaSped.ContaPassivo, label: "Conta de passivo" },
    {
        value: CodigoNaturezaSped.PatrimonioLiquido,
        label: "Patrimônio líquido"
    },
    { value: CodigoNaturezaSped.ContaResultado, label: "Conta de resultado" },
    {
        value: CodigoNaturezaSped.ContaCompensacao,
        label: "Conta de compensação"
    },
    { value: CodigoNaturezaSped.Outras, label: "Outras" },
];

export const IndicadorTipoContaSped = {
    None: -1,
    Sintetica: 1,
    Analitica: 2
};

export const IndicadoresTiposContasSped = [
    {
        value: IndicadorTipoContaSped.None,
        label: "Selecione o indicador do tipo de conta do SPED"
    },
    { value: IndicadorTipoContaSped.Sintetica, label: "Sintética" },
    { value: IndicadorTipoContaSped.Analitica, label: "Analítica" }
];

export const RedeAutorizadora = {
    None: - 1
}

export const RedesAutorizadoras = [
    {
        value: RedeAutorizadora.None,
        label: "Selecione a rede autorizadora"
    }
]

export const Grupo = {
    None: -1
}

export const Grupos = [{ value: Grupo.None, label: "Selecione o grupo" }];

class FormSubConta extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            codigoPai = Grupo.None,
            descricao = "",
            conta = null,
            contaReduzida = null,
            pagarReceber = TipoPagarReceber.None,
            tipoConta = null,
            redeAutorizadora = null,
            tipoReceitaDespesa = TipoReceitaDespesa.None,
            codigoContaSped = null,
            codigoNaturezaSped = null,
            indicadorTipoContaSped = null,
            nivelContaSped = IndicadorTipoContaSped.None,
            //nivelContaSped = IndicadorTipoContaSped.Outras,
            inativo = false,
            restrito = false,
            exibir = true,
            sped = {},
            rateio = [],
            rowVersion = null,
        } = this.props.subconta;

        this.state = {
            codigo,
            codigoPai,
            descricao,
            conta,
            contaReduzida,
            pagarReceber,
            tipoConta,
            tipoContaCodigo: tipoConta ? tipoConta.codigo : TipoConta.None,
            redeAutorizadora,
            redeAutorizadoraCodigo: redeAutorizadora ? redeAutorizadora.codigo :
                RedeAutorizadora.None,
            tipoReceita: tipoReceitaDespesa,
            codigoContaSped,
            codigoNaturezaSped,
            indicadorTipoContaSped,
            nivelContaSped,
            ativo: !inativo,
            restrito,
            exibir,
            vigenciaMes: String(moment().month()),
            vigenciaAno: String(moment().year()),
            vigenciaAtual: getDateIndex(moment().month(), moment().year()),
            sped,
            rateio,
            listaRateios: new Array(),
            listaPagarReceber: [],
            listaTipos: [],
            listaReceitaDespesa: [],
            listaRedes: [],
            meses: getMeses(),
            anos: [],
            setores: [],
            totalRateio: 0,
            percentuais: new Array(),
            listaGrupos: [],
            tiposContasCartao: [],
            showRedes: false,
            originalmenteRestrito: restrito,
            listaNaturezaSped: [],
            listaIndicadoresTipoSped: [],
            showSped: false,
            codigoGrupoSped: Grupo.None,
            codigoTipoContaSped: TipoConta.None,

            rowVersion,

            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: "",

            subContaSel: [],
            subContasExistentes: []
        };
    }

    async componentDidMount() {
        //debugger;
        // declaradas no início para que o try-finally faça sentido
        let listaGrupos = [],
            listaPagarReceber = [],
            listaTipos = [],
            listaReceitaDespesa = [],
            listaRedes = [],
            setores = [],
            anos = [],
            percentuais = [],
            listaInterna = [],
            listaRateios = [],
            tiposContasCartao = [],
            listaNaturezaSped = [],
            listaIndicadoresTipoSped = [],
            codigoGrupoSped = Grupo.None,
            codigoTipoContaSped = TipoConta.None,
            showRedes = false;
        let { vigenciaAno, vigenciaAtual, tipoContaCodigo } = this.state;

        try {
            const { data: dataGrupos } = await montaComboGrupo();
            listaGrupos.push(Grupos[0]);
            dataGrupos.forEach((g) => {
                listaGrupos.push({ label: g.descricao, value: g.codigo });
                if (g.descricao.toUpperCase().includes("SPED")) {
                    codigoGrupoSped = g.codigo;
                }
            });

            const { data: dataPagarReceber } = await montaComboPagarReceber();
            listaPagarReceber.push(TiposPagarReceber[0]);
            dataPagarReceber.forEach((pr) => {
                listaPagarReceber.push({
                    label: pr.descricao,
                    value: pr.codigo
                });
            });

            const { data: dataTipos } = await montaComboTipoConta();
            listaTipos.push(TiposContas[0]);
            dataTipos.forEach((t) => {
                listaTipos.push({ label: t.descricao, value: t.codigo });
                if (t.descricao.toUpperCase().includes("CARTÃO")) {
                    tiposContasCartao.push(t.codigo);
                } else if (t.descricao.toUpperCase().includes("SPED")) {
                    codigoTipoContaSped = t.codigo;
                }
            });

            showRedes = tiposContasCartao.includes(tipoContaCodigo);

            const { data: dataReceitaDespesa } =
                await montaComboReceitaDespesa();
            listaReceitaDespesa.push(TiposReceitasDespesas[0]);
            dataReceitaDespesa.forEach((rd) => {
                listaReceitaDespesa.push({
                    label: rd.descricao,
                    value: rd.codigo
                });
            });

            const { data: dataRedes } = await montaComboRede(true);
            listaRedes.push(RedesAutorizadoras[0]);
            dataRedes.forEach((r) => {
                listaRedes.push({ label: r.descricao, value: r.codigo });
            });

            const { data: dataNaturezaSped } = await montaComboNaturezaSped();
            listaNaturezaSped.push(CodigosNaturezaSped[0]);
            dataNaturezaSped.forEach((n) => {
                listaNaturezaSped.push({ label: n.descricao, value: n.codigo });
            });

            const { data: dataIndicadores } = await montaComboRede(true);
            listaIndicadoresTipoSped.push(IndicadoresTiposContasSped[0]);
            dataIndicadores.forEach((i) => {
                listaIndicadoresTipoSped.push({
                    label: i.descricao,
                    value: i.codigo
                });
            });

            const { data } = await getSetores(1);
            data.forEach((s) => {
                if (String(s.descricao) !== "Lubrax") {
                    setores.push(s);
                }
            });

            for (let i = 0; i > -5; i--) {
                anos.push({
                    label: String(Number(vigenciaAno) + i),
                    value: Number(vigenciaAno) + i
                });
            };

            let totalRateio = 0,
                i = 1;
            const { rateio } = this.state;

            if (rateio && rateio.length > 0) {
                rateio.forEach((r) => {
                    listaInterna.push({
                        setor: {
                            descricao: r.setor.descricao,
                            codigo: r.setor.codigo
                        },
                        codigo: r.setor.codigo,
                        rateio: r.rateio,
                        mesInicio: String(Number(r.mesInicio - 1)),
                        anoInicio: String(r.anoInicio),
                        isTotalizador: false
                    });
                    totalRateio += r.rateio;
                    if (i >= 2 && i % 2 === 0) {
                        listaInterna.push(this.getRateioTotalizador(
                            totalRateio));
                        vigenciaAtual = getDateIndex(r.mesInicio - 1,
                            r.anoInicio);
                        // copia o array, pois não pode ser por referência                     
                        listaRateios[vigenciaAtual] = listaInterna.slice();
                        // limpa o array original, não a cópia de cima
                        listaInterna.length = 0;
                        totalRateio = 0;
                    }
                    i++;
                });

            } else {
                setores.forEach((s) => {
                    percentuais[s.codigo] = 0;
                    listaInterna.push({
                        setor: { descricao: s.descricao, codigo: s.codigo },
                        codigo: s.codigo,
                        rateio: Number(percentuais[s.codigo]),
                        mesInicio: this.state.vigenciaMes,
                        anoInicio: this.state.vigenciaAno,
                        isTotalizador: false
                    });
                }
                );
                listaInterna.push(this.getRateioTotalizador(totalRateio));

                listaRateios[vigenciaAtual] = listaInterna;
            }
        } finally {

            this.setState({
                listaPagarReceber,
                listaTipos,
                listaReceitaDespesa,
                anos,
                setores,
                vigenciaAtual,
                listaRedes,
                listaRateios,
                percentuais,
                listaGrupos,
                tiposContasCartao,
                showRedes,
                listaNaturezaSped,
                listaIndicadoresTipoSped,
                codigoGrupoSped,
                codigoTipoContaSped
            });
        }
    }

    handleAlertAction = async (resp) => {
        const {
            codigo,
            alertType
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/contas/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluiSubConta(codigo);
                        this.showInfo("Subconta excluída com sucesso!");
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/contas/");
                }
                break;
            default:
                break;
        }
    };

    isFormValid() {
        const {
            restrito,
            originalmenteRestrito,
            descricao,
            codigoPai,
            conta,
            tipoConta,
            tipoReceita,
            redeAutorizadora,
            pagarReceber,
            listaRateios,
            codigoContaSped,
            codigoNaturezaSped,
            indicadorTipoContaSped,
            nivelContaSped,
            meses,
            tiposContasCartao
        } = this.state;

        if (restrito && originalmenteRestrito) {
            return true;
        }

        if (!codigoPai || codigoPai === Grupo.None) {
            this.showError("Selecione o grupo da conta");
            return false;
        }

        if (!descricao) {
            this.showError("A descrição não pode ficar vazia");
            return false;
        }

        if (!conta) {
            this.showError("A conta não pode ficar vazia");
            return false;
        }

        if (!pagarReceber) {
            this.showError("Selecione a natureza da conta");
            return false;
        }

        /* // Não é obrigatório
        if (!tipoConta || tipoConta === TipoConta.None) {
            this.showError("Selecione um tipo para a conta");
            return false;
        } */

        if (tiposContasCartao.includes(Number(tipoConta)) &&
            (!redeAutorizadora || redeAutorizadora === RedeAutorizadora.None)) {
            this.showError("Selecione a rede autorizadora");
            return false;
        }

        if (tipoReceita === TipoReceitaDespesa.None) {
            this.showError("Selecione o tipo de receita/despesa da conta");
            return false;
        }

        if (Number(nivelContaSped) !== IndicadorTipoContaSped.None) {
            if (!codigoContaSped) {
                this.showError("O código da conta SPED não pode ficar vazio");
                return false;
            }

            if (!codigoNaturezaSped ||
                codigoNaturezaSped === CodigoNaturezaSped.None) {
                this.showError("Selecione o código da natureza da conta SPED");
                return false;
            }

            if (!indicadorTipoContaSped ||
                indicadorTipoContaSped === IndicadorTipoContaSped.None) {
                this.showError("Selecione o indicador de tipo de conta SPED");
                return false;
            }

            if (!Number(nivelContaSped)) { // === 0
                this.showError("O nível da conta SPED deve estar entre " +
                    "1 e 99.999");
                return false;
            }
        }

        let result = true; // return dentro do forEach finaliza apenas ele mesmo
        listaRateios.forEach((r) => {
            let total = this.getTotalRateio(r);
            if ((total > 0 && total < 100) || (total > 100)) {
                this.showError("Total do percentual de rateio de " +
                    meses[Number(r[0].mesInicio)].label + " de " +
                    r[0].anoInicio + " deve ser igual a 100%.");
                result = false;
                return;
            }
        });
        return result;
    }

    handleSalvar = async () => {
        if (!this.isFormValid()) {
            return;
        }

        let {
            codigo,
            codigoPai,
            descricao,
            conta,
            contaReduzida,
            pagarReceber,
            tipoContaCodigo,
            redeAutorizadoraCodigo,
            ativo,
            restrito,
            exibir,
            tipoReceita,
            //sped,
            //rateio,
            rowVersion,
            listaRateios,
            codigoContaSped,
            codigoNaturezaSped,
            indicadorTipoContaSped,
            nivelContaSped
        } = this.state;

        let inativo = !ativo;

        const listaRateiosParaEnviar = [];

        listaRateios.forEach((r) => {
            // rateio com total 0 não precisa ser enviado
            if (r && this.getTotalRateio(r) > 0) {
                // mexe numa cópia para não bagunçar o que está na tela
                // pois a API pode retornar algum erro
                const helper = r.filter((rat => rat.codigo !== Total.Codigo));
                helper.forEach((item) => {
                    item.mesInicio = Number(item.mesInicio) + 1;
                    listaRateiosParaEnviar.push(item);
                })
            }
        });

        const sped = {
            codigoConta: codigoContaSped,
            codigoNaturezaConta: codigoNaturezaSped,
            tipoConta: indicadorTipoContaSped,
            nivelConta: nivelContaSped
        };

        const rede = { codigo: redeAutorizadoraCodigo };
        const tipo = { codigo: tipoContaCodigo };

        const [action, params] =
            rowVersion === null
                ? [
                    incluiSubConta,
                    [
                        codigoPai,
                        descricao,
                        conta,
                        contaReduzida,
                        pagarReceber,
                        tipo,
                        rede,
                        inativo,
                        restrito,
                        exibir,
                        tipoReceita,
                        sped,
                        listaRateiosParaEnviar
                    ]
                ]
                : [
                    alteraSubConta,
                    [
                        codigo,
                        descricao,
                        conta,
                        contaReduzida,
                        pagarReceber,
                        tipo,
                        rede,
                        inativo,
                        restrito,
                        exibir,
                        tipoReceita,
                        sped,
                        listaRateiosParaEnviar,
                        rowVersion
                    ]
                ];

        try {
            await action(...params);
            this.showInfo(`Subconta ${rowVersion === null ?
                "incluída" : "alterada"} com sucesso!`);
        } catch (err) {
            this.showInfo(err.response.data.message);
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Subcontas",
            alertSubtitle: message
        });
    }

    handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Subcontas",
            alertSubtitle: "Deseja excluir?"
        });
    };

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Subcontas",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    };

    criaRateioVazio(mes, ano) {
        const { setores } = this.state;
        const rateioVazio = [];
        setores.forEach((s) => {
            rateioVazio.push({
                setor: { descricao: s.descricao, codigo: s.codigo },
                codigo: s.codigo,
                rateio: 0,
                mesInicio: mes ? mes : this.state.vigenciaMes,
                anoInicio: ano ? ano : this.state.vigenciaAno,
                isTotalizador: s.codigo === Total.Codigo
            });
        }
        );
        rateioVazio.push(this.getRateioTotalizador(0));
        return rateioVazio;
    }

    getRateioTotalizador(totalRateio) {
        return {
            setor: { descricao: Total.Label, codigo: Total.Codigo },
            codigo: Total.Codigo,
            rateio: totalRateio,
            mesInicio: this.state.vigenciaMes,
            anoInicio: this.state.vigenciaAno,
            isTotalizador: true,
        };
    }

    getTotalRateio(rateios) {
        let total = 0;
        if (rateios) {
            rateios.forEach((r) => {
                if (Number(r.codigo) !== Total.Codigo)
                    total += r.rateio ? Number(r.rateio) : 0;
                //total += String(p) === "" ? 0 : p;
            });
        }
        return total;
    }

    handleChangeGrid = (value, name, codigo) => {
        // se é a linha de total, não precisa fazer o processo
        if (codigo === Total.Codigo)
            return;

        const { listaRateios, vigenciaAtual } = this.state;
        const rateios = listaRateios[vigenciaAtual].map(r => {
            if (r.codigo === codigo) {
                return { ...r, [name]: value };
            } else {
                return r;
            }
        });
        const totalRateio = this.getTotalRateio(rateios);
        const { percentuais } = this.state;
        rateios.forEach((r) => {
            if (Number(r.codigo) === Total.Codigo) {
                r.rateio = totalRateio;
            }
            else {
                percentuais[r.codigo] = r.rateio;
            }
        });

        listaRateios[vigenciaAtual] = rateios;

        this.setState({ listaRateios, totalRateio, percentuais });
    };

    handleMesChange = (event) => {
        const vigenciaMes = event.target.value;
        const { vigenciaAno } = this.state;
        const vigenciaAtual = getDateIndex(vigenciaMes, vigenciaAno);
        const { listaRateios } = this.state;
        if (!listaRateios[vigenciaAtual])
            listaRateios[vigenciaAtual] = this.criaRateioVazio(vigenciaMes,
                vigenciaAno);
        this.setState({ vigenciaMes, vigenciaAtual, listaRateios });
    }

    handleAnoChange = (event) => {
        const vigenciaAno = event.target.value;
        const { vigenciaMes } = this.state;
        const vigenciaAtual = getDateIndex(vigenciaMes, vigenciaAno);
        const { listaRateios } = this.state;
        if (!listaRateios[vigenciaAtual])
            listaRateios[vigenciaAtual] = this.criaRateioVazio(vigenciaMes,
                vigenciaAno);
        this.setState({ vigenciaAno, vigenciaAtual, listaRateios });
    }

    handleTipoContaChange = (event) => {
        let tipoContaCodigo = event.target.value;
        const showRedes = this.state.tiposContasCartao.includes(Number(
            tipoContaCodigo));
        let { 
            codigoPai, 
            codigoGrupoSped, 
            codigoTipoContaSped 
        } = this.state;
        if(Number(codigoPai) !== Number(codigoGrupoSped) && 
            Number(tipoContaCodigo) === Number(codigoTipoContaSped)) {
            tipoContaCodigo = TipoConta.None;
            this.showError("Tipo de conta contábil para o SPED é exclusiva do grupo SPED");        
            }   
        this.setState({ tipoContaCodigo, showRedes });
    }

    handleGrupoChange = (event) => {        
        const codigoPai = event.target.value;
        let { 
            codigoGrupoSped, 
            codigoTipoContaSped, 
            tipoContaCodigo 
        } = this.state;

        const showSped = Number(codigoPai) === Number(codigoGrupoSped);

        if(showSped){
            tipoContaCodigo = codigoTipoContaSped;
        } else if (Number(tipoContaCodigo) === Number(codigoTipoContaSped)) {
            tipoContaCodigo = TipoConta.None; // limpa pois o tipo de conta sped é exclusivo
        }

        this.setState({ codigoPai, showSped, tipoContaCodigo });
    }

    ifShow(condition, divName) {
        return condition ? divName : "content-hidden";
    }

    render() {
        const {
            codigo,
            codigoPai,
            descricao,
            conta,
            contaReduzida,
            pagarReceber,
            tipoContaCodigo,
            redeAutorizadoraCodigo,
            tipoReceita,
            codigoContaSped,
            codigoNaturezaSped,
            indicadorTipoContaSped,
            nivelContaSped,
            ativo,
            restrito,
            exibir,
            vigenciaMes,
            vigenciaAno,
            vigenciaAtual,
            listaPagarReceber,
            listaTipos,
            listaReceitaDespesa,
            listaRedes,
            meses,
            anos,
            listaRateios,
            listaGrupos,
            showRedes,
            originalmenteRestrito,
            listaNaturezaSped,
            listaIndicadoresTipoSped,
            showSped,

            rowVersion,

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;

        return (
            <>
                <SectionContent
                    title={"Cadastro da subconta"}>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                value={codigoPai}
                                name="codigoPai"
                                label="Grupo:"
                                options={listaGrupos}
                                onChange={this.handleGrupoChange}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <InputText
                                value={codigo}
                                name="codigo"
                                label="Código ID:"
                                onChange={this.handleInputChange}
                                disabled
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <InputText
                                value={descricao}
                                name="descricao"
                                label="Descrição:"
                                maxlength={50}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <InputText
                                value={conta}
                                name="conta"
                                label="Conta:"
                                maxlength={30}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <InputText
                                value={contaReduzida}
                                name="contaReduzida"
                                label="Conta reduzida:"
                                onChange={this.handleInputChange}
                                type="number"
                                decimalScale={0}
                                maxlength={30}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <Select
                                value={pagarReceber}
                                name="pagarReceber"
                                label="A pagar/a receber:"
                                options={listaPagarReceber}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                value={tipoContaCodigo}
                                name="tipoContaCodigo"
                                label="Tipo de conta:"
                                options={listaTipos}
                                onChange={this.handleTipoContaChange}
                                disabled={restrito || showSped}
                            />
                        </div>
                        <div className={this.ifShow(showRedes, "col-5")}>
                            <Select
                                value={redeAutorizadoraCodigo}
                                name="redeAutorizadoraCodigo"
                                label="Rede autorizadora:"
                                options={listaRedes}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                value={tipoReceita}
                                name="tipoReceita"
                                label="Tipo de receita/despesa:"
                                options={listaReceitaDespesa}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <Checkbox
                                label="Opções">
                                {rowVersion ?
                                    <Checkitem
                                        checked={ativo}
                                        name="ativo"
                                        label="Ativo"
                                        onChange={this.handleInputChange}
                                        disabled={restrito}
                                    />
                                    :
                                    <></>
                                }
                                <Checkitem
                                    checked={restrito}
                                    name="restrito"
                                    label="Restrito"
                                    onChange={this.handleInputChange}
                                    disabled={originalmenteRestrito}
                                />
                                <Checkitem
                                    checked={exibir}
                                    name="exibir"
                                    label="Exibir conta na liquidação de títulos e lançamentos da tesouraria"
                                    onChange={this.handleInputChange}
                                />
                            </Checkbox>
                        </div>
                    </div>
                </SectionContent>
                <SectionContent
                    title="Dados do SPED"
                    visible={showSped}>
                    <div className="row">
                        <div className="col-5">
                            <InputText
                                value={codigoContaSped}
                                name="codigoContaSped"
                                label="Código conta SPED:"
                                onChange={this.handleInputChange}
                                maxlength={255}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <Select
                                value={codigoNaturezaSped}
                                name="codigoNaturezaSped"
                                label="Código da natureza da conta (SPED):"
                                options={listaNaturezaSped}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                value={indicadorTipoContaSped}
                                name="indicadorTipoContaSped"
                                label="Indicador de tipo de conta (SPED):"
                                options={listaIndicadoresTipoSped}
                                onChange={this.handleInputChange}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <InputText
                                value={nivelContaSped}
                                name="nivelContaSped"
                                label="Nível da conta (SPED):"
                                onChange={this.handleInputChange}
                                type="number"
                                maxlength={5}
                                decimalScale={0}
                                allowNegative={false}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                </SectionContent>
                <SectionContent title="Rateio"
                    visible={!showSped}>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                label="Início da vigência (Mês):"
                                name="vigenciaMes"
                                value={vigenciaMes}
                                onChange={this.handleMesChange}
                                options={meses}
                                disabled={restrito}
                            />
                        </div>
                        <div className="col-5">
                            <Select
                                label="Início da vigência (Ano):"
                                name="vigenciaAno"
                                value={vigenciaAno}
                                onChange={this.handleAnoChange}
                                options={anos}
                                disabled={restrito}
                            />
                        </div>
                    </div>
                    <SectionContent >
                        <List
                            title="Rateio"
                            sortable={false}
                            defaultPageSize={3}
                            rows={listaRateios[vigenciaAtual]}
                            cols={[
                                {
                                    accessor: "codigo",
                                    Header: "Código",
                                    show: false
                                },
                                {
                                    accessor: "isTotalizador",
                                    Header: "Totalizador",
                                    show: false
                                },
                                {
                                    accessor: "setor.descricao",
                                    Header: "Setor"
                                },
                                {
                                    accessor: "rateio",
                                    Header: "Percentual de rateio",
                                    Cell: props => {
                                        return (<InputText
                                            className="input"
                                            //label="Descrição:"                                            
                                            name="rateio"
                                            value={props.row.rateio}
                                            onChange={event =>
                                                this.handleChangeGrid(
                                                    event.floatValue,
                                                    "rateio",
                                                    props.row.codigo
                                                )
                                            }
                                            maxlength={6}
                                            type="number"
                                            tabindex={10}
                                            disabled={props.row.isTotalizador ||
                                                restrito}
                                        />);
                                    }
                                },
                            ]
                            } />

                    </SectionContent>
                </SectionContent>
                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={(rowVersion === null) ?
                        null : this.handleExcluir}
                    handleCancelar={this.handleCancelar}
                />
                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>);
    }
}



FormSubConta = withRouter(FormSubConta);
export { FormSubConta };