/* eslint-disable no-array-constructor */
import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import {
    InputText,
    Checkbox,
    Checkitem,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";

import { SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import {
    excluiConta,
    alteraConta,
    incluiConta,
    montaComboPagarReceber
} from "../../../services/Contas";

import moment from "moment";
import { getSetores } from "../../../services/Setores";
import { getMeses, getDateIndex } from "../../../utils/Utils";
import { List } from "../../formulario/List";

export const Total = {
    Codigo: 99,
    Label: "Total percentual dos rateios"
};

class FormConta extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            descricao = "",
            pagarReceber = null,
            tipo = 1,
            inativo = false,
            rateio = [],
            rowVersion = null
        } = this.props.conta;

        const { subContasExistentes } = this.props;

        this.state = {
            codigo,
            descricao,
            pagarReceber,
            listaPagarReceber: [],
            ativo: !inativo,
            tipo,
            exibirVigencia: true,
            vigenciaMes: String(moment().month()),
            vigenciaAno: String(moment().year()),
            vigenciaAtual: getDateIndex(moment().month(), moment().year()),
            rateio,
            totalRateio: 0,
            percentuais: new Array(),
            listaRateios: new Array(),
            rowVersion,
            setores: null, // será um array

            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: "",

            subContasExistentes,
            contaSel: []
        };

    }

    isFormValid() {
        const {
            descricao,
            pagarReceber,
            listaRateios,
            meses
        } = this.state;

        if (!descricao) {
            this.showError("A descrição não pode ficar vazia");
            return false;
        }

        if (!pagarReceber) {
            this.showError("Selecione o tipo da conta");
            return false;
        }
        let result = true; // return dentro do forEach finaliza apenas ele mesmo
        listaRateios.forEach((r) => {
            let total = this.getTotalRateio(r);
            if ((total > 0 && total < 100) || (total > 100)) {
                this.showError("Total do percentual de rateio de " +
                    meses[Number(r[0].mesInicio)].label + " de " +
                    r[0].anoInicio + " deve ser igual a 100%.");
                result = false;
                return;
            }
        });
        return result;
    }

    handleSalvar = async () => {
        if (!this.isFormValid()) {
            return;
        }

        let {
            codigo,
            descricao,
            pagarReceber,
            tipo,
            //rateio,
            listaRateios,
            ativo,
            rowVersion
        } = this.state;

        let inativo = !ativo;

        const listaRateiosParaEnviar = [];

        listaRateios.forEach((r) => {
            // rateio com total 0 não precisa ser enviado
            if (r && this.getTotalRateio(r) > 0) {
                // mexe numa cópia para não bagunçar o que está na tela
                // pois a API pode retornar algum erro
                const helper = r.filter((rat => rat.codigo !== Total.Codigo));
                helper.forEach((item) => {
                    item.mesInicio = Number(item.mesInicio) + 1;
                    listaRateiosParaEnviar.push(item);
                })
            }
        })

        const [action, params] =
            rowVersion === null
                ? [
                    incluiConta,
                    [
                        descricao,
                        pagarReceber,
                        tipo,
                        inativo,
                        listaRateiosParaEnviar,
                        rowVersion
                    ]
                ]
                : [
                    alteraConta,
                    [
                        codigo,
                        descricao,
                        pagarReceber,
                        tipo,
                        inativo,
                        listaRateiosParaEnviar,
                        rowVersion
                    ]
                ];

        try {
            await action(...params);
            this.showInfo(`Conta ${rowVersion === null ?
                "incluída" : "alterada"} com sucesso!`);
        } catch (err) {
            this.showInfo(err.response.data.message);
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Contas",
            alertSubtitle: message
        });
    }

    handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Contas",
            alertSubtitle: "Deseja excluir?"
        });
    };

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Contas",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    };

    criaRateioVazio(mes, ano) {
        const { setores } = this.state;
        const rateioVazio = [];
        setores.forEach((s) => {
            rateioVazio.push({
                setor: { descricao: s.descricao, codigo: s.codigo },
                codigo: s.codigo,
                rateio: 0,
                mesInicio: mes ? mes : this.state.vigenciaMes,
                anoInicio: ano ? ano : this.state.vigenciaAno,
                isTotalizador: s.codigo === Total.Codigo
            });
        }
        );
        rateioVazio.push(this.getRateioTotalizador(0));
        return rateioVazio;
    }

    getRateioTotalizador(totalRateio) {
        return {
            setor: { descricao: Total.Label, codigo: Total.Codigo },
            codigo: Total.Codigo,
            rateio: totalRateio,
            mesInicio: this.state.vigenciaMes,
            anoInicio: this.state.vigenciaAno,
            isTotalizador: true,
        };
    }

    async componentDidMount() {
        const { data: dataPagarReceber } = await montaComboPagarReceber();
        const listaPagarReceber = [];
        listaPagarReceber.push({ label: "Selecione o tipo da conta", value: "" });
        dataPagarReceber.forEach((pr) => {
            listaPagarReceber.push({ label: pr.descricao, value: pr.codigo });
        });

        let { vigenciaAno, vigenciaAtual } = this.state;
        const anos = [];
        for (let i = 0; i > -5; i--) {
            anos.push({
                label: String(Number(vigenciaAno) + i),
                value: Number(vigenciaAno) + i
            });
        };

        let { setores } = this.state;
        if (!setores) {
            setores = [];
            const { data } = await getSetores(1);

            data.forEach((s) => {
                if (String(s.descricao) !== "Lubrax") {
                    setores.push(s);
                }
            });
        }

        const percentuais = [],
            listaInterna = [],
            listaRateios = [];

        let totalRateio = 0,
            i = 1;
        const { rateio } = this.state;

        if (rateio && rateio.length > 0) {
            rateio.forEach((r) => {
                listaInterna.push({
                    setor: {
                        descricao: r.setor.descricao,
                        codigo: r.setor.codigo
                    },
                    codigo: r.setor.codigo,
                    rateio: r.rateio,
                    mesInicio: String(Number(r.mesInicio - 1)),
                    anoInicio: String(r.anoInicio),
                    isTotalizador: false
                });
                totalRateio += r.rateio;
                if (i >= 2 && i % 2 === 0) {
                    listaInterna.push(this.getRateioTotalizador(totalRateio));
                    vigenciaAtual = getDateIndex(r.mesInicio - 1, r.anoInicio);
                    // copia o array, pois não pode ser por referência                     
                    listaRateios[vigenciaAtual] = listaInterna.slice();
                    // limpa o array original, não a cópia de cima
                    listaInterna.length = 0;
                    totalRateio = 0;
                }
                i++;
            });

        } else {
            setores.forEach((s) => {
                percentuais[s.codigo] = 0;
                listaInterna.push({
                    setor: { descricao: s.descricao, codigo: s.codigo },
                    codigo: s.codigo,
                    rateio: Number(percentuais[s.codigo]),
                    mesInicio: this.state.vigenciaMes,
                    anoInicio: this.state.vigenciaAno,
                    isTotalizador: false
                });
            }
            );
            listaInterna.push(this.getRateioTotalizador(totalRateio));

            listaRateios[vigenciaAtual] = listaInterna;
        }

        this.setState({
            setores,
            listaPagarReceber,
            meses: getMeses(),
            anos,
            listaRateios,
            percentuais,
            totalRateio
        });
    }

    handleAlertAction = async (resp) => {
        const {
            codigo,
            alertType
        } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/contas/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluiConta(codigo);
                        this.showInfo("Conta excluída com sucesso!");
                    } catch (err) {
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/contas/");
                }
                break;
            default:
                break;
        }
    };

    getTotalRateio(rateios) {
        let total = 0;
        if (rateios) {
            rateios.forEach((r) => {
                if (Number(r.codigo) !== Total.Codigo)
                    total += r.rateio ? Number(r.rateio) : 0;
                //total += String(p) === "" ? 0 : p;
            });
        }
        return total;
    }

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Contas",
            alertSubtitle: message
        });
    }

    handleChangeGrid = (value, name, codigo) => {
        if (codigo === Total.Codigo) // se é a linha de total, não precisa fazer o processo
            return;

        const { listaRateios, vigenciaAtual } = this.state;
        const rateios = listaRateios[vigenciaAtual].map(r => {
            if (r.codigo === codigo) {
                return { ...r, [name]: value };
            } else {
                return r;
            }
        });
        const totalRateio = this.getTotalRateio(rateios);
        const { percentuais } = this.state;
        rateios.forEach((r) => {
            if (Number(r.codigo) === Total.Codigo) {
                r.rateio = totalRateio;
            }
            else {
                percentuais[r.codigo] = r.rateio;
            }
        });

        listaRateios[vigenciaAtual] = rateios;

        this.setState({ listaRateios, totalRateio, percentuais });
    };

    handleTipoChange = (event) => {
        //const { pagarReceber } = event.targe.value;
        //
        this.setState({ pagarReceber: event.target.value });
    }

    // async getNewRateiosFromVigencia(mes, ano) {
    //     const { data: dataRateios } = await getRateiosVigencia(mes, ano);
    //     let rateios = dataRateios.map();// todo
    //     if (!rateios)
    //         rateios = [];
    //     return rateios;
    // }

    handleMesChange = (event) => {
        const vigenciaMes = event.target.value;
        const { vigenciaAno } = this.state;
        const vigenciaAtual = getDateIndex(vigenciaMes, vigenciaAno);
        const { listaRateios } = this.state;
        if (!listaRateios[vigenciaAtual])
            listaRateios[vigenciaAtual] = this.criaRateioVazio(vigenciaMes,
                vigenciaAno);
        this.setState({ vigenciaMes, vigenciaAtual, listaRateios });
    }

    handleAnoChange = (event) => {
        const vigenciaAno = event.target.value;
        const { vigenciaMes } = this.state;
        const vigenciaAtual = getDateIndex(vigenciaMes, vigenciaAno);
        const { listaRateios } = this.state;
        if (!listaRateios[vigenciaAtual])
            listaRateios[vigenciaAtual] = this.criaRateioVazio(vigenciaMes,
                vigenciaAno);
        this.setState({ vigenciaAno, vigenciaAtual, listaRateios });
    }

    canDelete() {        
        const { codigo, rowVersion, subContasExistentes } = this.state;

        if (!rowVersion){
            return false; // está inserindo um novo
        }

        let result = true;
        subContasExistentes.forEach((c) => {
            if(c.codigoPai === codigo){ // possui subconta vinculada
                result = false;
                return;
            }
        });
        return result;
    }

    render() {
        const {
            codigo,
            descricao,
            ativo,
            pagarReceber,
            listaPagarReceber,
            listaRateios,
            exibirVigencia,
            vigenciaMes,
            vigenciaAno,
            vigenciaAtual,
            meses,
            anos,
            rowVersion,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;

        return (
            <>
                <SectionContent title="Cadastro de Conta" accordion>
                    <div className="row">
                        <div className="col-5">
                            <InputText
                                label="Código da conta:"
                                value={codigo}
                                name="codigo"
                                onChange={this.handleInputChange}
                                maxlength={20}
                                tabindex={1}
                                disabled
                            />
                        </div>
                        <div className="col-5">
                            <InputText
                                label="Descrição:"
                                value={descricao}
                                name="descricao"
                                onChange={this.handleInputChange}
                                maxlength={50}
                                tabindex={2}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                label="Tipo:"
                                name="tipo"
                                //value={tipo}
                                value={pagarReceber}
                                onChange={this.handleTipoChange}
                                options={listaPagarReceber}
                                tabindex={3}
                            />
                        </div>
                        {rowVersion ?
                            <div className="col-5">
                                <Checkbox label="Ativo:">
                                    <Checkitem
                                        label=""
                                        name="ativo"
                                        checked={ativo}
                                        onChange={this.handleInputChange}
                                        tabindex={4}
                                    />
                                </Checkbox>
                            </div>
                            :
                            <></>
                        }
                    </div>

                </SectionContent>


                <SectionContent title="Rateio" accordion>
                    <div className="row">
                        <div className="col-5">
                            <Select
                                label="Início da vigência (Mês):"
                                name="vigenciaMes"
                                value={vigenciaMes}
                                onChange={this.handleMesChange}
                                options={meses}
                                tabindex={5}
                            />
                        </div>
                        <div className="col-5">
                            <Select
                                label="Início da vigência (Ano):"
                                name="vigenciaAno"
                                value={vigenciaAno}
                                onChange={this.handleAnoChange}
                                options={anos}
                                tabindex={6}
                            />
                        </div>

                    </div>

                    <SectionContent visible={exibirVigencia}
                    >
                        <List
                            title="Rateio"
                            sortable={false}
                            defaultPageSize={3}
                            rows={listaRateios[vigenciaAtual]}
                            cols={[
                                {
                                    accessor: "codigo",
                                    Header: "Código",
                                    show: false
                                },
                                {
                                    accessor: "isTotalizador",
                                    Header: "Totalizador",
                                    show: false
                                },
                                {
                                    accessor: "setor.descricao",
                                    Header: "Setor"
                                },
                                {
                                    accessor: "rateio",
                                    Header: "Percentual de rateio",
                                    Cell: props => {
                                        return (<InputText
                                            className="input"
                                            //label="Descrição:"                                            
                                            name="rateio"
                                            value={props.row.rateio}
                                            onChange={event =>
                                                this.handleChangeGrid(
                                                    event.floatValue,
                                                    "rateio",
                                                    props.row.codigo
                                                )
                                            }
                                            maxlength={6}
                                            type="number"
                                            tabindex={10}
                                            disabled={props.row.isTotalizador}
                                        />);
                                    }
                                },
                            ]
                            } />

                    </SectionContent>
                </SectionContent>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={this.canDelete() ? this.handleExcluir : null}                        
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />

            </>
        );
    }

}

FormConta = withRouter(FormConta);
export { FormConta };