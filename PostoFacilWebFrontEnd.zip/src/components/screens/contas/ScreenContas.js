import React, { Component } from "react";
import ReactDOM from "react-dom";
import { withRouter } from "react-router-dom";

import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";

import "rc-tree/assets/index.css";
import Tree from "rc-tree";
import Tooltip from "rc-tooltip";
import { FormConta } from "./ScreenContasCadastroPai";
import { FormSubConta } from "./ScreenContasCadastroSub";
import { getContas, getSubConta } from "../../../services/Contas";

class TreeContas extends React.Component {
    constructor(props) {
        super(props);

        const {
            contaSel = {},
            subcontaSel = {}            
        } = this.props;

        this.state = {
            contaSel,
            subcontaSel,
            contas: [],
            subContas: [],
            contasPreparadas: [],
            selectedKeys: [],
            expandedKeys: []
        };
    }

    async componentDidMount() {
        this.getContainer();

        const { data: dataContas } = await getContas(false, true);
        const contas = [];
        const subContas = [];

        dataContas.result.forEach((c) => {
            if (c.codigoPai) {
                subContas.push(c);
            } else {
                contas.push(c);
            }
        });

        //const { contasPreparadas } = this.state;
        const contasPreparadas = [];
        contasPreparadas.push({
            title: "Estrutura de contas",
            key: 1,
            children: [],
            self: {},
            level: 1
        });

        //let i = 2;
        contas.forEach((c) => {
            // let j = i;
            const children = [];
            subContas.forEach((s) => {
                if (s.codigoPai === c.codigo) {
                    // i++;
                    children.push({
                        title: s.descricao,
                        //key: i,
                        key: s.codigo,
                        children: [],
                        self: s,
                        level: 3
                    });
                }
            });

            contasPreparadas[0].children.push({
                title: c.descricao,
                //key: j,
                key: c.codigo,
                children,
                self: c,
                level: 2,
                isLeaf: false
            });
            //i++;
        });
        this.setState({ contasPreparadas, contas, subContas });
    }
    componentWillUnmount() {
        if (this.cmContainer) {
            ReactDOM.unmountComponentAtNode(this.cmContainer);
            document.body.removeChild(this.cmContainer);
            this.cmContainer = null;
        }
    }
    onRightClick = (info) => {
        this.renderCm(info);
    };
    getContainer() {
        if (!this.cmContainer) {
            this.cmContainer = document.createElement("div");
            document.body.appendChild(this.cmContainer);
        }
        return this.cmContainer;
    }
    onSelect = (
        selectedKeys,
        e /*:{selected: bool, selectedNodes, node, event, nativeEvent}*/
    ) => {
        const { expandedKeys } = this.state;
        const key = selectedKeys[0];
        if (expandedKeys.includes(key)) {
            this.setState({ expandedKeys: expandedKeys.filter(k => k !== key) });
        } else {
            this.setState({ expandedKeys: [...expandedKeys, key] });
        }
    };
    onExpand = (expandedKeys, e) => {
        this.setState({ expandedKeys });
    };

    handleItem(handleInfo) {
        if (!handleInfo)
            return;

        switch (handleInfo.level) {
            case handleInfo.contaLevel:
                this.setState({ contaSel: handleInfo.object });
                this.props.setConta(handleInfo.object, this.state.subContas);
                break;

            case handleInfo.subContaLevel:
                this.setState({ subcontaSel: handleInfo.object });
                this.props.setSubConta(handleInfo.object);
                break;
            default:
                break;
        }
    }

    newItem = (info) => {       
        const handleInfo = {};
        handleInfo.level = info.props.level;
        handleInfo.contaLevel = 1;
        handleInfo.subContaLevel = 2;
        handleInfo.object = info.props.self;
        this.handleItem(handleInfo);
    };

    changeItem = (info) => {
        const handleInfo = {};
        handleInfo.level = info.props.level;
        handleInfo.contaLevel = 2;
        handleInfo.subContaLevel = 3;
        handleInfo.object = info.props.self;
        this.handleItem(handleInfo);
    };

    renderCm(info) {
        if (this.toolTip) {
            ReactDOM.unmountComponentAtNode(this.cmContainer);
            this.toolTip = null;
        }
        this.toolTip = (
            <Tooltip
                trigger="click"
                placement="bottomRight"
                prefixCls="rc-tree-contextmenu"
                defaultVisible
                overlay={
                    <ContextMenu
                        info={info}
                        newItem={this.newItem}
                        changeItem={this.changeItem}
                    />
                }
            >
                <span />
            </Tooltip>
        );

        const container = this.getContainer();
        Object.assign(this.cmContainer.style, {
            position: "absolute",
            left: `${info.event.pageX}px`,
            top: `${info.event.pageY}px`
        });

        ReactDOM.render(this.toolTip, container);
    }

    render() {
        return (
            <div>
                <Tree
                    onRightClick={this.onRightClick}
                    defaultExpandAll
                    showLine
                    selectedKeys={this.state.selectedKeys}
                    expandedKeys={this.state.expandedKeys}
                    onExpand={this.onExpand}
                    showIcon={false}
                    onSelect={this.onSelect}
                    treeData={this.state.contasPreparadas}
                />
            </div>
        );
    }
}

class ContextMenu extends Component {
    render() {
        const {
            node,
            node: {
                props: { pos }
            }
        } = this.props.info;
        const { newItem, changeItem } = this.props;
        return (
            <div>
                {!node.isLeaf() && (
                    <h4 onClick={() => newItem(node)}>Incluir sub-item</h4>
                )}
                {pos !== "0-0" && (
                    <h4 onClick={() => changeItem(node)}>Alterar item</h4>
                )}
            </div>
        );
    }
}

class ScreenContas extends Component {
    state = {
        contas: [],
        contaSel: {},
        subContas: [],
        subcontaSel: {},
        telaDisponivel: false
    };

    setConta = (conta, subContas) => {
        this.setState({ contaSel: conta, subContas });
        this.props.history.push("/contas/conta");
    }

    setSubConta = async (conta) => {
        let sub = {};
        if (conta) {
            if (conta.codigoPai) {
                const { data } = await getSubConta(conta.codigo);
                sub = data;
            } else {
                sub = { codigoPai: conta.codigo }
            }
        }
        this.setState({ subcontaSel: sub });
        this.props.history.push("/contas/subconta");
    }

    doMount() {
        this.setState({
            telaDisponivel: true
        });
    }

    componentDidMount() {
        this.doMount();
    }

    componentDidUpdate(prevProps) {
        if ((this.props.edit !== prevProps.edit && !this.props.edit) ||
            (this.props.editSub !== prevProps.editSub && !this.props.editSub)) {
            this.doMount();
        }
    }

    render() {
        const {
            edit,
            editSub
        } = this.props;

        const {
            contaSel = {},
            subcontaSel = {},
            subContas
        } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader title="Contas" />
                    <SectionContainer>
                        <SectionContent>
                            {edit ? (<FormConta conta={contaSel}
                                subContasExistentes={subContas} />) :
                                (editSub ? (<FormSubConta
                                    subconta={subcontaSel} />) :
                                    <TreeContas
                                        setConta={this.setConta}
                                        setSubConta={this.setSubConta} />)}
                        </SectionContent>
                    </SectionContainer>
                </section>
            </main>
        );
    }
}
ScreenContas = withRouter(ScreenContas);
export { ScreenContas };