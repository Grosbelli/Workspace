import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Checkbox,
    Checkitem,
    InputDate,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import { List } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { AlertType, Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";
import moment from "moment";

import {
    incluiPessoa,
    alteraPessoa,
    excluiPessoa,
    getPessoas,
    verifyPessoa,
    getCategorias
} from "../../../services/Pessoas";

import {
    validaCPF,
    validaCNPJ,
    validaCpfOrCnpj,
    maskedCnpjCpf,
    maskCpfCnpj,
    isValidIE,
    isValidEmail
} from "../../../utils/Utils";

import {
    getEstados,
    getCidades,
    getCep
} from "../../../services/Localidades";

// parece ser um bug, no options do Select se tiver um item com value: null dá uma série de erros
export const none = "";

export const TipoPessoa = {
    None: none,
    Fisica: 0,
    Juridica: 1
};

// enumerator somente com as classificações contempladas nesse cadastro
export const Classificacao = {
    Cliente: 1,
    Fornecedor: 2,
    Transportadora: 4,
    Fabricante: 5
};

// enumerator somente com as categorias ,"fixas", utilizadas em condições
export const Categoria = {
    ProdutorRural: 7, // classificação "cliente"
    Contador: 2 // classificação "fornecedor"
};

function apiToState(api) {
    const result = { ...api };
    const classificacoes = result.classificacoes;
    delete result.classificacoes; // deleta o array classificacoes
    result.isCliente = false;
    result.categoriaCliente = none;
    result.isFornecedor = false;
    result.categoriaFornecedor = none;
    result.crc = null;
    result.nomeContador = null;
    result.isFabricante = false;
    result.categoriaFabricante = none;
    result.isTransportadora = null
    classificacoes.forEach((c) => {
        switch (c.codigo) {
            case Classificacao.Cliente:
                result.isCliente = true;
                if (c.categoria)
                    result.categoriaCliente = c.categoria.codigo;
                break;
            case Classificacao.Fornecedor:
                result.isFornecedor = true;
                if (c.categoria) {
                    result.categoriaFornecedor = c.categoria.codigo;
                    result.crc = c.categoria.crc;
                    result.nomeContador = c.categoria.nomeContador;
                }
                break;
            case Classificacao.Fabricante:
                result.isFabricante = true;
                if (c.categoria)
                    result.categoriaFabricante = c.categoria.codigo;
                break;
            case Classificacao.Transportadora:
                result.isTransportadora = true;
                break;
            default:
                break;
        }
    });
    result.tipo = result.tipo.codigo; // transforma tipo.codigo em tipo
    result.ativo = !result.inativo;
    delete result.inativo;
    result.cep = result.endereco.cep;
    result.codigoUF = result.endereco.codigoUF;
    result.codigoMunicipio = result.endereco.codigoMunicipio;
    result.numero = result.endereco.numero;
    result.complemento = result.endereco.complemento;
    result.referencia = result.endereco.referencia;
    result.bairro = result.endereco.bairro;
    result.endereco = result.endereco.endereco;
    if (result.contatos) {
        result.contatoNome = result.contatos[0].nome;
        result.contatoDescricao = result.contatos[0].descricao;
        result.contatoDDD = result.contatos[0].ddd;
        result.contatoNumero = result.contatos[0].numero;
        result.contatoEMail = result.contatos[0].email;
    } else {
        result.contatoNome = null;
        result.contatoDescricao = null;
        result.contatoDDD = null;
        result.contatoNumero = null;
        result.contatoEMail = null;
    };
    delete result.contatos;
    return result;
};

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            cnpjCpf = null,
            inscricaoEstadual = null,
            inscricaoMunicipal = null,

            nome = null,
            apelido = null,
            isentoICMS = null,
            dataNascimento = null,
            identidade = null,
            orgaoEmissor = null,
            emiteNFe = null,
            ativo = true,
            tipo = null,

            isCliente = false,
            categoriaCliente = none,

            isFornecedor = false,
            categoriaFornecedor = none,
            crc = null,
            nomeContador = null,

            isFabricante = false,
            categoriaFabricante = none,

            isTransportadora = false,

            cep = null,
            codigoUF = null,
            codigoMunicipio = null,
            endereco = null,
            numero = null,
            complemento = null,
            referencia = null,
            bairro = null,

            contatoNome = null,
            contatoDescricao = null,
            contatoDDD = null,
            contatoNumero = null,
            contatoEMail = null,

            site = null,

            excluido = false,
            dataExclusao = null,
            rowVersion = null
        } = this.props.pessoa;

        this.state = {
            codigo,
            cnpjCpf,
            inscricaoEstadual,
            inscricaoMunicipal,

            nome,
            apelido,
            isentoICMS,
            dataNascimento,
            identidade,
            orgaoEmissor,
            emiteNFe,
            ativo,
            tipo,

            isCliente,
            categoriaCliente,

            isFornecedor,
            categoriaFornecedor,
            crc,
            nomeContador,

            isFabricante,
            categoriaFabricante,

            isTransportadora,

            cep,
            codigoUF,
            codigoMunicipio,
            endereco,
            numero,
            complemento,
            referencia,
            bairro,

            contatoNome,
            contatoDescricao,
            contatoDDD,
            contatoNumero,
            contatoEMail,

            site,

            excluido,
            dataExclusao,
            rowVersion,

            alertActive: false,
            alertType: AlertType.None,
            alertTitle: "",
            alertSubtitle: "",
            alertFocus: null,
            alertAction: null,

            categoriasClientes: [],
            categoriasFornecedores: [],
            categoriasFabricantes: [],
            estados: [],
            cidades: []
        };
    };

    async componentDidMount() {

        function mapCombo(data, showNone, showCode) {
            const combo = data.map(item => {
                return {
                    value: item.codigo,
                    label: item.descricao + `${showCode ? " (" + item.codigo + ")" : ""}`
                }
            });
            if (showNone) {
                combo.unshift({ value: none, label: showNone });
            };
            return combo;
        }

        async function montaComboCategorias(classificacao, showNone) {
            const { data } = await getCategorias(classificacao);
            return mapCombo(data, showNone, true);
        };

        this.setState({
            categoriasClientes: await montaComboCategorias(
                Classificacao.Cliente, "Selecione um tipo de cliente", true),
            categoriasFornecedores: await montaComboCategorias(
                Classificacao.Fornecedor, "Selecione um tipo de fornecedor", true),
            categoriasFabricantes: await montaComboCategorias(
                Classificacao.Fabricante, "Selecione um tipo de fabricante", true),
            estados: [],
            cidades: []
        });
        this.updateEstados();
        this.updateCidades(this.state.codigoUF);
    }

    showMessage = (alertActive,
        alertType,
        alertTitle,
        alertSubtitle,
        alertFocus,
        alertAction) => {
            this.setState({
                alertActive,
                alertType,
                alertTitle: !!alertTitle ? alertTitle : "Pessoa",
                alertSubtitle,
                alertFocus,
                alertAction: !!alertAction ? alertAction : this.hideAlert
            });    
        }
    
    showInfo = (message, action) => {
        this.showMessage(
            true,
            AlertType.Success,
            "",
            message,
            null,
            action);
    }

    showQuestion = (message, action) => {
        this.showMessage(
            true,
            AlertType.Question,
            "",
            message,
            null,
            action);
    }

    showError = (message, field, action) => {
        this.showMessage(
            true,
            AlertType.Error,
            "",
            message,
            field,
            action);
    }

    setFocus = (elementID) => {
        const node = document.getElementById(elementID);
        if (node) {
            node.focus();
            node.scrollIntoView();
        }
    }

    hideAlert = () => {
        const { alertFocus } = this.state;
        this.setState({
            alertActive: false,
            alertType: AlertType.None,
            alertTitle: "",
            alertSubtitle: "",
            alertFocus: null,
            alertAction: null
        });
        this.setFocus(alertFocus);
    }

    backToScreen = () => {
        this.hideAlert();
        this.props.history.push("/pessoas/");
    }

    validateDataNascimento = () => {
        if (moment(this.state.dataNascimento).isAfter(moment())) {
            this.showError(
                `A data de ${this.isPF() ? "nascimento" : "fundação"}, quando informada, não pode ser superior a data atual.`,
                "dataNascimento");
        }
    }

    validateEmail = () => {
        const email = this.state.contatoEMail;
        if (!!email && !isValidEmail(email)) {
            this.showError('O email "' + email + '" não é válido.',
                "contatoEMail");
        }
    }

    validateData = () => {
        let erro = null;
        if (!this.state.isCliente && !this.state.isFornecedor && !this.state.isFabricante && !this.state.isTransportadora)
            erro = {
                field: "isCliente",
                message: "Pelo menos uma das seguintes opções deve estar marcada: cliente, fornecedor, fabricante ou transportadora."
            }

        else if (this.state.isFornecedor && (this.state.categoriaFornecedor === none))
            erro = {
                field: "categoriaFornecedor",
                message: "Quando a pessoa é um fornecedor, o tipo de fornecedor deve ser informado."
            }

        else if (this.state.isFabricante && (this.state.categoriaFabricante === none))
            erro = {
                field: "categoriaFabricante",
                message: "Quando a pessoa é um fabricante, o tipo de fabricante deve ser informado."
            }

        else if (!this.state.nome)
            erro = {
                field: "nome",
                message: `${this.isPF() ?
                    "O nome da pessoa deve ser informado." : "O nome da empresa deve ser informado."}`
            }

        else if (moment(this.state.dataNascimento).isAfter(moment())) {
            erro = {
                field: "dataNascimento",
                message:
                    `A data de ${this.isPF() ? "nascimento" : "fundação"
                    }, quando informada, não pode ser superior a data atual.`
            }
        } // TODO: Coloquei a validação aqui porque no onBlur não funcionou no InputDate

        else if (this.isPF() && !this.state.identidade)
            erro = {
                field: "identidade",
                message: "Para pessoa física, a identidade deve ser informada."
            }

        else if (this.needIE() && !this.state.inscricaoEstadual)
            erro = {
                field: "inscricaoEstadual",
                message: `${this.isPJ() ?
                    "A inscrição estadual da empresa deve ser informada." :
                    "Para produtor rural, a inscrição estadual da pessoa deve ser informada."}`
            }

        else if (this.isContador() && !this.state.nomeContador)
            erro = {
                field: "nomeContador",
                message: "Quando a pessoa é um fornecedor e o seu tipo é contador, o nome do contador deve ser informado."
            }

        else if (this.isContador() && !this.state.crc)
            erro = {
                field: "crc",
                message: "Quando a pessoa é um fornecedor e o seu tipo é contador, o CRC do contador deve ser informado."
            }

        else if (!this.state.cep)
            erro = {
                field: "cep",
                message: "O CEP deve ser informado."
            }

        else if (!this.state.endereco)
            erro = {
                field: "endereco",
                message: "O endereço (rua, av, logradouro) deve ser informado."
            }

        else if (!this.state.bairro)
            erro = {
                field: "bairro",
                message: "O bairro deve ser informado."
            }

        else if (!this.state.codigoUF)
            erro = {
                field: "codigoUF",
                message: "A unidade federativa (uf, estado) deve ser informada."
            }

        else if (!this.state.codigoMunicipio)
            erro = {
                field: "codigoMunicipio",
                message: "A cidade deve ser informada."
            }

        else if (this.needIE() && !isValidIE(this.state.inscricaoEstadual, this.state.codigoUF)) {
            erro = {
                field: "",
                message: 'A inscrição estadual "' + this.state.inscricaoEstadual + '" não é válida.'
            }
        }

        if (erro) {
            this.showError(erro.message, erro.field);
            return false
        }
        else
            return true;
    }

    handleSalvar = async () => {
        const {
            codigo,
            cnpjCpf,
            inscricaoEstadual,
            inscricaoMunicipal,

            nome,
            apelido,
            isentoICMS,
            dataNascimento,
            identidade,
            orgaoEmissor,
            emiteNFe,
            ativo,
            tipo,

            isCliente,
            categoriaCliente,

            isFornecedor,
            categoriaFornecedor,
            crc,
            nomeContador,

            isFabricante,
            categoriaFabricante,

            isTransportadora,

            cep,
            codigoUF,
            codigoMunicipio,
            endereco,
            numero,
            complemento,
            referencia,
            bairro,

            contatoNome,
            contatoDescricao,
            contatoDDD,
            contatoNumero,
            contatoEMail,

            site,
            excluido,
            datsaExclusao,

            rowVersion
        } = this.state;

        const [action, params] = this.isInserting() ?
            [incluiPessoa, [
                cnpjCpf,
                inscricaoEstadual,
                inscricaoMunicipal,

                nome,
                apelido,
                isentoICMS,
                dataNascimento,
                identidade,
                orgaoEmissor,
                emiteNFe,
                ativo,
                tipo,

                isCliente,
                categoriaCliente,

                isFornecedor,
                categoriaFornecedor,
                crc,
                nomeContador,

                isFabricante,
                categoriaFabricante,

                isTransportadora,

                cep,
                codigoUF,
                codigoMunicipio,
                endereco,
                numero,
                complemento,
                referencia,
                bairro,

                contatoNome,
                contatoDescricao,
                contatoDDD,
                contatoNumero,
                contatoEMail,

                site]] :
            [alteraPessoa, [
                codigo,

                cnpjCpf,
                inscricaoEstadual,
                inscricaoMunicipal,

                nome,
                apelido,
                isentoICMS,
                dataNascimento,
                identidade,
                orgaoEmissor,
                emiteNFe,
                ativo,
                tipo,

                isCliente,
                categoriaCliente,

                isFornecedor,
                categoriaFornecedor,
                crc,
                nomeContador,

                isFabricante,
                categoriaFabricante,

                isTransportadora,

                cep,
                codigoUF,
                codigoMunicipio,
                endereco,
                numero,
                complemento,
                referencia,
                bairro,

                contatoNome,
                contatoDescricao,
                contatoDDD,
                contatoNumero,
                contatoEMail,

                site,

                rowVersion]];
        if (this.validateData()) {
            try {
                const resp = await action(...params);
                this.showInfo(`Pessoa ${this.isInserting() ? "cadastrada" :
                    this.isRestoring() ? "restaurada" : "alterada"} com sucesso!`,
                    this.backToScreen);
            }
            catch (err) {
                this.showError(err.response.data.message);
            };
        }
    };

    handleExcluir = () => {
        this.showQuestion("Deseja realmente excluir essa pessoa?",
            async (resp) => {
                if (resp) {
                    try {
                        await excluiPessoa(this.state.codigo);
                        this.showInfo("Pessoa excluída com sucesso!",
                            this.backToScreen);
                    } catch (err) {
                        this.showError(err.response.data.message)
                    }
                }
                else { this.hideAlert() }
            })
    }

    handleCancelar = async () => {
        if (this.isVerifying()) {
            this.backToScreen()
        }
        else {
            this.showQuestion("Deseja realmente cancelar a operação?",
                (resp) => {
                    if (resp) {
                        this.backToScreen()
                    }
                    else {
                        this.hideAlert()
                    }
                }
            )
        };
    }

    makeCombo = (list, showCode, showNull) => {
        let combo = list.map(item => {
            return {
                value: item.codigo,
                label: item.descricao + `${showCode ? " (" + item.codigo + ")" : ""}`
            }
        });
        if (showNull) {
            combo.unshift({ value: none, label: showNull });
        }
        return combo;
    }

    updateEstados = async () => {
        const { data: listaEstados } = await getEstados(this.state.codigoUF);
        this.setState({
            estados: this.makeCombo(listaEstados, true,
                "Selecione um estado")
        })
    };

    updateCidades = async (estado) => {
        if (!estado) {
            this.setState({ cidades: [{ value: none, label: "Selecione um estado primeiro" }] })
        } else {
            const { data: listaCidades } = await getCidades(estado);
            this.setState({
                cidades: this.makeCombo(listaCidades, true,
                    "Selecione uma cidade")
            })
        };
    };

    changeEstado = (event) => {
        const codigoUF = event.target.value;
        this.setState({ codigoUF, codigoMunicipio: null, cidades: [] });
        this.updateCidades(codigoUF);
    }

    searchCep = async () => {
        const { data: dadosCep } = await getCep(this.state.cep);
        if (dadosCep && dadosCep.value) {
            const cep = dadosCep.value;
            let endereco =
                (cep.TIPO_LOGRADOURO ?
                    String(cep.TIPO_LOGRADOURO).trim() + " " : "") +
                (!cep.OBS ?
                    String(cep.LOGRADOURO).trim() :
                    String(cep.LOGRADOURO.substring(0,
                        cep.LOGRADOURO.indexOf(cep.OBS))).trim());

            this.updateCidades(cep.ID_UF);
            this.setState({
                codigoUF: cep.ID_UF,
                endereco,
                bairro: cep.BAIRRO,
                codigoMunicipio: cep.COD_MUNICIPIO_IBGE
            });
        }
        else {
            this.showError('Cep "' + this.state.cep + '" não encontrado.',
                "cep");
        }
    }

    cnpjCpfIconeClick = async () => {
        const { cnpjCpf } = this.state;
        try {
            const { data: response } = await verifyPessoa(cnpjCpf);
            if (!!response.excluido) {
                this.showQuestion(`A pessoa com o ${validaCPF(cnpjCpf) ?
                    "CPF" : "CNPJ"} "${maskedCnpjCpf(cnpjCpf)}
                    " foi excluída do sistema. Deseja restaurá-la?`,
                    (resp) => {
                        if (resp) {
                            this.hideAlert();
                            this.setState(apiToState(response))
                        }
                        else {
                            this.hideAlert();
                        }
                    });
            }

            else {
                this.showError(`A pessoa com o ${validaCPF(cnpjCpf) ?
                    "CPF" : "CNPJ"} "${maskedCnpjCpf(cnpjCpf)}
                    " já está cadastrada!`, "cnpjCpf")
            }
        }
        catch (e) {
            if (validaCPF(cnpjCpf)) {
                this.setState({
                    tipo: TipoPessoa.Fisica,
                    isentoICMS: true
                })
            } else {
                this.setState({
                    tipo: TipoPessoa.Juridica,
                    isentoICMS: false
                })
            }

        }
    }

    isVerifying = () => {
        return this.state.tipo === null
    }// true se clicou no botão "+" e está digitando campo(s) chave
    isEditing = () => {
        return !this.isVerifying() && !!this.state.rowVersion
    } // (!! para garantir false ) true se  clicou em um item da list
    isInserting = () => {
        return !this.isVerifying() && !this.state.rowVersion
    } // true se clicou no botão "+" e já digitou campo(s)
    isRestoring = () => {
        return !this.isVerifying() && !!this.state.excluido
    }
    isPJ = () => {
        return this.state.tipo === TipoPessoa.Juridica
    }
    isPF = () => {
        return this.state.tipo === TipoPessoa.Fisica
    }
    isRural = () => {
        return (!this.isVerifying() && this.state.isCliente && (Number(this.state.categoriaCliente) === Categoria.ProdutorRural))
    }
    isContador = () => {
        return !this.isVerifying() && this.state.isFornecedor && (Number(this.state.categoriaFornecedor) === Categoria.Contador)
    }
    needIE = () => {
        return !this.state.isentoICMS
    }

    render() {
        const {
            codigo,
            cnpjCpf,
            inscricaoEstadual,
            inscricaoMunicipal,

            nome,
            apelido,
            isentoICMS,
            dataNascimento,
            identidade,
            orgaoEmissor,
            emiteNFe,
            ativo,
            tipo,

            isCliente,
            categoriaCliente,

            isFornecedor,
            categoriaFornecedor,
            crc,
            nomeContador,

            isFabricante,
            categoriaFabricante,

            isTransportadora,

            cep,
            codigoUF,
            codigoMunicipio,
            endereco,
            numero,
            complemento,
            referencia,
            bairro,

            contatoNome,
            contatoDescricao,
            contatoDDD,
            contatoNumero,
            contatoEMail,

            site,
            excluido,
            dataExclusao,
            rowVersion,

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle,
            alertFocus,

            categoriasClientes,
            categoriasFornecedores,
            categoriasFabricantes
        } = this.state;

        function ifTipo(Fisica, Juridica, Ambos) {
            switch (tipo) {
                case TipoPessoa.Fisica:
                    return Fisica;
                case TipoPessoa.Juridica:
                    return Juridica;
                default:
                    return Ambos;
            }
        }

        return (
            <>
                <SectionContainer>
                    <SectionContent
                        title={`${this.isVerifying() ?
                            "Dados básicos para a inclusão de uma nova pessoa" :
                            ifTipo(
                                "Dados cadastrais da pessoa física",
                                "Dados cadastrais da pessoa jurídica",
                                "Dados cadastrais da pessoa")}`}>
                        <div className={ifShow(false, "row")}>
                            <div className="col-1">
                                <InputText
                                    disabled
                                    value={apelido}
                                    name="apelido"
                                    label={"debug> "
                                        + " | identidade: " + identidade
                                        + " | orgaoEmissor: " + orgaoEmissor
                                        + " | isentoICMS: " + isentoICMS
                                        + " | isCliente: " + isCliente
                                        + " | categoriaCliente: " + categoriaCliente
                                        + " | isFornecedor: " + isFornecedor
                                        + " | categoriaFornecedor: " + categoriaFornecedor
                                        + " | codigo: " + codigo
                                        + " | excluido: " + excluido
                                        + " | isVerifying(): " + this.isVerifying()
                                        + " | isRestoring(): " + this.isRestoring()
                                        + " | isEditing(): " + this.isEditing()
                                        + " | isInserting(): " + this.isInserting()
                                        + " | isPF(): " + this.isPF()
                                        + " | isPJ(): " + this.isPJ()
                                        + " | isRural(): " + this.isRural()
                                        + " | isContador(): " + this.isContador()
                                        + " | row: " + this.state.rowVersion
                                        + " | isCli:" + this.state.isCliente
                                        + " | catCli: " + this.state.categoriaCliente
                                        + " | r: " + Categoria.ProdutorRural
                                        + " | "
                                    }
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <InputText
                                    value={cnpjCpf}
                                    name="cnpjCpf"
                                    label={ifTipo(
                                        "CPF:",
                                        "CNPJ:",
                                        "CPF/CNPJ:")}
                                    type="number"
                                    icone={`${this.isVerifying() && validaCpfOrCnpj(cnpjCpf) ?
                                        "icon-lx-search" :
                                        ""}`}
                                    onIconeClick={this.cnpjCpfIconeClick}
                                    onKeyDown={(event) => {
                                        if (event.keyCode === 13)
                                            this.cnpjCpfIconeClick()
                                        else if (event.keyCode === 27)
                                            this.setState({ cnpjCpf: "" })
                                    }}

                                    format={maskCpfCnpj(cnpjCpf)}
                                    onChange={this.handleInputChange}
                                    disabled={!this.isVerifying()}
                                    help={`${this.isVerifying() ?
                                        (String(cnpjCpf).length === 11 ?
                                            (validaCPF(cnpjCpf) ?
                                                'Clique na "lupa" para verificar CPF' :
                                                "Não é um CPF válido"
                                            ) :
                                            (String(cnpjCpf).length === 14 ?
                                                (validaCNPJ(cnpjCpf) ?
                                                    'Clique na "lupa" para verificar CNPJ' :
                                                    "Não é um CNPJ válido"
                                                ) : "CPF/CNPJ (somente números)"
                                            )) : ""}`}

                                />

                            </div>
                            <div className={ifShow(!this.isVerifying(), "col-4")}>
                                <Select
                                    value={tipo}
                                    name="tipo"
                                    label={"Tipo da pessoa:"}
                                    options={[
                                        { value: none, label: "Não definida" },
                                        { value: 0, label: "Pessoa física" },
                                        { value: 1, label: "Pessoa jurídica" }
                                    ]}
                                    disabled
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(this.isEditing(), "col-4")}>
                                <InputText
                                    value={codigo}
                                    name="codigo"
                                    label="Código:"
                                    onChange={this.handleInputChange}
                                    disabled
                                />
                            </div>
                            <div className={ifShow(this.isEditing(), "col-4")}>
                                <Checkbox
                                    label="Situação:">
                                    <Checkitem
                                        checked={ativo}
                                        name="ativo"
                                        label="Ativo"
                                        onChange={this.handleInputChange}
                                        disabled={this.isInserting()}
                                    />
                                </Checkbox>
                            </div>
                        </div>
                        <div className={ifShow(!this.isVerifying(), "row")}>
                            <div className="col-4">
                                <Checkbox>
                                    <Checkitem
                                        checked={isCliente}
                                        name="isCliente"
                                        label="Cliente"
                                        //onChange={this.handleInputChange}
                                        onChange={(event) => {
                                            const isentoICMS = this.isPF() ?
                                                true : this.state.isentoICMS;
                                            this.setState({
                                                isCliente: event.target.checked,
                                                categoriaCliente: none,
                                                isentoICMS
                                            });
                                        }
                                        }
                                    />
                                </Checkbox>
                            </div>
                            <div className="col-4">
                                <Checkbox>
                                    <Checkitem
                                        checked={isFornecedor}
                                        name="isFornecedor"
                                        label="Fornecedor"
                                        // onChange={this.handleInputChange}
                                        onChange={(event) => {
                                            this.setState({
                                                isFornecedor: event.target.checked,
                                                categoriaFornecedor: none
                                            });
                                        }
                                        }
                                    />
                                </Checkbox>
                            </div>
                            <div className="col-4">
                                <Checkbox>
                                    <Checkitem
                                        checked={isFabricante}
                                        name="isFabricante"
                                        label="Fabricante"
                                        // onChange={this.handleInputChange}
                                        onChange={(event) => {
                                            this.setState({
                                                isFabricante: event.target.checked,
                                                categoriaFabricante: none
                                            });
                                        }
                                        }
                                    />
                                </Checkbox>
                            </div>
                            <div className="col-4">
                                <Checkbox>
                                    <Checkitem
                                        checked={isTransportadora}
                                        name="isTransportadora"
                                        label="Transportadora"
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                        </div>

                        <div className={ifShow(!this.isVerifying(), "row")}>
                            <div className={ifShow(this.isPF() && isCliente, "col-4")}>
                                <Select
                                    value={categoriaCliente}
                                    name="categoriaCliente"
                                    label="Tipo do cliente:"
                                    options={categoriasClientes}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(isFornecedor, "col-4")}>
                                <Select
                                    value={categoriaFornecedor}
                                    name="categoriaFornecedor"
                                    label="Tipo do fornecedor:"
                                    options={categoriasFornecedores}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(isFabricante, "col-4")}>
                                <Select
                                    value={categoriaFabricante}
                                    name="categoriaFabricante"
                                    label="Tipo do fabricante:"
                                    options={categoriasFabricantes}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className={ifShow(!this.isVerifying(), "row")}>
                            <div className="col-5">
                                <InputText
                                    value={nome}
                                    name="nome"
                                    label={ifTipo(
                                        "Nome:",
                                        "Razão social:",
                                        "Nome/Razão social:")}
                                    maxlength={65}
                                    help="Obrigatório"
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    value={apelido}
                                    name="apelido"
                                    label={ifTipo(
                                        "Apelido:",
                                        "Nome fantasia:",
                                        "Apelido/Nome fantasia:")}
                                    maxlength={30}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputDate
                                    value={dataNascimento}
                                    name="dataNascimento"
                                    label={ifTipo(
                                        "Data de nascimento:",
                                        "Data de fundação:",
                                        "Data de nascimento/fundação:")}
                                    onChange={this.handleInputChange}
                                    onFocusChanged={this.validateDataNascimento}
                                />
                            </div>
                        </div>

                        <div className={ifShow(!this.isVerifying(), "row")}>
                            <div className={ifShow(this.isPF(), "col-4")}>
                                <InputText
                                    value={identidade}
                                    label="Identidade:"
                                    name="identidade"
                                    help="Obrigatório"
                                    maxlength={15}
                                    visible={tipo !== TipoPessoa.Juridica}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(this.isPF(), "col-4")}>
                                <InputText
                                    value={orgaoEmissor}
                                    name="orgaoEmissor"
                                    label="Órgão emissor:"
                                    maxlength={18}
                                    visible={tipo !== TipoPessoa.Juridica}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(this.isPJ() || this.isRural(), "col-4")}>
                                <Checkbox
                                    label="ICMS:">
                                    <Checkitem
                                        checked={isentoICMS}
                                        name="isentoICMS"
                                        label="Isento"
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                            <div className={ifShow(this.needIE(), "col-4")}>
                                <InputText
                                    value={inscricaoEstadual}
                                    label="Inscrição estadual:"
                                    name="inscricaoEstadual"
                                    maxlength={20}
                                    help="Obrigatório"
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(this.isPJ(), "col-4")}>
                                <InputText
                                    value={inscricaoMunicipal}
                                    label="Inscrição municipal:"
                                    name="inscricaoMunicipal"
                                    maxlength={15}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className={ifShow(false && isCliente, "col-4")}>
                                <Checkbox
                                    label="Faturamento:">
                                    <Checkitem
                                        checked={emiteNFe}
                                        label="Emitir NF-e"
                                        name="emiteNFe"
                                        onChange={this.handleInputChange}
                                    />
                                </Checkbox>
                            </div>
                            <div className={ifShow(this.isContador(), "col-4")}>
                                <InputText
                                    value={nomeContador}
                                    label="Nome do(a) contador(a):"
                                    name="nomeContador"
                                    maxlength={50}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className={ifShow(this.isContador(), "col-4")}>
                                <InputText
                                    value={crc}
                                    label="CRC:"
                                    name="crc"
                                    maxlength={15}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                    </SectionContent>
                    <SectionContent
                        title="Endereço"
                        visible={!this.isVerifying()}
                        accordion accordionDefaultDisplay={false}>
                        <div className="row">
                            <div className="col-4">
                                <InputText
                                    value={cep}
                                    label="CEP:"
                                    name="cep"
                                    type="number"
                                    format="#####-###"
                                    icone={`${String(cep).length === 8 ?
                                        "icon-lx-search" :
                                        ""}`}
                                    onIconeClick={this.searchCep}
                                    onChange={this.handleInputChange}
                                    help={`${String(cep).length === 8 ?
                                        'Clique na "lupa" para buscar o CEP' :
                                        ""}`}
                                //onBlur={this.searchCep}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    value={endereco}
                                    label="Endereço:"
                                    name="endereco"
                                    maxlength={65}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <InputText
                                    value={numero}
                                    label="Número:"
                                    name="numero"
                                    type="number"
                                    decimalScale={0}
                                    maxlength={7}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    value={complemento}
                                    label="Complemento:"
                                    name="complemento"
                                    maxlength={45}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    value={referencia}
                                    label="Referência:"
                                    name="referencia"
                                    maxlength={45}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    value={bairro}
                                    label="Bairro:"
                                    name="bairro"
                                    maxlength={45}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <Select
                                    value={codigoUF}
                                    name="codigoUF"
                                    label="UF:"
                                    options={this.state.estados}
                                    onChange={this.changeEstado}
                                />
                            </div>
                            <div className="col-4">
                                <Select
                                    value={codigoMunicipio}
                                    name="codigoMunicipio"
                                    label="Cidade:"
                                    options={this.state.cidades}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <InputText
                                    value={contatoNome}
                                    label="Contato:"
                                    name="contatoNome"
                                    maxlength={50}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    value={contatoDescricao}
                                    label="Descrição:"
                                    name="contatoDescricao"
                                    maxlength={50}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    value={contatoDDD}
                                    label="DDD:"
                                    name="contatoDDD"
                                    type="number"
                                    decimalScale={0}
                                    maxlength={2}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                            <div className="col-4">
                                <InputText
                                    value={contatoNumero}
                                    label="Telefone:"
                                    name="contatoNumero"
                                    type="number"
                                    maxlength={15}
                                    decimalScale={0}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    value={contatoEMail}
                                    label="E-mail:"
                                    name="contatoEMail"
                                    maxlength={65}
                                    onChange={this.handleInputChange}
                                    onBlur={this.validateEmail}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    value={site}
                                    label="Endereço Internet:"
                                    name="site"
                                    maxlength={50}
                                    onChange={this.handleInputChange}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer >

                <FormOptions
                    handleSalvar={this.isInserting() || this.isEditing() ? this.handleSalvar : null}
                    handleExcluir={this.isEditing() ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}
                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.state.alertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenPessoas extends Component {
    state = {
        pessoas: [],
        pessoaSel: {},
        searchText: null,
        lastSearch: null,
        listas: []
    }

    loadPessoas = async (text) => {
        const search = !!text ? text : this.state.searchText;
        if (search) {
            const pessoas = []; 
            const { data } = await getPessoas({ search });

            data.result.forEach((pessoa) => {
                pessoas.push(apiToState(pessoa))
            });
            this.setState({ lastSearch: search, pessoas });
        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            if (this.state.lastSearch) {
                this.setState({ searchText: this.state.lastSearch });
                this.loadPessoas((this.state.lastSearch));
            }
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) {
            this.setState({ pessoaSel: rowInfo.original });
            this.props.history.push("/pessoas/new");
        }
    }

    render() {
        const { edit } = this.props,
            {
                pessoaSel,
                searchText,
                lastSearch
            } = this.state;
        this.handleInputChange = handleInputChange.bind(this);

        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Pessoas"
                        right={
                            <div className={ifShow(!edit, "button-container")}>
                                <div className={"section-header-search"}>
                                    <InputText
                                        value={searchText}
                                        name="searchText"
                                        placeholder="Buscar"
                                        help={`${searchText ? 'Clique na "lupa" para buscar' : ""}`}
                                        icone={searchText ? "icon-lx-search" : ""}
                                        onIconeClick={() => { this.loadPessoas() }}
                                        onChange={this.handleInputChange}
                                        onKeyDown={searchText ? (event) => {
                                            if (event.keyCode === 13)
                                                this.loadPessoas()
                                            else if (event.keyCode === 27)
                                                this.setState({ searchText: this.state.lastSearch })
                                        } : null}
                                    />
                                </div>

                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao
                                            ic
                                            icon="icon-lx-plus"
                                            onClick={() => {
                                                this.setState({ pessoaSel: {} });
                                                this.props.history.push("/pessoas/new")
                                            }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form pessoa={pessoaSel} pessoasExistentes={this.state.pessoas} />
                    ) : (
                            <>
                                <List
                                    onClick={this.handleTableClick}
                                    defaultPageSize={10}
                                    noDataText={`${!this.state.lastSearch ?
                                        'Inicie fazendo uma busca ou incluindo uma nova pessoa.' :
                                        'Sua pesquisa "' + this.state.lastSearch + '" não encontrou nenhuma pessoa correspondente.'}`}
                                    cols={[
                                        {
                                            accessor: "nome",
                                            Header: "Nome/Razão Social",
                                            width: 400
                                        },
                                        {
                                            accessor: "cnpjCpf",
                                            Header: "CPF/CNPJ",
                                            width: 160,
                                            Cell: props =>
                                                <div>
                                                    {maskedCnpjCpf(props.value)}
                                                </div>
                                        },
                                        {
                                            accessor: "apelido",
                                            Header: "Apelido/Nome Fantasia",
                                            width: 320
                                        },
                                        {
                                            accessor: "codigo",
                                            Header: "Código",
                                            width: 100
                                        }
                                    ]}
                                    rows={this.state.pessoas}
                                />
                            </>
                        )}
                </section>
            </main>
        );
    }
}

function ifShow(condition, divName) {
    return condition ? divName : "content-hidden"
}

ScreenPessoas = withRouter(ScreenPessoas);
export { ScreenPessoas };
