import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import {
    InputText,
    Checkbox,
    Checkitem,
    Select,
    FormOptions,
    handleInputChange
} from "../../formulario/Formulario";
import {
    List,
    sortInt
} from "./../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "./../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getBancos,
    getBanco,
    getTiposBancos,
    incluiBanco,
    alteraBanco,
    excluiBanco
} from "../../../services/Bancos";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);

        const {
            codigo = null,
            codigoEstabelecimento = "1",
            nome = "",
            tipo = "1",
            restrito = false,
            excluido = false,
            inativo = false,
            novoCodigo = null,
            rowVersion = null
        } = this.props.banco;

        this.state = {
            codigo,
            codigoEstabelecimento,
            nome,
            tipo,
            restrito,
            excluido,
            inativo,
            novoCodigo,
            tipos: [],
            rowVersion,

            codigoOriginal: codigo,
            objetoCodigoTipo: { codigo },

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert   

            bancosExistentes: this.props.bancosExistentes
        };

    }

    /*
    async componentDidMount() {        
        const { data: tipos } = await getTiposBanco(1);
        this.setState({ tipos: tipos.map(t => 
            {return {label: t.descricao, value: t.codigo }})});        
    }
    */

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoEstabelecimento,
            codigo } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/bancos/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluiBanco(codigo);
                        //sucesso                        
                        this.showInfo("Banco excluído com sucesso!");
                    } catch (err) {
                        // falha                        
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/bancos/");
                }
                break;

            default:
                break;
        }
    };

    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            /*codigo: null,
            codigoEstabelecimento: "",
            nome: "",
            rowVersion: null,
            tipo: null,
            restrito: false,
            excluido: false,*/
            alertActive: true,
            alertType: "success",
            alertTitle: "Bancos",
            alertSubtitle: message
        });
    }

    verificaCodigoExistente = (valorCodigo) => {
        let existeCodigo = false;
        let lista = this.state.bancosExistentes;
        for (let i = 0; i < lista.length; i++) {
            const bancosLista = lista[i];
            if (bancosLista.codigo === valorCodigo)
                existeCodigo = true;
        }
        if (existeCodigo)
            this.showError("Código já está sendo utilizado por outro banco");

        return existeCodigo;
    }

    verificaBancos = () => {

        var temErros = false;
        //verifica preenchimento dos campos

        if (!this.state.codigo) {
            this.showError("Código do banco é obrigatório");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (this.state.nome.trim() === "") {
            this.showError("Descrição do banco é obrigatória");
            temErros = true;
        }

        if (temErros)
            return temErros;

        if (!this.state.rowVersion)
            temErros = this.verificaCodigoExistente(this.state.codigo);

        return temErros;
    }

    handleSalvar = async () => {
        let {
            codigo,
            nome,
            restrito,
            inativo = false,
            rowVersion,
            codigoAlterado,
            novoCodigo,
            objetoCodigoTipo,
            codigoOriginal
        } = this.state;

        if (this.state.restrito) {
            this.showError("Banco selecionado está indicado como restrito e por isso não pode ser alterado")
        } else {

            if (codigoOriginal !== codigo) {
                novoCodigo = codigo;
                codigoAlterado = true;
            }

            objetoCodigoTipo.codigo = this.state.tipo;

            const [action, params] =
                rowVersion !== null
                    ? [
                        alteraBanco,
                        [
                            codigoOriginal,
                            nome,
                            objetoCodigoTipo,
                            restrito,
                            inativo,
                            rowVersion,
                            codigoAlterado,
                            novoCodigo
                        ]
                    ]
                    : [
                        incluiBanco,
                        [
                            novoCodigo,
                            nome,
                            objetoCodigoTipo,
                            restrito,
                            inativo
                        ]
                    ];

            var temErros = this.verificaBancos();

            if (!temErros) {

                try {
                    //const resp = await action(...params);
                    await action(...params);
                    //console.log(resp);
                    this.setState({
                        /*codigo: null,
                        codigoEstabelecimento: "1",
                        nome: "",
                        tipo: "",
                        restrito: false,
                        excluido: false,*/
                        inativo: false,
                        rowVersion: null,
                        alertActive: true,
                        alertType: "success",
                        alertTitle: "Bancos",
                        alertSubtitle: `Banco ${rowVersion === null ? "incluído" :
                            "alterado"} com sucesso!`
                    });
                } catch (err) {
                    this.setState({
                        alertActive: true,
                        alertType: "error",
                        alertTitle: "Erro",
                        alertSubtitle: err.response.data.message
                    });
                }
            }
        }
    };

    handleExcluir = () => {
        let {
            codigo,
            codigoOriginal
        } = this.state;

        let temErros = false;

        if (this.state.restrito) {
            this.showError("Banco selecionado está indicado como restrito e por isso não pode ser excluído.")
        } else {

            if (!this.state.codigo) {
                this.showError("Código do banco é obrigatório para exclusão");
                temErros = true;
            }

            if(!temErros)
            {
                if (codigoOriginal !== codigo) {
                    this.showError("Código foi alterado e por isso não é possível a exclusão");
                    temErros = true;
                }
            }

            if (!temErros) {
                //console.log("excluir");
                this.setState({
                    alertActive: true,
                    alertType: "question",
                    alertTitle: "Bancos",
                    alertSubtitle: "Deseja excluir?"
                });
            }
        }
    }

    handleBlur = (event) => {
        /*
        let labelCampo = "";
        let campo = event.target;
        if (this.state[campo.name] === "") {
            switch (campo.name) {
                case "codigo":
                    labelCampo = "Código";
                    break;

                case "nome":
                    labelCampo = "Banco";
                    break;

                case "tipo":
                    labelCampo = "Tipo";
                    break;

                default:
                    break;
            }
            this.showError("É obrigatório informar o " + labelCampo);
        }
        */
    }

    handleCancelar = () => {
        console.log("cancelar");
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Bancos",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    async componentDidMount() {
        const { data: tiposBancos } = await getTiposBancos();
        this.setState({
            tipos: tiposBancos.map(t => {
                return {
                    label: t.descricao,
                    value: t.codigo
                }
            })
        });
    }

    render() {
        const {
            codigo,
            nome,
            tipo,
            tipos,
            restrito,
            rowVersion,
            //novoCodigo,
            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="Dados do Banco">
                        <div className="row">
                            <div className="col-12">
                                <InputText
                                    label="Código:"
                                    value={codigo}
                                    name="codigo"
                                    type="number"
                                    decimalScale={0}
                                    allowNegative={false}
                                    maxlength="4"
                                    autofocus
                                    required
                                    onBlur={this.handleBlur}
                                    onChange={this.handleInputChange}
                                    disabled={restrito}
                                />
                            </div>

                            <div className="col-3">
                                <InputText
                                    label="Banco:"
                                    value={nome}
                                    name="nome"
                                    required
                                    onBlur={this.handleBlur}
                                    onChange={this.handleInputChange}
                                    maxlength={50}
                                    disabled={restrito}
                                />
                            </div>

                            <div className="col-2">
                                <Select
                                    label="Tipo:"
                                    name="tipo"
                                    value={tipo}
                                    onChange={this.handleInputChange}
                                    options={tipos}
                                    required
                                    disabled={restrito}
                                />
                            </div>
                            <div className="col-12">
                                <Checkbox label="Restrito:">
                                    <Checkitem
                                        label=""
                                        name="restrito"
                                        checked={restrito}
                                        onChange={this.handleInputChange}
                                        disabled
                                    />
                                </Checkbox>
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions
                    handleSalvar={
                        restrito !== true ? this.handleSalvar : null}
                    handleExcluir={
                        ((rowVersion !== null) && (restrito !== true))  ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}

                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenBancos extends Component {
    state = { bancos: [], bancoSel: {} };

    async doMount() {
        const { data: bc } = await getBancos();
        const bancosArray = bc.result;
        this.setState({
            bancos: bancosArray.map(b => {
                return {
                    codigo: b.codigo,
                    nome: b.nome,
                    tipo: b.tipo.codigo,
                    tipoDesc: b.tipo.descricao,
                    restrito: b.restrito,
                    inativo: b.inativo,
                    dataInativacao: b.dataInativacao,
                    rowVersion: b.rowVersion,
                    codigoAlterado: b.codigoAlterado,
                    novoCodigo: b.novoCodigo
                }
            }
            )
        }
        );
    }

    componentDidMount() {
        this.doMount();
    }

    componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            this.doMount();
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) {
            this.setState({ bancoSel: rowInfo.original });
            this.props.history.push("/bancos/new");
        }
    }

    render() {
        const { edit } = this.props,
            { bancoSel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Bancos"
                        subtitle=""
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <>

                                    </>
                                ) : (
                                        <Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ bancoSel: {} });
                                            this.props.history.push("/bancos/new")
                                        }} />
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form banco={bancoSel}
                            bancosExistentes={this.state.bancos}

                        />
                    ) : (
                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "codigo",
                                        Header: "Código",
                                        width: 200,
                                        filterable: false,
                                        sortMethod: sortInt
                                    },
                                    {
                                        accessor: "nome",
                                        Header: "Nome",
                                        width: 400,
                                        filterable: false
                                    },
                                    {
                                        accessor: "tipoDesc",
                                        Header: "Tipo",
                                        width: 150,
                                        filterable: false
                                    },
                                    {
                                        accessor: "restrito",
                                        Header: "Restrito",
                                        width: 100,
                                        filterable: false,
                                        Cell: ({ row }) => {
                                            return (
                                                <Botao
                                                    secondary={!row.restrito}
                                                    ic
                                                    icon={
                                                        row.restrito ?
                                                            "icon-lx-check" :
                                                            "icon-lx-close"
                                                    }
                                                />
                                            );
                                        }
                                    }
                                ]}
                                rows={this.state.bancos}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenBancos = withRouter(ScreenBancos);
export { ScreenBancos };