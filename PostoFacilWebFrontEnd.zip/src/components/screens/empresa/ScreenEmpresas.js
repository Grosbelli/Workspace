import React, { Component } from "react";
import ReactDOM from "react-dom";
import { Botao } from "../../botoes/Botao";
import {
  InputText,
  Select,
  Checkbox,
  Checkitem,
  FormOptions,
  handleInputChange,
  InputDate
} from "../../formulario/Formulario";
import { List, sortInt } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import { consultaCep } from "../../../utils/ConsultaCep";

import {
  getEstabelecimentos,
  montarComboContador,
  incluirEstabelecimento,
  alterarEstabelecimento,
  excluirEstabelecimento,
  montarComboUfs,
  montarComboMunicipios,
  listarCNAEs
} from "../../../services/Empresa";

import {
  validaCNPJ,
  validaIE,
  validaCPF
} from "../../../utils/Utils";

import ReactTable from "react-table";
import "react-table/react-table.css";

import "rc-tree/assets/index.css";
import Tree from "rc-tree";
import Tooltip from "rc-tooltip";
import moment from "moment";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.handleInputChange = handleInputChange.bind(this);

    this.handleCNAE = this.handleCNAE.bind(this);

    const {

      //empresas

      codigoEstabelecimento = null,
      razaoSocial = null,
      inativo = false,
      nomeFantasia = null,
      cnpj = null,
      inscricaoEstadual = "",
      inscricaoMunicipal = null,
      codigoANP = null,
      dataConstituicao = null,
      email = null,
      enderecoInternet = "",
      rowVersion = null,

      //endereco

      endereco = {},

      //setor

      setor = [],

      //representante legal

      representante = {},

      //informacoes Fiscais

      fiscais = {},

      //CNAE

      cnae = []

    } = this.props.estabelecimento;

    var cnaesEmpresaSelecionada = [];

    var codigoSpedFiscalEmpresa = fiscais.codigoSpedFical;

    /*switch (fiscais.codigoSpedFical) {
      case "A":
        codigoSpedFiscalEmpresa = 1;
        break;

      case "B":
        codigoSpedFiscalEmpresa = 2;
        break;

      case "C":
        codigoSpedFiscalEmpresa = 3;
        break;

      default:
        break;
    }*/

    var representanteEmpresa = {};

    if (representante !== null)
      representanteEmpresa = representante;

    this.state = {
      //empresas

      codigoEstabelecimento,
      razaoSocial,
      ativo: !inativo,
      nomeFantasia,
      cnpj,
      inscricaoEstadual,
      inscricaoMunicipal,
      codigoANP,
      dataConstituicao,
      email,
      enderecoInternet,
      rowVersion,

      //endereço      

      Cep: endereco.cep,
      Endereco: endereco.endereco,
      Numero: endereco.numero,
      Complemento: endereco.complemento,
      Bairro: endereco.bairro,
      CodigoUF: endereco.codigoUF,
      CodigoMunicipio: endereco.codigoMunicipio,

      //setor

      setorLoja: setor.filter(s => parseInt(s.codigo) === 2).length !== 0, //Loja
      setorPista: setor.filter(s => parseInt(s.codigo) === 3).length !== 0, // Pista
      setorTrocaOleo: setor.filter(s => parseInt(s.codigo) === 4).length !== 0, // Centro de Serviços

      //representante legal      

      Nome: representanteEmpresa.nome,
      CPF: representanteEmpresa.cpf,
      FuncaoCargo: representanteEmpresa.funcaoCargo,

      //informacoes Fiscais

      perfilSpedFiscal: codigoSpedFiscalEmpresa,
      RegimenTributario: fiscais.regimenTributario,
      CodigoContador: fiscais.codigoContador,

      //CNAE

      cnae,

      listaContadores: [],
      listaUFs: [],
      listaCNAE: [],
      listaCNAEEmpresa: [],


      alertActive: false, // se o alert deve ser apresentado
      alertType: "", // tipo de alert (sucesso, erro...)
      alertTitle: "", // titulo do alert
      alertSubtitle: "", // subtitulo/mensagem do alert
    };
  }

  async componentDidMount() {
    const { data: listaContadores } = await montarComboContador(1);

    const contadorVazio = {
      codigo: 0,
      descricao: ""
    }

    listaContadores.push(contadorVazio);

    this.setState({
      listaContadores: listaContadores.map(contador => {
        return {
          label: contador.descricao,
          value: contador.codigo
        }
      })
    });

    const { data: listaUFs } = await montarComboUfs();

    this.setState({
      listaUFs: listaUFs.map(uf => {
        return {
          label: uf.descricao,
          value: uf.codigo
        }
      })
    });

    if (this.props.estabelecimento !== null) {
      this.carregaComboMunicipios();
    }

  }

  handleAlertAction = async (resp) => {
    const { alertType,
      codigoEstabelecimento
    } = this.state;

    this.setState({
      alertActive: false,
      alertType: "",
      alertTitle: "",
      alertSubtitle: ""
    });

    switch (alertType) {
      case "success":
        this.props.history.push("/empresas/");
        break;

      case "question":
        if (resp) {
          try {
            await excluirEstabelecimento(codigoEstabelecimento);
            //sucesso
            console.log("sucesso");
            this.showInfo("Empresa excluída com sucesso!");
          } catch (err) {
            // falha
            console.log("fallha");
            this.showError(err.response.data.message);
          }
        }
        break;

      case "cancel":
        if (resp) {
          this.props.history.push("/empresas/");
        }
        break;


      default:
        break;
    }
  };

  showError = (message) => {
    this.setState({
      alertActive: true,
      alertType: "error",
      alertTitle: "Erro",
      alertSubtitle: message
    });
  }

  showInfo = (message) => {
    this.setState({
      alertActive: true,
      alertType: "success",
      alertTitle: "empresas",
      alertSubtitle: message
    });
  }

  handleSalvar = async () => {
    const {
      razaoSocial,
      ativo,
      nomeFantasia,
      codigoANP,
      dataConstituicao,
      cnpj,
      inscricaoEstadual,
      inscricaoMunicipal,
      email,
      enderecoInternet = enderecoInternet === null ? "" : enderecoInternet,
      Cep,
      Endereco,
      Numero,
      Complemento,
      Bairro,
      CodigoUF,
      CodigoMunicipio,
      Nome,
      CPF,
      FuncaoCargo,
      setorLoja,
      setorPista,
      setorTrocaOleo,
      perfilSpedFiscal,
      RegimenTributario,
      CodigoContador,
      cnae,
      rowVersion,

    } = this.state,
      inativo = !ativo,
      objEndereco = {
        Cep,
        Endereco,
        Numero,
        Complemento: Complemento === null ? "" : Complemento,
        Bairro,
        CodigoUF,
        CodigoMunicipio
      },
      representante = {
        Nome,
        CPF,
        FuncaoCargo,
      },
      infoFiscais = {
        CodigoSpedFical: perfilSpedFiscal,
        RegimenTributario,
        CodigoContador
      },
      objSetorLoja = {
        codigo: 2,
        descricao: "Loja"
      },
      objSetorPista = {
        codigo: 3,
        descricao: "Pista"
      },
      objSetorCS = {
        codigo: 4,
        descricao: "Centro de Serviços"
      },
      cnaes = [],
      setores = [];

    for (let i = 0; i < cnae.length; i++) {
      const element = cnae[i];
      const objCNAE = {
        codCnae: "",
        cnaeCodigo: "",
        cnaeDescricao: "",
        primario: false
      }
      objCNAE.codCnae = element.codCnae;
      objCNAE.cnaeCodigo = element.cnaeCodigo;
      objCNAE.cnaeDescricao = element.cnaeDescricao;
      objCNAE.primario = element.primario;
      cnaes.push(objCNAE);
    }

    if (setorLoja)
      setores.push(objSetorLoja);
    if (setorPista)
      setores.push(objSetorPista);
    if (setorTrocaOleo)
      setores.push(objSetorCS);

    const [action, params] =
      rowVersion !== null
        ? [
          alterarEstabelecimento,
          [
            1,
            razaoSocial,
            inativo,
            nomeFantasia,
            codigoANP,
            dataConstituicao,
            cnpj,
            inscricaoEstadual,
            inscricaoMunicipal,
            email,
            enderecoInternet,
            objEndereco,
            representante,
            infoFiscais,
            setores,
            cnaes,
            rowVersion
          ]
        ]
        : [
          incluirEstabelecimento,
          [
            razaoSocial,
            inativo,
            nomeFantasia,
            codigoANP,
            dataConstituicao,
            cnpj,
            inscricaoEstadual,
            inscricaoMunicipal,
            email,
            enderecoInternet,
            objEndereco,
            representante,
            setores,
            infoFiscais,
            cnaes
          ]
        ];

    var temErros = false;

    if (!this.validaDataEscolhida()) {
      this.showError("Campo Data de Constituição deve ser uma data válida");
      temErros = true;
    }

    if (!temErros)
      temErros = this.verificaestabelecimento();

    if (!temErros) {


      try {
        const resp = await action(...params);
        console.log(resp);
        this.setState({
          alertActive: true,
          alertType: "success",
          alertTitle: "Empresas",
          alertSubtitle: `Empresa ${rowVersion === null ? "cadastrada" : "alterada"} com sucesso!`
        });
      } catch (err) {
        this.setState({
          alertActive: true,
          alertType: "error",
          alertTitle: "Erro",
          alertSubtitle: err.response.data.message
        });
      }
    }
  };

  handleExcluir = () => {
    console.log("excluir");
    var temErros = false;

    if (!temErros)

      if (!temErros) {

        this.setState({
          alertActive: true,
          alertType: "question",
          alertTitle: "Empresas",
          alertSubtitle: "Confirma a exclusão do empresas?"
        });
      }
  }

  handleCancelar = () => {
    console.log("cancelar");
    this.setState({
      alertActive: true,
      alertType: "cancel",
      alertTitle: "Empresas",
      alertSubtitle: "Deseja realmente cancelar a operação?"
    });
  }

  verificaestabelecimento = () => {
    //verifica preenchimento dos campos   

    var temErros = false;

    if ((!this.state.razaoSocial) || (this.state.razaoSocial.trim() === '')) {
      this.showError("É necessário informar a razão social.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if ((!this.state.nomeFantasia) || (this.state.nomeFantasia.trim() === '')) {
      this.showError("É necessário informar o nome fantasia.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if ((!this.state.inscricaoEstadual) || (this.state.inscricaoEstadual.trim() === '')) {
      this.showError("É necessário informar a inscrição estadual.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if (!this.validaEmail()) {
      temErros = true;
      return temErros;
    }

    if ((!this.state.Cep) || (this.state.Cep.trim() === '')) {
      this.showError("É necessário informar o cep.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if ((!this.state.Endereco) || (this.state.Endereco.trim() === '')) {
      this.showError("É necessário informar o endereço.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if ((!this.state.Bairro) || (this.state.Bairro.trim() === '')) {
      this.showError("É necessário informar o bairro.");
      temErros = true;
    }

    if (!this.state.setorLoja && !this.state.setorPista && !this.state.setorTrocaOleo) {
      this.showError("Deve ser selecionado ao menos um setor");
      temErros = true;
    }


    if ((!this.state.Nome) || (this.state.Nome.trim() === '')) {
      this.showError("É necessário informar o nome do representante legal.");
      temErros = true;
    }

    if (temErros)
      return temErros;

    if ((!this.state.CPF) || (this.state.CPF.trim() === '')) {
      this.showError("Campo CPF do Representante legal deve ser preenchido.");
      temErros = true;
    }

    temErros = (!this.verificaCPF());

    if (temErros)
      return temErros;

    temErros = (!this.verificaIE());

    if (temErros)
      return temErros;

    /*if (this.state.cnae.length === 0) {
      this.showError("Deve ser informada ao menos uma CNAE");
      temErros = true;
    }
  
    if (temErros)
    return temErros;*/

    if (this.state.cnae.length > 0) {
      var existePrimario = false;

      for (let i = 0; i < this.state.cnae.length; i++) {
        const element = this.state.cnae[i];
        if (element.primario)
          existePrimario = true;
      }

      if (!existePrimario) {
        this.showError("Deve ser informada ao menos um CNAE primário");
        temErros = true;
      }

      if (temErros)
        return temErros;
    }
  }


  validaTeclaDigitada = (e) => {
    const re = /[0-9a-zA-Z]+/g;
    if (!re.test(e.key)) {
      e.preventDefault();
    }

    if ((e.key === 'ç')) {
      e.preventDefault();
    }
  }

  validaTextoColado = (event) => {
    console.log(event.clipboardData.getData('Text'));

    var textoNovo = "";

    var textoOriginal = "";

    var tamMax = 0;
    var tamTexto = 0;

    tamMax = event.target.maxLength;

    var caracterEspecial = false;

    var campo = event.target.name;

    textoOriginal = event.clipboardData.getData('Text');

    for (let i = 0; i < textoOriginal.length; i++) {
      const re = /[0-9a-zA-Z]+/g;
      const c = textoOriginal[i];
      tamTexto = textoNovo.length;
      caracterEspecial = false;
      if (!re.test(c)) {
        caracterEspecial = true;
      }

      if ((c === 'ç')) {
        caracterEspecial = true;
      }

      if (tamTexto < tamMax)
        if (!caracterEspecial)
          textoNovo += c;
    }

    if (caracterEspecial)
      event.preventDefault();

    this.setState({
      [campo]: textoNovo
    });

  }

  verificaCNPJ = () => {
    if (!validaCNPJ(this.state.CNPJ)) {
      this.showError('CNPJ não é válido');
    }
  }

  verificaCPF = () => {
    if ((!this.state.CPF) || (this.state.CPF.trim() === '')) {
      this.showError("Campo CPF do Representante legal deve ser preenchido.");
      return false;
    }
    else if (!validaCPF(this.state.CPF)) {
      this.showError('CPF do Representante legal não é válido');
      return false;
    }
    else
      return true;
  }

  verificaIE = () => {

    console.log("this.state.CodigoUF->" + this.state.CodigoUF);
    var codigoEstado = this.state.CodigoUF;
    var ie = "";
    ie = this.state.inscricaoEstadual.toString();

    var UF = "";

    UF = this.state.listaUFs.filter(uf => parseInt(uf.value) === parseInt(codigoEstado));
    console.log("UF->" + UF[0].label);
    if (!validaIE(ie, UF[0].label)) {
      this.showError('Inscrição estadual não é válida');
      return false;
    }
    else
      return true;
  }

  consultaDadosCep = async () => {
    const { data: dadosCep } = await consultaCep(this.state.Cep);
    var logradouroTratado = "";
    if (dadosCep) {
      var dadosCepValue = dadosCep.value;

      if (dadosCep.value)
        logradouroTratado = dadosCep.value.OBS === "" ? dadosCepValue.LOGRADOURO : dadosCepValue.LOGRADOURO.substring(0, dadosCepValue.LOGRADOURO.indexOf(dadosCepValue.OBS));

      if (dadosCepValue) {
        this.setState({ CodigoUF: dadosCepValue.ID_UF });
        this.carregaComboMunicipios();
        this.setState({ Endereco: dadosCepValue.TIPO_LOGRADOURO + " " + logradouroTratado, Bairro: dadosCepValue.BAIRRO, CodigoMunicipio: dadosCepValue.COD_MUNICIPIO_IBGE });
      }
      else {
        this.showError('Cep não encontrado');
      }

    }
  }

  carregaComboMunicipios = async (codigoUFAtual) => {

    if (!codigoUFAtual)
      codigoUFAtual = this.state.CodigoUF;
    console.log("carregando..." + codigoUFAtual);
    const { data: listaMunicipios } = await montarComboMunicipios(codigoUFAtual);
    this.setState({
      listaMunicipios: listaMunicipios.map(cid => {
        return {
          label: cid.descricao,
          value: cid.codigo
        }
      })
    });

  }

  handleUFChange = (event) => {
    let value = "";

    value = event.target.value;

    this.setState({
      CodigoUF: value
    });

    this.carregaComboMunicipios(value);

  }

  handleCNAE(cnae) {
    console.log('cnae->' + cnae.length);
    this.setState({
      cnae
    })
  }

  validaDataEscolhida = () => {
    var dataValida = false;
    dataValida = moment(this.state.dataConstituicao, "YYYY-MM-DD").isValid();
    return dataValida;
  }

  validaEmail = () => {
    if ((!this.state.email) || (this.state.email.trim() === '')) {
      this.showError("O campo E-mail deve ser preenchido.");
      return false;
    } else {

      let field = this.state.email;
      let usuario = field.substring(0, field.indexOf("@"));
      let dominio = field.substring(field.indexOf("@") + 1, field.length);

      if (!((usuario.length >= 1) &&
        (dominio.length >= 3) &&
        (usuario.search("@") == -1) &&
        (dominio.search("@") == -1) &&
        (usuario.search(" ") == -1) &&
        (dominio.search(" ") == -1) &&
        (dominio.search(".") != -1) &&
        (dominio.indexOf(".") >= 1) &&
        (dominio.lastIndexOf(".") < dominio.length - 1))) {
        this.showError('E-mail não é válido');
        return false;
      }
    }

    return true;

  }

  validaRegimeTributario = (e) => {
    var regime = e.target.value;
    var perfil = this.state.perfilSpedFiscal;
    if ((perfil === "3") && ((regime !== "4") && (regime !== "8")))
      this.showError("Para o perfil C, é recomendado utilizar regime tributário Simples Nacional.");
  }

  /*validaPerfilSPED = (e) => {
    var regime = e.target.value;
    var perfil = this.state.perfilSpedFiscal;
    if (((regime === 4) || (regime === 8)) && ((perfil !== "3")))
      this.showError("Para o regime tributário Simples Nacional, é recomendado utilizar Perfil do SPED C.");
  }*/

  defineRegimeTributario = (e) => {
    var perfil = e.target.value;
    if (perfil === "1")
      this.setState({ RegimenTributario: 2 });
    else if (perfil === "2")
      this.setState({ RegimenTributario: 1 });
    else if (perfil === "3")
      this.setState({ RegimenTributario: 4 });
  }

  render() {
    const {
      //campos tela
      codigoEstabelecimento,
      razaoSocial,
      ativo,
      nomeFantasia,
      cnpj,
      inscricaoEstadual,
      inscricaoMunicipal,
      codigoANP,
      dataConstituicao,
      email,
      enderecoInternet = "",
      rowVersion,

      //endereço

      Cep,
      Endereco,
      Numero,
      Complemento,
      Bairro,
      CodigoUF,
      CodigoMunicipio,

      //setor

      setorLoja,
      setorPista,
      setorTrocaOleo,

      //representante legal

      Nome,
      CPF,
      FuncaoCargo,

      //informacoes Fiscais

      perfilSpedFiscal,
      RegimenTributario,
      CodigoContador,

      //CNAE

      primario,
      cnae,

      listaUFs,
      listaContadores,
      listaMunicipios,

      alertActive,
      alertType,
      alertTitle,
      alertSubtitle,
    } = this.state;
    return (
      <>
        <SectionContainer>
          <SectionContent title="Identificação da empresas" accordion>
            <div className="row">
              <div className="col-5">
                <InputText
                  label="Razão Social"
                  value={razaoSocial}
                  name="razaoSocial"
                  onChange={this.handleInputChange}
                  tabindex={1}
                  maxlength="65"
                />
              </div>
              <div className="col-5">
                <InputText
                  label="Nome Fantasia"
                  value={nomeFantasia}
                  name="nomeFantasia"
                  onChange={this.handleInputChange}
                  tabindex={2}
                  maxlength="30"
                />
              </div>
            </div>
            <div className="row">
              <div className="col-5">
                <InputText
                  label="CNPJ"
                  type="number"
                  value={cnpj}
                  name="cnpj"
                  onChange={this.handleInputChange}
                  onBlur={this.verificaCNPJ}
                  format="##.###.###/####-##"
                  help="Apenas números"
                  tabindex={3}
                  disabled={rowVersion !== null}
                />
              </div>
              <div className="col-5">
                <InputText
                  label="Inscrição Estadual"
                  value={inscricaoEstadual}
                  name="inscricaoEstadual"
                  onChange={this.handleInputChange}
                  onBlur={this.verificaIE}
                  onKeyDown={this.validaTeclaDigitada}
                  onPaste={this.validaTextoColado}
                  tabindex={4}
                  disabled={rowVersion !== null}
                />
              </div>
            </div>
            <div className="row">
              <div className="col-5">
                <InputText
                  label="Inscrição Municipal"
                  type="number"
                  value={inscricaoMunicipal}
                  name="inscricaoMunicipal"
                  onChange={this.handleInputChange}
                  tabindex={5}
                  maxlength="15"
                />
              </div>
              <div className="col-5">
                <InputText
                  label="ANP"
                  value={codigoANP}
                  name="codigoANP"
                  onChange={this.handleInputChange}
                  tabindex={6}
                  maxlength="11"
                />
              </div>
            </div>
            <div className="row">
              <div className="col-5">
                <InputDate
                  label="Data Constituição"
                  value={dataConstituicao}
                  name="dataConstituicao"
                  onChange={this.handleInputChange}
                  tabindex={7}
                />
              </div>
              {/*<div className="col-2">
                <Checkbox label="Ativo">
                  <Checkitem
                    label=""
                    name="ativo"
                    checked={ativo}
                    onChange={this.handleInputChange}
                    tabindex={8}
                  />
                </Checkbox>
    </div>*/}
            </div>
            <div className="row">
              <div className="col-5">
                <InputText
                  label="E-mail"
                  value={email}
                  name="email"
                  onChange={this.handleInputChange}
                  onBlur={this.validaEmail}
                  tabindex={9}
                  maxlength="65"
                />
              </div>
              <div className="col-5">
                <InputText
                  label="Endereço Internet"
                  value={enderecoInternet}
                  name="enderecoInternet"
                  onChange={this.handleInputChange}
                  tabindex={10}
                  maxlength="50"
                />
              </div>
            </div>
          </SectionContent>
          <div className="content-divider" />
          <SectionContent title="Endereço" accordion accordionDefaultDisplay={false}>
            <div className="row">
              <div className="col-5">
                <InputText
                  type="number"
                  label="Cep"
                  name="Cep"
                  value={Cep}
                  onChange={this.handleInputChange}
                  onBlur={this.consultaDadosCep}
                  icone="icon-lx-search"
                  tabindex={11}
                  //maxlength="10"
                  format="#####-###"

                />
              </div>

            </div>

            <div className="row">
              <div className="col-1">
                <InputText
                  label="Endereço"
                  name="Endereco"
                  value={Endereco}
                  onChange={this.handleInputChange}
                  tabindex={12}
                  maxlength="65"
                />
              </div>
            </div>

            <div className="row">

              <div className="col-4">
                <InputText
                  label="Número"
                  name="Numero"
                  value={Numero}
                  onChange={this.handleInputChange}
                  tabindex={13}
                />
              </div>

              <div className="col-4">
                <InputText
                  label="Complemento"
                  name="Complemento"
                  value={Complemento}
                  onChange={this.handleInputChange}
                  tabindex={14}
                  maxlength="45"
                />
              </div>

              <div className="col-5">
                <InputText
                  label="Bairro"
                  name="Bairro"
                  value={Bairro}
                  onChange={this.handleInputChange}
                  tabindex={15}
                  maxlength="45"
                />
              </div>

            </div>

            <div className="row">

              <div className="col-4">
                <Select
                  label="UF"
                  name="CodigoUF"
                  value={CodigoUF}
                  onChange={this.handleUFChange}
                  options={listaUFs}
                  required
                  autofocus="true"
                  tabindex={16}
                />
              </div>

              <div className="col-1">
                <Select
                  label="Cidade"
                  name="CodigoMunicipio"
                  value={CodigoMunicipio}
                  onChange={this.handleInputChange}
                  options={listaMunicipios}
                  required
                  autofocus="true"
                  tabindex={17}
                />
              </div>

            </div>
          </SectionContent>
          <div className="content-divider" />
          <SectionContent title="Setor" accordion accordionDefaultDisplay={false}>
            <div className="col-15">
              <Checkbox label="Setor:">
                <Checkitem
                  label="Loja"
                  name="setorLoja"
                  checked={setorLoja}
                  onChange={this.handleInputChange}
                  tabindex={18}
                />
                <Checkitem
                  label="Pista"
                  name="setorPista"
                  checked={setorPista}
                  onChange={this.handleInputChange}
                  tabindex={18}
                />
                <Checkitem
                  label="Troca de óleo"
                  name="setorTrocaOleo"
                  checked={setorTrocaOleo}
                  onChange={this.handleInputChange}
                  tabindex={18}
                />
              </Checkbox>
            </div>
          </SectionContent>
          <div className="content-divider" />
          <SectionContent title="Representante Legal" accordion accordionDefaultDisplay={false}>
            <div className="row">

              <div className="col-1">
                <InputText
                  label="Nome"
                  name="Nome"
                  value={Nome}
                  onChange={this.handleInputChange}
                  tabindex={19}
                  maxlength="50"
                />
              </div>
            </div>
            <div className="row">

              <div className="col-5">
                <InputText
                  type="number"
                  label="CPF"
                  name="CPF"
                  value={CPF}
                  onChange={this.handleInputChange}
                  onBlur={this.verificaCPF}
                  format="###.###.###-##"
                  tabindex={20}
                />
              </div>

              <div className="col-5">
                <InputText
                  label="Cargo/Função"
                  name="FuncaoCargo"
                  value={FuncaoCargo}
                  onChange={this.handleInputChange}
                  tabindex={21}
                  maxlength="30"
                />
              </div>

            </div>
          </SectionContent>
          <div className="content-divider" />
          <SectionContent title="Informações Fiscais" accordion accordionDefaultDisplay={false}>
            <div className="row">
              <div className="col-5">
                <Select
                  label="Perfil SPED Fiscal"
                  name="perfilSpedFiscal"
                  value={perfilSpedFiscal}
                  onChange={this.handleInputChange}
                  options={[
                    { value: "1", label: "A" },
                    { value: "2", label: "B" },
                    { value: "3", label: "C" }]}
                  required
                  autofocus="true"
                  tabindex={22}
                  onBlur={this.defineRegimeTributario}
                />
              </div>
              <div className="col-5">
                <Select
                  label="Regime Tributário"
                  name="RegimenTributario"
                  value={RegimenTributario}
                  onChange={this.handleInputChange}
                  options={[
                    { value: "1", label: "Lucro presumido" },
                    { value: "2", label: "Lucro real" },
                    { value: "4", label: "Simples nacional" },
                    { value: "8", label: "Simples nacional - excesso sublimite" }]}
                  required
                  autofocus="true"
                  tabindex={23}
                  onBlur={this.validaRegimeTributario}
                />
              </div>
            </div>
            <div className="row">
              <div className="col-1">
                <Select
                  label="Contador"
                  name="CodigoContador"
                  value={CodigoContador}
                  onChange={this.handleInputChange}
                  options={listaContadores}
                  required
                  autofocus="true"
                  tabindex={24}
                />
              </div>
            </div>
          </SectionContent>
          <div className="content-divider" />
          <SectionContent title="CNAE" accordion accordionDefaultDisplay={false}>

            <TreeCNAE listaCNAE={this.state.cnae} handleCNAE={this.handleCNAE} />

          </SectionContent>

        </SectionContainer>

        <FormOptions
          handleSalvar={this.handleSalvar}
        />

        <Alert
          active={alertActive}
          type={alertType}
          title={alertTitle}
          subtitle={alertSubtitle}
          handleAction={this.handleAlertAction}
        />
      </>
    );
  }
}

Form = withRouter(Form);

class ScreenEmpresas extends Component {
  state = {
    estabelecimentos: [],
    estabelecimentosel: {}
  };

  async componentDidMount() {
    const { data: responseestabelecimentos } = await getEstabelecimentos();
    var estabelecimentos = responseestabelecimentos.result;

    this.setState({ estabelecimentos });

  }

  async componentDidUpdate(prevProps) {
    if (this.props.edit !== prevProps.edit && !this.props.edit) {
      const { data: responseestabelecimentos } = await getEstabelecimentos();
      var estabelecimentos = responseestabelecimentos.result;

      this.setState({ estabelecimentos });
    }
  }


  handleTableClick = (state, rowInfo, column, instance, e) => {
    if (rowInfo) { // se clicar numa linha vazia, não faz nada
      this.setState({ estabelecimentosel: rowInfo.original });
      this.props.history.push("/empresas/new");
    }
  }

  render() {
    const { edit } = this.props,
      { estabelecimentosel } = this.state;
    return (
      <main className="main">
        <section className="section-container">
          <SectionHeader
            title="Empresas"
            subtitle=""
            /*  <div className="section-header-search">
                    <InputText placeholder="Buscar" icone="icon-lx-search" />
                </div>
                    */
            right={
              <div className="button-container">
                {edit ? (
                  <>

                  </>
                ) : (
                    this.state.estabelecimentos.length === 1 ?
                      <>
                      </>
                      :
                      <Botao ic icon="icon-lx-plus" onClick={() => {
                        this.setState({ estabelecimentosel: {} });
                        this.props.history.push("/empresas/new")
                      }} />
                  )}
              </div>
            }
          />
          {edit ? (
            <Form
              estabelecimento={estabelecimentosel}
            />
          ) : (
              this.state.estabelecimentos.length === 1 ? <Form
                estabelecimento={this.state.estabelecimentos[0]}
              /> :
                <List
                  onClick={this.handleTableClick}
                  cols={[
                    {
                      accessor: "cnpj",
                      Header: "CNPJ",
                      width: 200,
                      filterable: false,
                      sortMethod: sortInt
                    },
                    {
                      accessor: "inscricaoEstadual",
                      Header: "Inscrição Estadual",
                      width: 200,
                      filterable: false,
                      sortMethod: sortInt
                    },
                    {
                      accessor: "razaoSocial",
                      Header: "Razão Social",
                      width: 420,
                      filterable: false
                    },
                    {
                      accessor: "inativo",
                      Header: "Ativo",
                      width: 100,
                      filterable: false,
                      Cell: ({ row }) => {
                        return (
                          <Botao
                            secondary={row.inativo}
                            ic
                            icon={row.inativo ? "icon-lx-close" : "icon-lx-check"}
                          />
                        );
                      }
                    }
                  ]}
                  rows={this.state.estabelecimentos}
                />
            )}
        </section>
      </main>
    );
  }
}

class TreeCNAE extends React.Component {

  constructor(props) {
    super(props);

    const cnaesEmpresa = this.props.listaCNAE;

    this.state = { cnaesEmpresa }

  };

  carregarCNAEEmpresa = () => {
    var listaCNAEEmpresa = [];
    var cnaeEmpresaClasse = {};
    var cnaeEmpresaGrupo = {};
    var cnaeEmpresaDivisao = {};
    var cnaeEmpresaSessao = {};
    var cnaeEmpresaSubclasse = {};

    for (let i = 0; i < this.state.cnaesEmpresa.length; i++) {
      const cnaeItem = this.state.cnaesEmpresa[i];
      let cnaeEmpresa = {
        subclasse: "",
        classe: "",
        grupo: "",
        divisao: "",
        sessao: "",
        primario: "",
        codCnae: "",
        cnaeCodigo: "",
        cnaeDescricao: ""
      }

      var listaCNAEResult = this.state.listaCNAE;

      cnaeEmpresaSubclasse = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeItem.codCnae));
      cnaeEmpresa.subclasse = cnaeEmpresaSubclasse[0].codigo + " - " + cnaeEmpresaSubclasse[0].descricao;

      cnaeEmpresaClasse = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaSubclasse[0].idPai));
      cnaeEmpresa.classe = cnaeEmpresaClasse[0].codigo + " - " + cnaeEmpresaClasse[0].descricao;

      cnaeEmpresaGrupo = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaClasse[0].idPai));
      cnaeEmpresa.grupo = cnaeEmpresaGrupo[0].codigo + " - " + cnaeEmpresaGrupo[0].descricao;

      cnaeEmpresaDivisao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaGrupo[0].idPai));
      cnaeEmpresa.divisao = cnaeEmpresaDivisao[0].codigo + " - " + cnaeEmpresaDivisao[0].descricao;

      cnaeEmpresaSessao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaDivisao[0].idPai));
      cnaeEmpresa.sessao = cnaeEmpresaSessao[0].codigo + " - " + cnaeEmpresaSessao[0].descricao;

      cnaeEmpresa.primario = cnaeItem.primario;

      cnaeEmpresa.codCnae = cnaeItem.codCnae;
      cnaeEmpresa.cnaeCodigo = cnaeEmpresaSubclasse[0].codigo;
      cnaeEmpresa.cnaeDescricao = cnaeEmpresaSubclasse[0].descricao;

      listaCNAEEmpresa.push(cnaeEmpresa);

      this.setState({ listaCNAEEmpresa });

    }
  }

  incluirCNAEQuadro = () => {

  }

  tratarArvore = (listaCNAE) => {
    var children = [];
    var arvore = [];
    let listaCNAERaizes = ((listaCNAE === null) || (listaCNAE === undefined)) ? [] : listaCNAE.filter(lc => lc.idPai === 0);
    for (let i = 0; i < listaCNAERaizes.length; i++) {
      var itemArvore = {
        title: "",
        key: 0,
        children: []
      };
      const raiz = listaCNAERaizes[i];
      let listaCNAEGalhos = ((listaCNAE === null) || (listaCNAE === undefined)) ? [] : listaCNAE.filter(lc => lc.idPai === raiz.id);
      for (let j = 0; j < listaCNAEGalhos.length; j++) {
        const galho = listaCNAEGalhos[j];
        var itemGalho = {
          title: galho.codigo + " - " + galho.descricao,
          key: galho.id,
          children: []
        };
        itemArvore.children.push(this.tratarGalhos(itemGalho));
      }
      itemArvore.title = raiz.codigo + " - " + raiz.descricao;
      itemArvore.key = raiz.id;

      arvore.push(itemArvore);
    }
    this.setState({ listaCNAETratada: arvore })
  };

  tratarGalhos = (raiz) => {
    var listaCNAEOriginal = this.state.listaCNAE;

    //verifica se o elemento tem filhos
    let listaCNAERaizes = ((listaCNAEOriginal === null) || (listaCNAEOriginal === undefined)) ? [] : listaCNAEOriginal.filter(lc => lc.idPai === raiz.key);
    if (listaCNAERaizes.length > 0) {

      for (let k = 0; k < listaCNAERaizes.length; k++) {
        const galho = listaCNAERaizes[k];
        var itemGalho = {
          title: galho.codigo + " - " + galho.descricao,
          key: galho.id,
          children: []
        };
        raiz.children.push(this.tratarGalhos(itemGalho));
      }
    }
    return raiz;

  };

  state = {
    selectedKeys: [],
    expandedKeys: [],
    cnaeSelect: ""
  };

  async componentDidMount() {
    this.getContainer();

    const { data: listaCNAEResponse } = await listarCNAEs();
    var listaCNAEResult = listaCNAEResponse.result;
    var listaCNAEResult = listaCNAEResponse.result;

    this.setState({ listaCNAE: listaCNAEResult });

    this.tratarArvore(this.state.listaCNAE);

    this.carregarCNAEEmpresa();
  }
  componentWillUnmount() {
    if (this.cmContainer) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      document.body.removeChild(this.cmContainer);
      this.cmContainer = null;
    }
  }
  getContainer() {
    if (!this.cmContainer) {
      this.cmContainer = document.createElement("div");
      document.body.appendChild(this.cmContainer);
    }
    return this.cmContainer;
  }
  onSelect = (
    selectedKeys,
    e /*:{selected: bool, selectedNodes, node, event, nativeEvent}*/
  ) => {


    let { expandedKeys } = this.state;

    const key = selectedKeys[0];

    var listaCNAEResult = this.state.listaCNAE;

    let listaCNAEGalhos = ((listaCNAEResult === null) || (listaCNAEResult === undefined)) ? [] : listaCNAEResult.filter(lc => lc.idPai === parseInt(key));

    if (listaCNAEGalhos.length === 0) {

      var listaCNAEEmpresa = this.state.listaCNAEEmpresa !== undefined ? this.state.listaCNAEEmpresa : [];
      var cnaeEmpresaClasse = {};
      var cnaeEmpresaGrupo = {};
      var cnaeEmpresaDivisao = {};
      var cnaeEmpresaSessao = {};
      var cnaeEmpresaSubclasse = {};


      var cnaeExistente = false;

      for (let i = 0; i < listaCNAEEmpresa.length; i++) {
        const element = listaCNAEEmpresa[i];
        if (parseInt(element.codCnae) === parseInt(key))
          cnaeExistente = true;
      }

      if (!cnaeExistente) {

        let cnaeEmpresa = {
          subclasse: "",
          classe: "",
          grupo: "",
          divisao: "",
          sessao: "",
          primario: "",
          codCnae: "",
          cnaeCodigo: "",
          cnaeDescricao: ""
        }

        cnaeEmpresaSubclasse = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(key));
        cnaeEmpresa.subclasse = cnaeEmpresaSubclasse[0].codigo + " - " + cnaeEmpresaSubclasse[0].descricao;

        cnaeEmpresaClasse = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaSubclasse[0].idPai));
        cnaeEmpresa.classe = cnaeEmpresaClasse[0].codigo + " - " + cnaeEmpresaClasse[0].descricao;

        cnaeEmpresaGrupo = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaClasse[0].idPai));
        cnaeEmpresa.grupo = cnaeEmpresaGrupo[0].codigo + " - " + cnaeEmpresaGrupo[0].descricao;

        cnaeEmpresaDivisao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaGrupo[0].idPai));
        cnaeEmpresa.divisao = cnaeEmpresaDivisao[0].codigo + " - " + cnaeEmpresaDivisao[0].descricao;

        cnaeEmpresaSessao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaDivisao[0].idPai));
        cnaeEmpresa.sessao = cnaeEmpresaSessao[0].codigo + " - " + cnaeEmpresaSessao[0].descricao;

        cnaeEmpresa.primario = false;

        cnaeEmpresa.codCnae = key;
        cnaeEmpresa.cnaeCodigo = cnaeEmpresaSubclasse[0].codigo;
        cnaeEmpresa.cnaeDescricao = cnaeEmpresaSubclasse[0].descricao;

        listaCNAEEmpresa.push(cnaeEmpresa);

        this.setState({ listaCNAEEmpresa })

        this.props.handleCNAE(listaCNAEEmpresa);
      }
    }

    if (!expandedKeys)
      expandedKeys = [];

    if (expandedKeys.includes(key)) {
      this.setState({ expandedKeys: expandedKeys.filter(k => k !== key) });
    } else {
      this.setState({ expandedKeys: [...expandedKeys, key] });
    }
  };
  onExpand = (expandedKeys, e) => {
    console.log(expandedKeys);
    this.setState({ expandedKeys });
  };

  newItem = () => {
    console.log("new item");
  };

  changeItem = () => {
    console.log("change item");
  };

  deleteItem = () => {
    console.log("delete item");
  };

  renderCm(info) {
    if (this.toolTip) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      this.toolTip = null;
    }
    this.toolTip = (
      <Tooltip
        trigger="click"
        placement="bottomRight"
        prefixCls="rc-tree-contextmenu"
        defaultVisible
        overlay={
          <ContextMenu
            info={info}
            newItem={this.newItem}
            changeItem={this.changeItem}
            deleteItem={this.deleteItem}
          />
        }
      >
        <span />
      </Tooltip>
    );

    const container = this.getContainer();
    Object.assign(this.cmContainer.style, {
      position: "absolute",
      left: `${info.event.pageX}px`,
      top: `${info.event.pageY}px`
    });

    ReactDOM.render(this.toolTip, container);
  }

  buscarCodigoCNAE = (codigo) => {
    /*let cnaeEmpresaSubclasse = listaCNAEResult.filter(c => parseInt(c.codigo) === parseInt(key));
    cnaeEmpresa.subclasse = cnaeEmpresaSubclasse[0].codigo + " - " + cnaeEmpresaSubclasse[0].descricao;

    cnaeEmpresaClasse = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaSubclasse[0].idPai));
    cnaeEmpresa.classe = cnaeEmpresaClasse[0].codigo + " - " + cnaeEmpresaClasse[0].descricao;

    cnaeEmpresaGrupo = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaClasse[0].idPai));
    cnaeEmpresa.grupo = cnaeEmpresaGrupo[0].codigo + " - " + cnaeEmpresaGrupo[0].descricao;

    cnaeEmpresaDivisao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaGrupo[0].idPai));
    cnaeEmpresa.divisao = cnaeEmpresaDivisao[0].codigo + " - " + cnaeEmpresaDivisao[0].descricao;

    cnaeEmpresaSessao = listaCNAEResult.filter(c => parseInt(c.id) === parseInt(cnaeEmpresaDivisao[0].idPai));
    cnaeEmpresa.sessao = cnaeEmpresaSessao[0].codigo + " - " + cnaeEmpresaSessao[0].descricao;*/
  }

  handleSelectChange = (e) => {
    console.log('abrindo ' + e.target.value);
    let keys = this.buscarCodigoCNAE(e.target.value);
    this.setState({ expandedKeys: keys });
  }

  eliminarCnae = (e) => {
    var listaCNAEAtual = this.state.listaCNAEEmpresa;
    var listaCNAENovo = [];
    var nome = e.currentTarget.className;

    for (let i = 0; i < listaCNAEAtual.length; i++) {
      const element = listaCNAEAtual[i];
      if ((nome.indexOf(element.subclasse) === -1))
        listaCNAENovo.push(element);
    }

    this.setState({ listaCNAEEmpresa: listaCNAENovo })
    this.props.handleCNAE(listaCNAENovo);

  }

  handleCNAEClick = (e) => {
    var listaCNAEAtual = this.state.listaCNAEEmpresa;

    var nome = e.target.name;
    var checked = e.target.checked;

    for (let i = 0; i < listaCNAEAtual.length; i++) {
      const element = listaCNAEAtual[i];
      if (element.subclasse === nome)
        listaCNAEAtual[i].primario = !listaCNAEAtual[i].primario;
      else if (checked)
        listaCNAEAtual[i].primario = false;
    }

    this.setState({ listaCNAEEmpresa: listaCNAEAtual })
    this.props.handleCNAE(this.state.listaCNAEEmpresa);

  }

  render() {
    return (
      <>
        {/* <div>
          <InputText
            label="Selecionar CNAE"
            value={this.state.cnaeSelect}
            name="cnaeSelect"
            onBlur={this.handleSelectChange}
            tabindex={1}
          />
       </div>*/}
        <div>
          <Tree
            defaultExpandParent
            showLine
            selectedKeys={[]}
            expandedKeys={this.state.expandedKeys}
            onExpand={this.onExpand}
            showIcon={false}
            onSelect={this.onSelect}
            treeData={this.state.listaCNAETratada}
          />
        </div>
        <div className="table-ctn">
          <ReactTable
            data={this.state.listaCNAEEmpresa}
            columns={[
              {
                accessor: "primario",
                Header: "Primário",
                width: 75,
                filterable: false,
                Cell: ({ row }) => {
                  return (
                    <Checkbox label="">
                      <Checkitem
                        label=""
                        name={row.subclasse}
                        checked={row.primario}
                        onChange={this.handleCNAEClick}
                      />
                    </Checkbox>
                  );
                }
              },
              {
                accessor: "sessao",
                Header: "Sessão",
                style: { 'white-space': 'unset' },
                width: 150,
                filterable: false,
              },
              {
                accessor: "divisao",
                Header: "Divisão",
                style: { 'white-space': 'unset' },
                width: 150,
                filterable: false,
              },
              {
                accessor: "grupo",
                Header: "Grupo",
                style: { 'white-space': 'unset' },
                width: 150,
                filterable: false,
              },
              {
                accessor: "classe",
                Header: "Classe",
                style: { 'white-space': 'unset' },
                width: 150,
                filterable: false,
              },
              {
                accessor: "subclasse",
                Header: "Subclasse",
                style: { 'white-space': 'unset' },
                width: 150,
                filterable: false,
              },
              {
                accessor: "acao",
                Header: "Excluir",
                width: 75,
                filterable: false,
                Cell: ({ row }) => {
                  return (
                    <Botao
                      className={row.subclasse}
                      icon={"icon-lx-trash"}
                      onClick={this.eliminarCnae}
                    />
                  );
                }
              }
            ]}
            getTdProps={(state, rowInfo, column, instance) => {
              return {
                onClick: (e, handleOriginal) => {
                  if (this.props.onClick) {
                    this.props.onClick(state, rowInfo, column, instance, e);
                  }

                  if (handleOriginal) {
                    handleOriginal();
                  }
                }
              };
            }}
            previousText="Anterior"
            nextText="Próximo"
            loadingText="Carregando registros..."
            noDataText="Sem registros para exibir"
            pageText="Página"
            ofText="de"
            rowsText="registros"
          />
        </div>
      </>
    );
  }
}

class ContextMenu extends Component {
  render() {
    const {
      node,
      node: {
        props: { pos }
      }
    } = this.props.info;
    const { newItem, changeItem, deleteItem } = this.props;
    return (
      <div>
        {!node.isLeaf() && (
          <h4 onClick={() => newItem(node)}>Incluir sub-item</h4>
        )}
        {pos !== "0-0" && (
          <h4 onClick={() => changeItem(node)}>Alterar item</h4>
        )}
        {pos !== "0-0" && (
          <h4 onClick={() => deleteItem(node)}>Excluir item</h4>
        )}
      </div>
    );
  }
}

ScreenEmpresas = withRouter(ScreenEmpresas);
export { ScreenEmpresas };
