import React, { Component } from "react";
import { Botao } from "./../../botoes/Botao";
import {
  InputText,
  InputDate,
  InputTime,
  Checkbox,
  Checkitem,
  Select,
  FormOptions,
  handleInputChange,
  formatPhoneNumber
} from "./../../formulario/Formulario";
import { List } from "./../../formulario/List";
import { SectionHeader } from "./../../section/Header";
import { SectionContainer, SectionContent } from "./../../section/Content";
import { TabHead, TabPanel } from "./../../tabs/Tabs";
import { Modal, ModalBody, ModalHeader, ModalFooter } from "../../modal/Modal";

import { Link } from "react-router-dom";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.handleInputChange = handleInputChange.bind(this);
    this.state = {
      showTab: 0,
      inscr: [],
      cnpj: "",
      fone: "",
      options: [
        { label: "teste", value: 1 },
        { label: "dois", value: 2 },
        { label: "três", value: 3 }
      ],
      dataAtivacao: "2017-02-12T23:00:00",
      time: "",
      logradouro: "",
      numero: "",
      bairro: "",
      displayInfoCompl: false,
    };
  }

  handleSalvar = () => {
    // verifica pelo name se o valor no state está correto e caso seja invalido
    // encontra o elemento (DOM) e chama o metodo .focus() para receber o focus.
    // A verificacao do state pode ser feito de outras formas, nao precisa utilizar array e .some

    // Caso o Inspetor do navegador estiver aberto, pode ser que .focus nao funciona corretamente,
    // pois o Inspetor pode não repassar o foco.

    const required_fields = ["logradouro", "numero", "bairro"];

    // .some itera em todos os elementos e para no primeiro que retornar true, retornando true,
    // ou retorna false se iterou até o fim e todas retornaram false. Assim caso seja retornado true é pq deve pelo menos
    // campo obrigatorio nao preenchido...
    const invalid = required_fields.some(field => {
      const value = this.state[field];
      if (!value || value === "") {
        // document.getElementById é uma função do proprio navegador (DOM) e retorna um objeto DOM e nao um componente React
        const node = document.getElementById(field);
        if (node) {
          node.focus();
          return true;
        }
      }
      return false;
    });

    if (invalid) {
      this.setState({displayInfoCompl: true});
      alert("preencher campo!");
    } else {
      alert("sucesso");
    }
  };

  render() {
    const {
      showTab,
      inscr,
      options,
      cnpj,
      fone,
      dataAtivacao,
      time,
      logradouro,
      numero,
      bairro,
      displayInfoCompl
    } = this.state;
    return (
      <>
        <SectionContainer>
          <SectionContent title="Identificação" accordion onChange={(open) => console.log(open? "abriu": "fechou")}>
            <div className="row">
              <div className="col-4">
                <InputText
                  label="Código:"
                  icone="icon-lx-search"
                  onIconeClick={() => {
                    alert("pesquisando...");
                  }}
                />
              </div>
              <div className="col-4">
                <InputText label="Nome Reduzido:" />
              </div>
              <div className="col-1">
                <InputText label="Nome" />
              </div>
            </div>
            <div className="row">
              <div className="col-1">
                <InputText label="Razão Social:" />
              </div>
            </div>
          </SectionContent>
          <div className="content-divider" />

          <SectionContent
            title="Informações complementares"
            accordion
            accordionDisplay={displayInfoCompl}
            onChange={() => this.setState({displayInfoCompl: !displayInfoCompl})}
          >
            <TabHead
              indexShow={showTab}
              handleChange={showTab => this.setState({ showTab })}
            >
              <span>Dados Principais</span>
              <span>Contas</span>
              <span>Departamento</span>
              <span>Nota Fiscal</span>
              <span>LMC</span>
              <span>Configurações</span>
              <span>Política de Preço</span>
              <span>Fiscal</span>
            </TabHead>

            <TabPanel indexShow={showTab}>
              <div>
                <div className="row">
                  <div className="col-1">
                    <InputText
                      label="Logradouro:"
                      name="logradouro"
                      value={logradouro}
                      onChange={this.handleInputChange}
                    />
                  </div>
                  <div className="col-4">
                    <InputText
                      label="Número:"
                      name="numero"
                      value={numero}
                      onChange={this.handleInputChange}
                    />
                  </div>
                  <div className="col-4">
                    <InputText
                      label="Bairro:"
                      name="bairro"
                      value={bairro}
                      onChange={this.handleInputChange}
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-4">
                    <InputText label="Complemento:" name="complemento" />
                  </div>
                  <div className="col-4">
                    <div className="row">
                      <div className="col-1">
                        <InputText label="Uf:" />
                      </div>
                      <div className="col-1">
                        <InputText label="Município:" />
                      </div>
                    </div>
                  </div>
                  <div className="col-4">
                    <InputText label="País:" />
                  </div>
                  <div className="col-4">
                    <InputDate
                      label="Data início atv.:"
                      value={dataAtivacao}
                      name="dataAtivacao"
                      onChange={this.handleInputChange}
                    />
                  </div>
                </div>
                <div className="row">
                  <div className="col-4">
                    <InputText label="CNAE:" />
                  </div>
                  <div className="col-4">
                    <InputText
                      type="number"
                      label="CNPJ:"
                      name="cnpj"
                      value={cnpj}
                      format="##.###.###/####-##"
                      onChange={this.handleInputChange}
                      help="Apenas números"
                    />
                  </div>
                  <div className="col-4">
                    <InputText
                      type="number"
                      label="Telefone:"
                      name="fone"
                      value={fone}
                      format={formatPhoneNumber}
                      onChange={this.handleInputChange}
                    />
                  </div>
                  <div className="col-4">
                    <InputText label="Fax:" />
                  </div>
                </div>
                <div className="row">
                  <div className="col-4">
                    <Select
                      multi
                      label="Insc. Municipal:"
                      name="inscr"
                      value={inscr}
                      options={options}
                      onChange={this.handleInputChange}
                    />
                  </div>
                  <div className="col-4">
                    <InputText label="Insc. Estadual:" />
                  </div>
                  <div className="col-1">
                    <InputText label="E-mail:" />
                  </div>
                </div>
                <div className="row">
                  <div className="col-1">
                    <Checkbox label="Website">
                      <Checkitem label="Atacadista" />
                      <Checkitem label="Atacadista" />
                    </Checkbox>
                  </div>
                </div>
              </div>
              <div>
                <div className="row">
                  <div className="col-1">
                    <div className="form-input">
                      <input type="input" className="input date" required />
                      <label className="input-label">Date:</label>
                    </div>
                  </div>
                  <div className="col-1">
                    <div className="form-input">
                      <InputTime
                        className="input time"
                        required
                        label="Hora:"
                        value={time}
                        name="time"
                        showSeconds
                      />
                    </div>
                  </div>
                  <div className="col-1">
                    <div className="form-input">
                      <input type="input" className="input money" required />
                      <label className="input-label">Money:</label>
                    </div>
                  </div>
                  <div className="col-1">
                    <div className="form-input">
                      <input type="input" className="input datetime" required />
                      <label className="input-label">Date time:</label>
                    </div>
                  </div>
                </div>
              </div>
            </TabPanel>
          </SectionContent>
        </SectionContainer>

        <FormOptions handleSalvar={this.handleSalvar} />
      </>
    );
  }
}

export class ScreenEmpresa extends Component {
  state = {
    empresas: [],
    modalFilter: false,
    // cada registro precisa de um ID unico para o onChange alterar o valor correto no state,
    // entao os novos registros sao criado com id negativo para indicar que nao sao ID vindos
    // do bancos de dados. Precisa tratar para quando enviar para o backend, nao mandar o ID.
    // idNovo funciona como uma sequence para o proxima ID a ser gerado
    idNovo: -1
  };

  createRows = () => {
    let rows = [];
    for (let i = 1; i < 8; i++) {
      rows.push({
        id: `${i}`,
        cnpj: `00.000.000/${Number.parseInt(i)}-00`,
        nome: ``,
        action: "Editar"
      });
    }

    return rows;
  };

  componentDidMount() {
    this.setState({ empresas: this.createRows() });
  }

  openFilter = () => {
    this.setState({ modalFilter: true });
  };

  handleCloseModal = (action, password) => {
    alert(`${action} ${password}`);
    this.setState({ modalFilter: false });
  };

  handleAdicionar = () => {
    const { empresas, idNovo } = this.state;

    this.setState({
      empresas: [...empresas, { id: idNovo, cnpj: "", nome: "", action: "" }],
      idNovo: idNovo - 1
    });
  };

  handleChangeGrid = (value, name, id) => {
    const empresas = this.state.empresas.map(e => {
      if (e.id === id) {
        return { ...e, [name]: value };
      } else {
        return e;
      }
    });
    this.setState({ empresas });
  };

  render() {
    const { edit, idEmpresa } = this.props;
    const { modalFilter } = this.state;
    return (
      <main className="main">
        <section className="section-container">
          <SectionHeader
            title="Empresa"
            subtitle="Empresa subtitulo exemplo"
            right={
              <div className="button-container">
                {edit ? (
                  <>
                    <Botao ic icon="icon-lx-trash" />
                    <Botao secondary icon="icon-lx-check" title="Salvar" />
                  </>
                ) : (
                  <>
                    <Botao
                      title="Adicionar"
                      icon="icon-lx-plus"
                      onClick={this.handleAdicionar}
                    />
                    <Botao ic icon="icon-lx-filter" onClick={this.openFilter} />
                    <Link to="/empresa/new">
                      <Botao ic icon="icon-lx-plus" />
                    </Link>
                  </>
                )}
              </div>
            }
          />
          {edit ? (
            <Form id={idEmpresa} />
          ) : (
            <>
              <List
                onClick={(...args) => console.log("Exemplo: ", args)}
                rows={this.state.empresas}
                cols={[
                  {
                    accessor: "id",
                    Header: "Código",
                    Cell: ({row}) => <div>{row.id > 0? row.id: "-"}</div>
                  },
                  {
                    accessor: "cnpj",
                    Header: "CNPJ",
                    Cell: props => {
                      return (
                        <InputText
                          className="input"
                          value={props.row.cnpj}
                          name="teste"
                          onChange={event =>
                            this.handleChangeGrid(
                              event.target.value,
                              "cnpj",
                              props.row.id
                            )
                          }
                        />
                      );
                    }
                  },
                  {
                    accessor: "nome",
                    Header: "Nome",
                    Cell: props => {
                      return (
                        <InputDate
                          className="input"
                          value={props.row.nome}
                          onChange={({ date }) =>
                            this.handleChangeGrid(date, "nome", props.row.id)
                          }
                        />
                      );
                    }
                  },
                  {
                    accessor: "action",
                    Header: "Ações",
                    sortable: false,
                    Cell: ({ row }) => {
                      return (
                        <div className="row">
                          <Botao ic icon={"icon-lx-edit"} />
                          <Botao ic secondary icon={"icon-lx-trash"} />
                        </div>
                      );
                    }
                  }
                ]}
              />

              <ModalFilter
                active={modalFilter}
                handleCloseModal={this.handleCloseModal}
              />
            </>
          )}
        </section>
      </main>
    );
  }
}

export class ModalFilter extends Component {
  constructor(props) {
    super(props);
    this.handleInputChange = handleInputChange.bind(this);
    this.state = { password: "", time: "" };
  }

  render() {
    const { active, handleCloseModal } = this.props;
    const { password, time } = this.state;

    return (
      <div>
        <Modal
          className={`${active ? "active" : null} modal-filter`}
          onClose={() => handleCloseModal(false)}
        >
          <ModalHeader title="Pesquisar Cliente" subtitle="" />

          <ModalBody>
            {/* Conteúdo principal */}
            <SectionContent title="Pesquisar">
              <div className="row">
                <div className="col-1">
                  <div className="form-input">
                    <input
                      type="input"
                      className="input"
                      name="password"
                      value={password}
                      onChange={this.handleInputChange}
                      required
                    />
                    <label className="input-label">Nome:</label>
                  </div>
                </div>
                <div className="col-1">
                  <div className="form-input">
                    <input
                      type="input"
                      className="input"
                      name="password"
                      value={password}
                      onChange={this.handleInputChange}
                      required
                    />
                    <label className="input-label">Apelido:</label>
                  </div>
                </div>
                <div className="col-1">
                  <div className="form-input">
                    <input
                      type="input"
                      className="input"
                      name="password"
                      value={password}
                      onChange={this.handleInputChange}
                      required
                    />
                    <label className="input-label">CNPJ/CPF:</label>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-1">
                  <div className="form-input">
                    <InputTime
                      className="input time"
                      required
                      label="Hora:"
                      value={time}
                      name="time"
                      showSeconds
                      onChange={this.handleInputChange}
                    />
                  </div>
                </div>
                <div className="col-1">
                  <div className="form-input">
                    <input
                      type="input"
                      className="input"
                      name="password"
                      value={password}
                      onChange={this.handleInputChange}
                      required
                    />
                    <label className="input-label">Código:</label>
                  </div>
                </div>
                <div className="col-1">
                  <div className="form-input">
                    <Select options={["Todas", "Física", "Jurídica"]} />
                    <label className="input-label">Código:</label>
                  </div>
                </div>
              </div>
            </SectionContent>
          </ModalBody>

          <ModalFooter>
            <Botao
              secondary
              icon="icon-lx-close"
              title={"Cancelar"}
              onClick={() => {
                handleCloseModal(false, password);
              }}
            />
            <Botao
              secondary
              icon="icon-lx-trash"
              title={"Limpar"}
              onClick={() => {
                handleCloseModal(false, password);
              }}
            />
            <Botao
              icon="icon-lx-check"
              title={"Salvar"}
              onClick={() => {
                handleCloseModal(true, password);
              }}
            />
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}
