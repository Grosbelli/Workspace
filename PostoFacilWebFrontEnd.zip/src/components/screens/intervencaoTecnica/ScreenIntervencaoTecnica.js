import React, { Component } from "react";
import { Botao } from "../../botoes/Botao";
import "react-dates";
import {
    InputText,
    Select,
    FormOptions,
    handleInputChange,
    InputDate
} from "../../formulario/Formulario";
import { List } from "../../formulario/List";
import { SectionHeader } from "../../section/Header";
import { SectionContainer, SectionContent } from "../../section/Content";
import { Alert } from "../../alert/Alert";

import { withRouter } from "react-router-dom";

import {
    getIntervencaoTecnica,
    alterarIntervencaoTecnica,
    excluirIntervencaoTecnica
} from "../../../services/IntervencaoTecnica";

import {
    toFloatFormattedDisplay, validaCPF
} from "../../../utils/Utils";

import moment from "moment";


/*import {
    getFornecedores
} from "../../../services/Fornecedor";*/


class Form extends React.Component {
    constructor(props) {
        super(props);
        this.handleInputChange = handleInputChange.bind(this);
        this.handleBlur = this.handleBlur.bind(this);

        const {
            codigoEstabelecimento = "1",
            codigoIntervencaoTecnica = null,
            dataIntervencao = "",
            codigoTanque = null,
            codigoBico = null,
            codigoPessoa = null,
            encerranteInicial = "",
            encerranteFinal = "",
            cpfTecnico = "",
            nomeTecnico = "",
            lacresRemovidos = "",
            lacresNovos = "",
            motivo = "",
            rowVersion = null,

            horaInterv = "",
            dataInterv = ""
        } = this.props.intervencaoTecnica;

        this.state = {
            codigoEstabelecimento,
            codigoIntervencaoTecnica,
            dataIntervencao,
            dataInterv: moment(dataIntervencao),
            horaInterv: moment(dataIntervencao).format("HH:mm:ss"),
            codigoTanque,
            codigoBico,
            codigoPessoa,
            encerranteInicial,
            encerranteFinal,
            cpfTecnico,
            nomeTecnico,
            lacresRemovidos,
            lacresNovos,
            motivo,
            rowVersion,

            alertActive: false, // se o alert deve ser apresentado
            alertType: "", // tipo de alert (sucesso, erro...)
            alertTitle: "", // titulo do alert
            alertSubtitle: "", // subtitulo/mensagem do alert

            intervencoesExistentes: []
        };
    }

     /* combo para fornecedores
    async componentDidMount() {
        const { data: fornecedores } = await getfornecedores(1);
        this.setState({
            fornecedores: fornecedores.map(forn => {
                return {
                    label: forn.descricao,
                    value: forn.codigo
                }
            })
        });
    } */

    handleAlertAction = async (resp) => {
        const { alertType,
            codigoEstabelecimento,
            codigoIntervencaoTecnica } = this.state;

        this.setState({
            alertActive: false,
            alertType: "",
            alertTitle: "",
            alertSubtitle: ""
        });

        switch (alertType) {
            case "success":
                this.props.history.push("/intervencaoTecnica/");
                break;

            case "question":
                if (resp) {
                    try {
                        await excluirIntervencaoTecnica(codigoEstabelecimento, codigoIntervencaoTecnica);
                        //sucesso
                        this.showInfo("Intervenção técnica excluída com sucesso!");
                    } catch (err) {
                        // falha
                        this.showError(err.response.data.message);
                    }
                }
                break;

            case "cancel":
                if (resp) {
                    this.props.history.push("/intervencaoTecnica/");
                }
                break;


            default:
                break;
        }
    };


    showError = (message) => {
        this.setState({
            alertActive: true,
            alertType: "error",
            alertTitle: "Erro",
            alertSubtitle: message
        });
    }

    showInfo = (message) => {
        this.setState({
            alertActive: true,
            alertType: "success",
            alertTitle: "Intervenção técnica",
            alertSubtitle: message
        });
    }

    handleSalvar = async () => {
        const {
            codigoEstabelecimento,
            codigoIntervencaoTecnica,
            dataIntervencao,
            codigoTanque,
            codigoBico,
            codigoPessoa,
            encerranteInicial,
            encerranteFinal,
            cpfTecnico,
            nomeTecnico,
            lacresRemovidos,
            lacresNovos,
            motivo,
            rowVersion,

            dataInterv,
            horaInterv
        } = this.state;

        debugger;    
        const [action, params] =
            codigoIntervencaoTecnica !== null
                ? [
                    alterarIntervencaoTecnica,
                    [
                        codigoEstabelecimento,
                        codigoIntervencaoTecnica,
                        moment(dataInterv).format("YYYY-MM-DD") + "T" + moment(horaInterv).format("HH:mm:ss"),
                        codigoTanque,
                        codigoBico,
                        codigoPessoa,
                        encerranteInicial,
                        encerranteFinal,
                        cpfTecnico,
                        nomeTecnico,
                        lacresRemovidos,
                        lacresNovos,
                        motivo,
                        rowVersion
                    ]
                ]
                : [
                    /***** Caso tenha um incluir futuramente 
                    incluirIntervencaoTecnica,
                    [
                        codigoEstabelecimento,
                        codigoIntervencaoTecnica,
                        dataIntervencao,
                        codigoTanque,
                        codigoBico,
                        codigoPessoa,
                        encerranteInicial,
                        encerranteFinal,
                        cpfTecnico,
                        nomeTecnico,
                        lacresRemovidos,
                        lacresNovos,
                        motivo
                    ]
                    */
                ];     
            debugger;   

        let temErros = this.verificaIntervencaoTecnica();

        if (!temErros) {
            temErros = this.verificaIntervencaoExistente(this.codigoIntervencaoTecnica);
        }

        if (!temErros) {

            try {
                const resp = await action(...params);
                this.setState({
                    alertActive: true,
                    alertType: "success",
                    alertTitle: "Intervenção técnica",
                    alertSubtitle: `Intervenção técnica  ${codigoIntervencaoTecnica === null ? "cadastrada" : "alterada"} com sucesso!`
                });
            } catch (err) {
                this.setState({
                    alertActive: true,
                    alertType: "error",
                    alertTitle: "Erro",
                    alertSubtitle: err.response.data.message
                });
            }
        }
    };

    handleExcluir = () => {
        this.setState({
            alertActive: true,
            alertType: "question",
            alertTitle: "Intervenção técnica",
            alertSubtitle: "Deseja excluir?"
        });
    }

    handleCancelar = () => {
        this.setState({
            alertActive: true,
            alertType: "cancel",
            alertTitle: "Intervenção técnica",
            alertSubtitle: "Deseja realmente cancelar a operação?"
        });
    }

    handleBlur = (event) => {
        debugger;
        let labelCampo = "";
        let campo = event.target;        
        if (this.state[campo.name] !== "") {
            switch (campo.name) {
                case "dataInterv":
                    if (!moment(this.state[campo.name], "YYYY-MM-DD").isValid()) {
                        labelCampo = "Data da intervenção inválida";     
                    }              
                    break;

                case "horaInterv":
                    if (!moment(this.state[campo.name], "HH:mm:ss").isValid()){
                        labelCampo = "Hora da intervenção inválida";
                    }
                    break;

                case "cpfTecnico":
                    if (!validaCPF(this.state[campo.name])){
                        labelCampo = "CPF do técnico inválido";
                    }
                    break;

                default:
                    break;
            }
            this.showError(labelCampo);
        }
    }

    verificaIntervencaoTecnica = () => {
        //verifica preenchimento dos campos
        if (this.state.dataInterv === "") {
              this.showError("É obrigatório informar a data da intervenção");
           return true;
        }        
        if (!moment(this.state.dataInterv, "YYYY-MM-DD").isValid()) {
            this.showError("Data da intervenção inválida");
            return true;
        }
        if (this.state.horaInterv === "") {
           this.showError("É obrigatório informar a hora da intervenção");
           return true;
        }
        if (!moment(this.state.dataInterv, "HH:mm:ss").isValid()) {
            this.showError("Hora da intervenção inválida");
            return true;
        }
        if (!this.state.codigoBico) {
            this.showError("É obrigatório informar o número do bico");
            return true;
        }
        if (!this.state.codigoPessoa) {
            //  this.showError("É obrigatório informar o fornecedor");
            //  return true;
        }
        if (this.state.encerranteInicial === "") {
            this.showError("É obrigatório informar o encerrante inicial");
            return true;
        }
        if (this.state.encerranteFinal === "") {
            this.showError("É obrigatório informar o encerrante final");
            return true;
        }
        if (this.state.cpfTecnico === "") {
            this.showError("É obrigatório informar o CPF do técnico");
            return true;
        }
        if (!validaCPF(this.state.cpfTecnico)) {
            this.showError("CPF do técnico inválido");
            return true;
        }
        if (this.state.lacresRemovidos === "") {
            this.showError("É obrigatório informar o lacre removido");
            return true;
        }
        if (this.state.lacresNovos === "") {
            this.showError("É obrigatório informar o lacre novo");
            return true;
        }
        if (this.state.motivo === "") {
            this.showError("É obrigatório informar o motivo");
            return true;
        }

        //verifica encerrante inicial maior que final
        if (parseFloat(this.state.encerranteFinal) > parseFloat(this.state.encerranteInicial)) {
            this.showError("O encerrante final não pode ser maior que a encerrante inicial");
            return true;
        }
    }

    verificaIntervencaoExistente = (valor) => {
        let existe = false;
        let lista = this.state.intervencoesExistentes;
        for (let i = 0; i < lista.length; i++) {
            const intervencao = lista[i];
            if (intervencao.codigoIntervencaoTecnica === valor) {
                existe = true;
            }
        }
        if (existe) {
            this.showError("Já existe intervenção técnica com os valores informados");
        }
        return existe;
    }


    render() {
        const {
            codigoIntervencaoTecnica,
            dataIntervencao,
            codigoTanque,
            codigoBico,
            codigoPessoa,
            encerranteInicial,
            encerranteFinal,
            cpfTecnico,
            nomeTecnico,
            lacresRemovidos,
            lacresNovos,
            motivo,
            fornecedores,

            dataInterv,
            horaInterv,

            alertActive,
            alertType,
            alertTitle,
            alertSubtitle
        } = this.state;
        return (
            <>
                <SectionContainer>
                    <SectionContent title="">
                        <div className="row">
                            <div className="col-5">
                                <InputDate
                                    label="Data da intervenção"
                                    name="dataInterv"
                                    value={(dataInterv ? moment(dataInterv) : moment())}
                                    onChange={this.handleInputChange}  
                                    onBlur={this.handleBlur}                                                                
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Hora da intervenção"
                                    value={horaInterv}
                                    name="horaInterv"
                                    type="number"
                                    format="##:##:##"
                                    required
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={2}
                                    text={moment(horaInterv).utc().format("HH:mm:ss")}
                                    onBlur={this.handleBlur}
                                //{toFormatHora(this.value)}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="N° seq. do bico"
                                    name="codigoBico"
                                    value={codigoBico}
                                    type="number"
                                    required
                                    disabled={codigoIntervencaoTecnica !== null}
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    maxlength="4"
                                    tabindex={3}
                                />
                            </div>
                            <div className="col-5">
                                <Select
                                    label="Fornecedores"
                                /* name="codigo"
                                 value={codigo}
                                 onChange={this.handleInputChange}
                                 options={fornecedores}
                                 required
                                 disabled={codigo === null}
                                 autofocus="true"
                                 tabindex={4}*/
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="Encerrante inicial"
                                    name="encerranteInicial"
                                    value={encerranteInicial}
                                    type="number"
                                    decimalScale={2}
                                    required
                                    disabled={codigoIntervencaoTecnica !== null}
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={5}
                                    maxlength="14"
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Encerrante final"
                                    name="encerranteFinal"
                                    value={encerranteFinal}
                                    type="number"
                                    decimalScale={2}
                                    required
                                    disabled={codigoIntervencaoTecnica !== null}
                                    onChange={this.handleInputChange}
                                    allowNegative={false}
                                    tabindex={6}
                                    maxlength="14"
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    type="number"
                                    label="CPF do técnico"
                                    name="cpfTecnico"
                                    value={cpfTecnico}
                                    format="###.###.###-##"
                                    onChange={this.handleInputChange}
                                    help="Apenas números"
                                    allowNegative={false}
                                    tabindex={7}
                                    onBlur={this.handleBlur}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Nome do técnico"
                                    name="nomeTecnico"
                                    value={nomeTecnico}
                                    type="text"
                                    maxlength="50"
                                    required
                                    onChange={this.handleInputChange}
                                    tabindex={8}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-5">
                                <InputText
                                    label="Lacres removidos"
                                    name="lacresRemovidos"
                                    value={lacresRemovidos}
                                    type="text"
                                    maxlength="50"
                                    required
                                    onChange={this.handleInputChange}
                                    tabindex={9}
                                />
                            </div>
                            <div className="col-5">
                                <InputText
                                    label="Lacres novos"
                                    name="lacresNovos"
                                    value={lacresNovos}
                                    type="text"
                                    maxlength="50"
                                    required
                                    onChange={this.handleInputChange}
                                    tabindex={10}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-1">
                                <InputText
                                    label="Motivo"
                                    name="motivo"
                                    value={motivo}
                                    type="text"
                                    maxlength="50"
                                    required
                                    onChange={this.handleInputChange}
                                    tabindex={11}
                                />
                            </div>
                        </div>
                    </SectionContent>
                </SectionContainer>

                <FormOptions
                    handleSalvar={this.handleSalvar}
                    handleExcluir={
                        codigoIntervencaoTecnica !== null ? this.handleExcluir : null}
                    handleCancelar={this.handleCancelar}

                />

                <Alert
                    active={alertActive}
                    type={alertType}
                    title={alertTitle}
                    subtitle={alertSubtitle}
                    handleAction={this.handleAlertAction}
                />
            </>
        );
    }
}

Form = withRouter(Form);

class ScreenIntervencaoTecnica extends Component {
    state = {
        intervencoesTecnicas: [],
        intervencoesTecnicasSel: {}
    };


    async doMount() {
        const { data: it } = await getIntervencaoTecnica(1);
        const intervencaoArray = it.result;
        this.setState({
            intervencoesTecnicas: intervencaoArray.map(interv => {
                return {
                    codigoEstabelecimento: interv.codigoEstabelecimento,
                    codigoIntervencaoTecnica: interv.codigoIntervencaoTecnica,
                    dataIntervencao: interv.dataIntervencao,
                    codigoTanque: interv.codigoTanque,
                    codigoBico: interv.codigoBico,
                    codigoPessoa: interv.codigoPessoa,
                    encerranteInicial: interv.encerranteInicial,
                    encerranteFinal: interv.encerranteFinal,
                    cpfTecnico: interv.cpfTecnico,
                    nomeTecnico: interv.nomeTecnico,
                    lacresRemovidos: interv.lacresRemovidos,
                    lacresNovos: interv.lacresNovos,
                    motivo: interv.motivo,
                    rowVersion: interv.rowVersion
                }
            }
            )
        }
        );
    }

    async componentDidMount() {
        this.doMount();
    }

    async componentDidUpdate(prevProps) {
        if (this.props.edit !== prevProps.edit && !this.props.edit) {
            this.doMount();
        }
    }

    handleTableClick = (state, rowInfo, column, instance, e) => {
        if (rowInfo) { // se clicar numa linha vazia, não faz nada
            this.setState({ intervencoesTecnicasSel: rowInfo.original });
            this.props.history.push("/intervencaoTecnica/new");
        }
    }

    render() {
        const { edit } = this.props,
            { intervencoesTecnicasSel } = this.state;
        return (
            <main className="main">
                <section className="section-container">
                    <SectionHeader
                        title="Intervenção técnica"
                        subtitle=""
                        /*  <div className="section-header-search">
                                <InputText placeholder="Buscar" icone="icon-lx-search" />
                            </div>
                                */
                        right={
                            <div className="button-container">
                                {edit ? (
                                    <> </>
                                ) : (
                                        <> </>
                                        /*<Botao ic icon="icon-lx-plus" onClick={() => {
                                            this.setState({ intervencoesTecnicasSel: {} });
                                            this.props.history.push("/intervencaoTecnica/new")
                                        }} />*/
                                    )}
                            </div>
                        }
                    />
                    {edit ? (
                        <Form
                            intervencaoTecnica={intervencoesTecnicasSel}
                            intervencoesExistentes={this.state.intervencoesTecnicas}
                        />
                    ) : (
                            <List
                                onClick={this.handleTableClick}
                                cols={[
                                    {
                                        accessor: "dataIntervencao",
                                        Header: "Data interv.",
                                        width: 100,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {moment(props.value).format("DD/MM/YYYY HH:mm:ss")}
                                            </div>
                                    },
                                    {
                                        accessor: "codigoBico",
                                        Header: "Seq. bico",
                                        width: 90,
                                        filterable: false
                                    },
                                    {
                                        accessor: "encerranteInicial",
                                        Header: "Enc. inicial",
                                        width: 100,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {toFloatFormattedDisplay(props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "encerranteFinal",
                                        Header: "Enc. final",
                                        width: 100,
                                        filterable: false,
                                        Cell: props =>
                                            <div>
                                                {toFloatFormattedDisplay(props.value)}
                                            </div>
                                    },
                                    {
                                        accessor: "codigoPessoa",
                                        Header: "Fornecedor",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "cpfTecnico",
                                        Header: "CPF técnico",
                                        width: 105,
                                        filterable: false
                                    },
                                    {
                                        accessor: "nomeTecnico",
                                        Header: "Nome técnico",
                                        width: 115,
                                        filterable: false
                                    },
                                    {
                                        accessor: "lacresRemovidos",
                                        Header: "Lac. removidos",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "lacresNovos",
                                        Header: "Lac. novos",
                                        width: 100,
                                        filterable: false
                                    },
                                    {
                                        accessor: "motivo",
                                        Header: "Motivo",
                                        width: 100,
                                        filterable: false
                                    }
                                ]}
                                rows={this.state.intervencoesTecnicas}
                            />
                        )}
                </section>
            </main>
        );
    }
}

ScreenIntervencaoTecnica = withRouter(ScreenIntervencaoTecnica);
export { ScreenIntervencaoTecnica };
