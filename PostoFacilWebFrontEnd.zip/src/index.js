import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import Login from './components/screens/Login';
import * as serviceWorker from './serviceWorker';

import { ScreenEmpresa } from './components/screens/empresa/ScreenEmpresa';
//import { ScreenCartoComanda } from './components/screens/cartaocomanda/ScreenCartaoComanda';
//import { ScreenFaixaComissionamento } from './components/screens/faixacomissionamento/ScreenFaixaComissionamento';
import { ScreenGrupoClientes } from './components/screens/grupoclientes/ScreenGrupoClientes';
//import { ScreenMensagens } from './components/screens/cartaocomanda/ScreenMensagens';
import { ScreenAlmoxarifado } from './components/screens/almoxarifado/ScreenAlmoxarifado';

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
//import { ScreenBancos } from './components/screens/bancos/ScreenBancos';
import { ScreenCentrosMonetarios } from './components/screens/centrosmonetarios/ScreenCentrosMonetarios';
//import { ScreenIntervencaoTecnica } from './components/screens/intervencaoTecnica/ScreenIntervencaoTecnica';
import { ScreenFormasPagamento } from './components/screens/pagamento/ScreenFormasPagamento';
import { ScreenPessoas } from './components/screens/pessoas/ScreenPessoas';
import { ScreenCadastroTanque } from './components/screens/tanque/ScreenCadastroTanque';
import { ScreenTroco } from './components/screens/troco/ScreenTroco';
import { ScreenEmpresas } from './components/screens/empresa/ScreenEmpresas';
import { ScreenContas } from './components/screens/contas/ScreenContas';
import { ScreenCadastroBico } from './components/screens/bicos/ScreenCadastroBico';
import { ScreenCadastroBomba } from './components/screens/bomba/ScreenCadastroBomba';
import { ScreenTanquesBombasBicos } from './components/screens/tanquesBombasBicos/ScreenTanquesBombasBicos';

document.body.addEventListener('focus', function(e) {
	if(!e.target.closest(".modal")) {
		const elemento = document.querySelector("div.modal input, div.modal button");
		elemento && elemento.focus();
	}
}, true);

const AppRouter = () => (
  <Router>
	  <Switch>
		<Route path="/" exact component={Login} />


	    {/* Cadastros */}
		
		<Route path="/" exact component={Login} />
		<Route path="/empresa/new" render={(props) => <App {...props} screen={<ScreenEmpresa edit />} />} />
		<Route path="/empresa/" render={(props) => <App {...props} screen={<ScreenEmpresa />} />} />				        
		<Route path="/grupoClientes/new" render={(props) => <App {...props} screen={<ScreenGrupoClientes edit />} />} />
		<Route path="/grupoClientes/" render={(props) => <App {...props} screen={<ScreenGrupoClientes />} />} />				
		<Route path="/almoxarifado/new" render={(props) => <App {...props} screen={<ScreenAlmoxarifado edit />} />} />
		<Route path="/almoxarifado/" render={(props) => <App {...props} screen={<ScreenAlmoxarifado />} />} />
		<Route path="/empresas/new" render={(props) => <App {...props} screen={<ScreenEmpresas edit />} />} />
		<Route path="/empresas/" render={(props) => <App {...props} screen={<ScreenEmpresas />} />} />					    
		
        {/* Financeiro */}

		<Route path="/centrosMonetarios/new" render={(props) => <App {...props} screen={<ScreenCentrosMonetarios edit/>} />} />
		<Route path="/centrosMonetarios/" render={(props) => <App {...props} screen={<ScreenCentrosMonetarios />} />} />		
		<Route path="/formaspagamento/new" render={(props) => <App {...props} screen={<ScreenFormasPagamento edit />} />} />
		<Route path="/formaspagamento/" render={(props) => <App {...props} screen={<ScreenFormasPagamento />} />} />		
		<Route path="/troco/" render={(props) => <App {...props} screen={<ScreenTroco />} />} />
		<Route path="/pessoas/new" render={(props) => <App {...props} screen={<ScreenPessoas  edit />} />} />
		<Route path="/pessoas/" render={(props) => <App {...props} screen={<ScreenPessoas />} />} />				        		
		<Route path="/contas/subconta" render={(props) => <App {...props} screen={<ScreenContas editSub />} />} />
		<Route path="/contas/conta" render={(props) => <App {...props} screen={<ScreenContas edit/>} />} />				
		<Route path="/contas/" render={(props) => <App {...props} screen={<ScreenContas />} />} />				        
		<Route path="/tanque/new" render={(props) => <App {...props} screen={<ScreenCadastroTanque edit />} />} />
		<Route path="/tanque/" render={(props) => <App {...props} screen={<ScreenCadastroTanque />} />} />
		<Route path="/bico/new" render={(props) => <App {...props} screen={<ScreenCadastroBico edit />} />} />
		<Route path="/bico/" render={(props) => <App {...props} screen={<ScreenCadastroBico />} />} />
		<Route path="/bomba/new" render={(props) => <App {...props} screen={<ScreenCadastroBomba edit />} />} />
		<Route path="/bomba/" render={(props) => <App {...props} screen={<ScreenCadastroBomba />} />} />
		<Route path="/tanquebombabico/" render={(props) => <App {...props} screen={<ScreenTanquesBombasBicos />} />} />		
	  </Switch>
  </Router>
  /*
	<Route path="/cartaocomanda/new" render={(props) => <App {...props} screen={<ScreenCartoComanda edit />} />} />
	<Route path="/cartaocomanda/" render={(props) => <App {...props} screen={<ScreenCartoComanda />} />} />
	<Route path="/mensagem/" render={(props) => <App {...props} screen={<ScreenMensagens />} />} />
	<Route path="/faixacomissionamento/new" render={(props) => <App {...props} screen={<ScreenFaixaComissionamento edit />} />} />
	<Route path="/faixacomissionamento/" render={(props) => <App {...props} screen={<ScreenFaixaComissionamento />} />} />
  	<Route path="/bancos/new" render={(props) => <App {...props} screen={<ScreenBancos edit/>} />} />
	<Route path="/bancos/" render={(props) => <App {...props} screen={<ScreenBancos />} />} />
	<Route path="/intervencaoTecnica/new" render={(props) => <App {...props} screen={<ScreenIntervencaoTecnica edit />} />} />
	<Route path="/intervencaoTecnica/" render={(props) => <App {...props} screen={<ScreenIntervencaoTecnica />} />} />
   */
)

ReactDOM.render(<AppRouter />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
