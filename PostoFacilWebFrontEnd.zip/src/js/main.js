import $ from 'jquery';

$(document).ready(function () {

    /* 1024 */
    $(".sidebar-nav-head-content").click(function () {
        $(".sidebar-nav").toggleClass("active");
        $(".sidebar-nav-subnivel-list").removeClass('active');
        $(".sidebar-nav-subnivel, .sidebar-nav-list").removeClass("active");
    });
    
    if (window.matchMedia('(max-width: 1200px)').matches) {
        $(".sidebar-nav-item").click(function () {
            $(".sidebar-nav").addClass("active");
        });
    };

    /* Mobile */
    $("#showmenumobile").click(function () {
        $(".sidebar-nav").toggle();
        $("body").toggleClass("teste");
    });

/* Ajuste do Scroll bug */
window.addEventListener('resize', function(){
    if (window.matchMedia('(min-width: 600px)').matches) {
        $(".sidebar-nav").show();
        $("body").removeClass("teste");
    } else {
        $(".sidebar-nav").hide();
    };
})

/* Fecha menu mobile */
$('.sidebar-nav-subnivel-list li:not(".subnivel, .sidebar-nav-subnivel-item-head"), .sidebar-nab-subnivel-sub li').click(function () {
    if (window.matchMedia('(max-width: 600px)').matches) {
        $(".sidebar-nav").hide();
        $(".sidebar-nav-subnivel-item").removeClass('hide');
        // $(".sidebar-nav-list, .sidebar-nav-item, .sidebar-nav-subnivel, .sidebar-nav-subnivel-list").removeClass('active');
        $("body").removeClass("teste");
    } else {
    }
})

});
